
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<!-- <link rel="stylesheet" href="/resources/demos/style.css"> -->
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>     <script src="main/js/jquery-1.12.4.js"></script>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/plugins/html5-editor/bootstrap-wysihtml5.css" >
<link href="assets/plugins/footable/css/footable.core.css" rel="stylesheet">
<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet">
<link href="main/css/style.css" rel="stylesheet">
<link href="main/css/colors/blue.css" id="theme" rel="stylesheet">
<link href="assets/plugins/sweetalert/sweetalert.css">
<link href="assets/plugins/wizard/steps.css">
<script src="assets/Chart.min.js"></script>
<!--[if lt IE 9]>
<script src="html5shiv.js"></script>
<script src="respond.min.js"></script>
<![endif]-->
<script src="main/js/jquery-ui.js"></script>
<script src="jquery.min.js"></script>
<link rel="stylesheet" href="bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<!-- Include SmartWizard CSS -->
<link href="assets/dist/css/smart_wizard.css" rel="stylesheet" type="text/css" >
<!-- Optional SmartWizard theme -->
<link href="assets/dist/css/smart_wizard_theme_arrows.css" rel="stylesheet" type="text/css" >
<!-- This page css -->
<!-- <link href="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" /> -->
<link href="assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet">
<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" >
<link href="assets/plugins/switchery/dist/switchery.min.css"rel="stylesheet" >
<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" >
<link href="assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" >
<link href="assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css" rel="stylesheet" >
<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css" >
<link href="sweetalert.css" rel="stylesheet">
<script src="sweetalert.min.js"></script>


<body>
  <?php 
  require_once('includes/dbconfig.php');
  include("includes/config.php");
  $id12=$_GET['cid'];
  $query=mysql_query("select * from purchaseorder_reg where id='$id12'");
  while($row=mysql_fetch_array($query))
  { 
     $cid=$row['pono'];
     $supplierid=$row['supplierid'];    
      ?>  
      <div class="modal-header">
        <h4>Update Sales Order Entry</h4>
        <button type="button" class="close" data-dismiss="modal" onclick="window.location.href='purchaseorder_viewup.php';">x</button>
      </div>


<div class="modal-body">
<form method="post" enctype="multipart/form-data" style="margin-top:1%" name="updateform">

<?php
if($row['orderstatus']=="Completed")
{ ?>
<label style="font-size:15px;">Status :&nbsp;&nbsp;</label><label style="font-weight:600;font-size:17px;color:#006400"><?php echo htmlspecialchars_decode($row['orderstatus']);?></label>
<?php } 
if($row['orderstatus']=="On Hold")
{ ?>
<label style="font-size:15px;">Status :&nbsp;&nbsp;</label><label style="font-weight:600;font-size:17px;color:#ffc125"><?php echo htmlspecialchars_decode($row['orderstatus']);?></label>
<?php } 
if($row['orderstatus']=="Short Closed")
{ ?>
<label style="font-size:15px;">Status :&nbsp;&nbsp;</label><label style="font-weight:600;font-size:17px;color:#00c851;"><?php echo htmlspecialchars_decode($row['orderstatus']);?></label>
<?php } 
if($row['orderstatus']=="Cancelled")
{ ?>
<label style="font-size:15px;">Status :&nbsp;&nbsp;</label><label style="font-weight:600;font-size:17px;color:#ff4444;"><?php echo htmlspecialchars_decode($row['orderstatus']);?></label>
<?php }
if($row['orderstatus']=="Open")
{ ?>
<label style="font-size:15px;">Status :&nbsp;&nbsp;</label><label style="font-weight:600;font-size:17px;color:#F38330;"><?php echo htmlspecialchars_decode($row['orderstatus']);?></label>
<?php } ?>


<table class="table table-bordered table-striped">
<tr>
<td style="background-color:#0080FF;text-align:left;font-size:13px;color:white;border:solid 1px lightgray;">Part Name</td>
<td style="font-size:13px;text-align:left;"><?php echo htmlspecialchars_decode($row['partname']);?></td>
</tr> 
<tr>
<td style="background-color:#0080FF;text-align:left;font-size:13px;color:white;border:solid 1px lightgray;">Drawing No.</td>
<td style="font-size:13px;text-align:left;"><?php echo htmlspecialchars_decode($row['drawingno']);?></td>
</tr> 
<tr>
<td style="background-color:#0080FF;text-align:left;font-size:13px;color:white;border:solid 1px lightgray;">Delivery Date</td>
<td style="font-size:13px;text-align:left;"><?php echo htmlspecialchars_decode($row['deliverydate']);?></td>
</tr>  
<tr>
<td style="background-color:#0080FF;text-align:left;font-size:13px;color:white;border:solid 1px lightgray;">Unit Price</td>
<td style="font-size:13px;text-align:left;"><span style="font-family: Verdana,sans-serif;">&#8377</span>&nbsp;<?php echo htmlspecialchars_decode($row['unitprice']);?></td>
</tr>     
</table>


  <div class="row">   
    <div class="col-md-6">
  <div class="form-group">
  <div class="text-left col-xs-3" style="color:black;font-size:14px">PO Quantity</div>
    <input type="text" class="form-control" id="poqty" value="<?php echo htmlentities($row['poqty']);?>"></div>
  </div>
  <div class="col-md-6">
  <div class="form-group">
  <div class="text-left col-xs-3" style="color:black;font-size:14px">Purchased Qty</div>
    <input type="text" class="form-control" name="purchasedqty" id="purchasedqty" style="font-weight: 400;color:black" autocomplete="off" value="<?php echo htmlspecialchars_decode($row['purchasedqty']);?>" onkeyup="calculate()"/></div>
  </div>
  </div>

<div class="row">
 <div class="col-md-6">
  <div class="form-group">
  <div class="text-left col-xs-3" style="color:black;font-size:14px">Pending Qty</div>
    <input type="text" class="form-control" name="pendingqty" id="pendingqty" style="font-weight: 400;color:black" value="<?php echo htmlspecialchars_decode($row['pendingqty']);?>"/>
</div>
  </div>
    <div class="col-md-6">
  <div class="form-group">
<div class="text-left col-xs-3" style="color:black;font-size:14px">Unit</div>
    <input type="text" class="form-control" readonly="" style="font-weight: 400;color:black" value="<?php echo htmlspecialchars_decode($row['unit']);?>"/>
</div>
  </div>

</div>


<input type="text" class="form-control" id="totalprice" readonly="" style="font-weight: 400;color:black;" value="<?php echo htmlspecialchars_decode($row['totalprice']);?>"/>

<input type="text" class="form-control" id="purchase_percent" name="purchase_percent" readonly="" style="font-weight: 400;color:black;" value="<?php echo htmlspecialchars_decode($row['purchase_percent']);?>"/>


<div id="hide1">
<div class="row">
<div class="col-md-6">
<div class="form-group">
  <div class="text-left col-xs-2" style="color:black;font-size:14px">Order Status</div>
<input name="poid" value="<?php echo $id12;?>" style="" >


 <select class="select2 form-control custom-select" name="orderstatus">
 <option><?php echo htmlspecialchars_decode($row['orderstatus']);?></option>   
 <option value="On Hold">On Hold</option>
 <option value="Short Closed">Short Closed</option>
 <option value="Cancelled">Cancelled</option>
 <option value="Open">Open</option>
 </select> 
  </div>
  </div>

<div class="col-md-6">
<div class="form-group">
  <div class="text-left col-xs-2" style="color:black;font-size:14px">Reason for Status Update</div>
   <select name="statusreason" class="form-control first" style="">
    <option><?php echo htmlspecialchars_decode($row['statusreason']);?></option>
    <?php
        require_once("dbcontrollernew.php");
        $db_handle = new DBController();
        $queryf2 ="SELECT * FROM purchaseorder_statusreason where status='1'";
        $productsf2 = $db_handle->runQuery($queryf2);
        foreach($productsf2 as $productf2)
        { ?>
        <option value="<?php echo $productf2['statusreason'];?>"><?php echo $productf2['statusreason'];?></option>
  <?php } ?>
  </select>

</div></div>
</div>


<div class="row">
<div class="col-md-6">
<div class="form-group">
<div class="text-left col-xs-2" style="color:black;font-size:14px">
Priority</div>
 <select class="select2 form-control custom-select" name="priority">
 <option><?php echo htmlspecialchars_decode($row['priority']);?></option>   
 <option value="MGT High">MGT High</option>
 <option value="Very High">Very High</option>
 <option value="High">High</option>
 <option value="Medium">Medium</option>
 <option value="Low">Low</option>
 </select> 
  </div>
  </div>

<div class="col-md-6">
<div class="form-group">
<div class="text-left col-xs-2" style="color:black;font-size:14px">
Commitment Date</div>
 <input type="text" name="statusdate" value="<?php echo htmlentities($row['statusdate']);?>" onpaste="return false;" onCopy="return false" autocomplete=off placeholder="dd-mm-yyyy" id="statusdate" class="form-control "  autocomplete=off> 
</div>
</div>

</div>

<div class="row">
  <div class="col-md-12" >
  <div class="text-left col-xs-2" style="color:black;font-size:14px">Status Remark</div>
<textarea class="form-control" style="background-color:white;line-height:1.6;text-align:justify;max-height:200px;resize:vertical;" maxlength="100" name="statusremark">
  <?php echo htmlspecialchars_decode($row['statusremark']);?>  
  </textarea>
  </div>
</div>  

</div>

<br>
<div class="row" >
  <div class="col-md-8" style="color:#67757C;font-size:13px;font-weight:500;text-align:left">
  <input type="submit" class="btn btn-primary" name="update4" value="Submit"> </div>
  <div class="col-md-4">
    <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="window.location.href='purchaseorder_viewup.php';" >Cancel</button>
  </div>
</div>  

</div><!-- class="modal-body"-->

<?php } ?>




<!-- new datepicker script with year selection -->
<!-- <script src="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<link href="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css"/> -->

<!-- difference between PO qty and pending qty-->
<script type="text/javascript">
function calculate() 
{
    var poqty=document.getElementById('poqty').value;
    var purchasedqty=document.getElementById('purchasedqty').value;
    var totalprice=document.getElementById('totalprice').value;

    var pendingqty=poqty-purchasedqty;
    document.getElementById('pendingqty').value=pendingqty;

    var purchase_percent1=purchasedqty/poqty;
    var purchase_percent2=purchase_percent1*100;
    var purchase_percent=purchase_percent2.toFixed(2);
  
    document.getElementById('purchase_percent').value=purchase_percent;

    if((pendingqty<'0')||(pendingqty=='0'))
    {
      document.getElementById('pendingqty').value='0';
      document.getElementById('purchase_percent').value=100;
    }
   
}
</script>



<script>
 $(document).ready(function(){

    var poqty=document.getElementById('poqty').value;
    var purchasedqty=document.getElementById('purchasedqty').value;
    var totalprice=document.getElementById('totalprice').value;

    if(purchasedqty=="")
    {
      purchasedqty='0';
      var pendingqty=poqty-purchasedqty;
      document.getElementById('pendingqty').value=pendingqty;

    }  
});
</script>


<!-- onkey of purchased qty if pending qty was 0 then hide the blocks-->
<script type="text/javascript">
$(document).ready(function(){    
    $("#purchasedqty").keyup(function(){  
       var p1=document.getElementById('pendingqty').value;
       if((p1=='0')||(p1<0))
       {
        document.getElementById('hide1').style.display="none";
       }
       else
       {
        document.getElementById('hide1').style.display="block";
       }
    });  
}); 

</script>


<!-- onload if pending qty was 0 then hide the blocks-->
<script type="text/javascript">
$(document).ready(function(){    
    // $("#purchasedqty").keyup(function(){  
       var p1=document.getElementById('pendingqty').value;
       if((p1=='0')||(p1<0))
       {
        document.getElementById('hide1').style.display="none";
       }
       else
       {
        document.getElementById('hide1').style.display="block";
       }
    // });  
}); 

</script>

<script type="text/javascript">
jQuery(document).ready(function() {
// Switchery
var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
$('.js-switch').each(function() {
new Switchery($(this)[0], $(this).data());
});
// For select 2
$(".select2").select2();
$('.selectpicker').selectpicker();
//Bootstrap-TouchSpin
$(".vertical-spin").TouchSpin({
verticalbuttons: true,
verticalupclass: 'ti-plus',
verticaldownclass: 'ti-minus'
});
var vspinTrue = $(".vertical-spin").TouchSpin({
verticalbuttons: true
});
if (vspinTrue) {
$('.vertical-spin').prev('.bootstrap-touchspin-prefix').remove();
}
$("input[name='tch1']").TouchSpin({
min: 0,
max: 100,
step: 0.1,
decimals: 2,
boostat: 5,
maxboostedstep: 10,
postfix: '%'
});
$("input[name='tch2']").TouchSpin({
min: -1000000000,
max: 1000000000,
stepinterval: 50,
maxboostedstep: 10000000,
prefix: '$'
});
$("input[name='tch3']").TouchSpin();
$("input[name='tch3_22']").TouchSpin({
initval: 40
});
$("input[name='tch5']").TouchSpin({
prefix: "pre",
postfix: "post"
});
// For multiselect
$('#pre-selected-options').multiSelect();
$('#optgroup').multiSelect({
selectableOptgroup: true
});
$('#public-methods').multiSelect();
$('#select-all').click(function() {
$('#public-methods').multiSelect('select_all');
return false;
});
$('#deselect-all').click(function() {
$('#public-methods').multiSelect('deselect_all');
return false;
});
$('#refresh').on('click', function() {
$('#public-methods').multiSelect('refresh');
return false;
});
$('#add-option').on('click', function() {
$('#public-methods').multiSelect('addOption', {
value: 42,
text: 'test 42',
index: 0
});
return false;
});
$(".ajax").select2({
ajax: {
url: "https://api.github.com/search/repositories",
dataType: 'json',
delay: 250,
data: function(params) {
return {
q: params.term, // search term
page: params.page
};
},
processResults: function(data, params) {
// parse the results into the format expected by Select2
// since we are using custom formatting functions we do not need to
// alter the remote JSON data, except to indicate that infinite
// scrolling can be used
params.page = params.page || 1;
return {
results: data.items,
pagination: {
more: (params.page * 30) < data.total_count
}
};
},
cache: true
},
escapeMarkup: function(markup) {
return markup;
}, // let our custom formatter work
minimumInputLength: 1,
//templateResult: formatRepo, // omitted for brevity, see the source of this page
//templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
});
});
</script>

    <script src="assets/plugins/jquery/jquery.min.js"></script>
    <script src="main/js/jquery-ui.js"></script>
    <script src="assets/plugins/bootstrap/js/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="main/js/jquery.slimscroll.js"></script>
    <script src="main/js/waves.js"></script>
    <script src="main/js/sidebarmenu.js"></script>
    <script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="main/js/custom.min.js"></script>
    <script src="assets/plugins/chartist-js/dist/chartist.min.js"></script>
    <script src="assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="assets/plugins/raphael/raphael-min.js"></script>
    <script src="assets/plugins/morrisjs/morris.min.js"></script>
    <script src="assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="assets/plugins/wizard/jquery.steps.min.js"></script>
    <script src="assets/plugins/wizard/jquery.validate.min.js"></script>
    <script src="assets/plugins/sweetalert/sweetalert.min.js"></script>
    <script src="assets/plugins/wizard/steps.js"></script>
    <script src="main/js/dashboard2.js"></script>
    <script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
    <script src="assets/datatables/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="assets/dist/js/jquery.smartWizard.min.js"></script>
 <script src="assets/plugins/moment/moment.js"></script>
              <!--script for calender-->
<script src="assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>
<script src="assets/plugins/Magnific-Popup-master/dist/jquery.magnific-popup.min.js"></script>
<script src="assets/plugins/Magnific-Popup-master/dist/jquery.magnific-popup-init.js"></script>
<script type="text/javascript">
$(document).ready(function(){

// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard').smartWizard({
selected: 0,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>
<script type="text/javascript">
$(document).ready(function(){

// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard1').smartWizard({
selected: 1,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>
<script type="text/javascript">
$(document).ready(function(){

// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard2').smartWizard({
selected: 2,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>

<script type="text/javascript">
$(document).ready(function(){

// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard3').smartWizard({
selected: 3,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>

<script type="text/javascript">
$('#statusdate').bootstrapMaterialDatePicker({ format: 'DD-MM-YYYY', time: false});
</script>

<!-- <script>
$("#statusdate").datepicker({ dateFormat: "dd-mm-yy"}).datepicker();
</script> -->

</body>
