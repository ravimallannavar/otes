 
    <link rel="stylesheet" href="main/js/jquery-ui.css">
     <script src="main/js/jquery-1.12.4.js"></script>
    <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/plugins/html5-editor/bootstrap-wysihtml5.css" >
    <!-- This page css -->
    <!--  <link href="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" /> -->
    <link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/switchery/dist/switchery.min.css"rel="stylesheet" />
    <link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" />
    <link href="assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" />
    <link href="assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
    <link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css" />
    <!--- -->
    <link href="assets/datatables/jquery.dataTables.yadcf.css" rel="stylesheet" type="text/css" />
    <script src="assets/datatables/jquery.dataTables.yadcf.js"></script>
     <link href="main/css/style.css" rel="stylesheet">
    <link href="main/css/colors/blue.css" id="theme" rel="stylesheet">
    <link href="assets/plugins/sweetalert/sweetalert.css">
    <link href="assets/plugins/wizard/steps.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="assets/Chart.min.js"></script>
    <!--[if lt IE 9]>
	    <script src="html5shiv.js"></script>
	    <script src="respond.min.js"></script>
	<![endif]-->
	<script src="main/js/jquery-ui.js"></script>
	<script src="jquery.min.js"></script>
	<link href="sweetalert.css" rel="stylesheet" />
    <script src="sweetalert.min.js"></script>
    <script src="assets/Chart.min.js"></script>
    <script src="assets/bootstrap-show-password.js"></script>


<script type="text/javascript">
function showDiv(select){
if(select.value=='Need More Info'){
document.getElementById('needinfo').style.display = "block";
}
else{
// location.reload();

document.getElementById('needinfo').style.display = "none";
}
if(select.value=='Approved')
{
document.getElementById('approved').style.display = "block";
}
else{
document.getElementById('approved').style.display = "none";
}

if(select.value=='Reject')
{
document.getElementById('approved2').style.display = "block";
}
else{
document.getElementById('approved2').style.display = "none";
}


}
</script>

<script>
function checkform() {
if(document.updateform.needremark.value == "") 
{
swal("Oops...!!!", "Kindly fill Remark", "warning")

return false;
} 
else {
document.updateform.submit();
}
}</script>


<body>
<div class="modal-header">
<h5>Update Purchase Order Management Status </h5>
<?php 
require_once('includes/dbconfig.php');
include("includes/config.php");
$id=intval($_GET['cid']);
$query=mysql_query("select * from purchaseorder_reg where pono='$id' limit 1");
while($row=mysql_fetch_array($query))
{  ?>

 <button type="button" class="close" data-dismiss="modal" onclick="window.location.href='purchaseorder_mgmtview.php?cid=<?php echo "$id"; ?>';">x</button>
</div>


<table class="table table-bordered table-sm">
<?php
$querypt1=mysql_query("select * from purchaseorder_reg where pono='".$_GET['cid']."' limit 1");
while($rowpt1=mysql_fetch_array($querypt1))                     
{ ?>

<tr>
<?php if($rowpt1['mgmt_status']=="Approved")
{ ?>

<td><h5 style="color:#5BB75B;font-weight:550;font-size:18px;">Approval Status :  <?php echo htmlentities($rowpt1['mgmt_status']);?></h5></td>

<?php }else if($rowpt1['mgmt_status']=="Need More Info"){ ?>
<td>  
<h5 style="color:#1976D2;font-weight:550;font-size:18px;">Approval Status :  <?php echo htmlentities($rowpt1['mgmt_status']);?></h5></td>

<?php  }else if($rowpt1['mgmt_status']=="Reject"){ ?>

<td>   <h5 style="color:#ff4444;font-weight:550;font-size:18px;">Approval Status : <?php echo htmlentities($rowpt1['mgmt_status']);?></h5>
</td>
<?php }
else if(($rowpt1['mgmt_status']=="Initiated")||($rowpt1['mgmt_status']==""))
{ ?>
<td> <h5 style="color:#ff4444;font-weight:550;font-size:18px;">Approval Status : Initiated</h5>
</td>
</tr>
<?php  } } ?>
</table>
<div class="modal-body">

<form method="post" enctype="multipart/form-data" style="margin-top:1%" name="updateform">


<div class="form-group">
<div class="text-left col-xs-2" style="color:#67757C;font-size:16px" >Status</div>

<select class="form-control" style="height:25px" name="status" required="required"  onchange="showDiv(this)">
<option value="">Please Select</option>
<option value="Need More Info">Need More Info</option>
<option value="Approved">Approved</option>
<option value="Reject">Reject</option>
</select>

</div>
<input value="<?php echo $id?>" name="pono" style="display: none">
<!-- Need Info -->
<div id="needinfo" style="display:none">
<div class="form-group">
<div class="text-left col-xs-2" style="color:#67757C;font-size:16px">Need Remark<span style="font-size:medium;color:red"></span><span style="font-size:small"> (Max. 200 Characters)</span></div>
<textarea class="form-control" name="needremark" style="background-color:white" maxlength="200" ></textarea>
</div>
	     
<div class="col-sm-2">
<input type="submit" class="btn btn-primary" name="update1" value="Submit" onclick="return checkform()">   
</div>
</div>

<!-- Approved-->
<div id="approved" style="display:none">
<div class="form-group">
<div class="text-left col-xs-2" style="color:#67757C;font-size:16px">Approve Remark<span style="font-size:small"> (Max. 200 Characters)</span></div>
<textarea  class="form-control" name="approveremark" style="background-color:white;margin-top:5px" maxlength="200"></textarea>
</div>
<div class="col-sm-2">
<input type="submit" class="btn btn-primary" name="update2" value="Submit" onclick="return checkform1()" >   
</div>
</div>

<div id="approved2" style="display:none">
<div class="form-group">
<div class="text-left col-xs-2" style="color:#67757C;font-size:16px">Reject Remark<span style="font-size:small"> (Max. 200 Characters)</span></div>
<textarea  class="form-control"  name="rejectremark" style="background-color:white;margin-top:5px" maxlength="200"></textarea>
</div>
<div class="col-sm-2">
<input type="submit" class="btn btn-primary" name="update3" value="Submit" onclick="return checkform1()" >   
</div>
</div>

</form>

<?php } ?>
</div>

 <script src="assets/plugins/jquery/jquery.min.js"></script>
    <script src="main/js/jquery-ui.js"></script>
    <script src="assets/plugins/bootstrap/js/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="main/js/jquery.slimscroll.js"></script>
    <script src="main/js/waves.js"></script>
    <script src="main/js/sidebarmenu.js"></script>
    <script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="main/js/custom.min.js"></script>
    <script src="assets/plugins/chartist-js/dist/chartist.min.js"></script>
    <script src="assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="assets/plugins/raphael/raphael-min.js"></script>
    <script src="assets/plugins/morrisjs/morris.min.js"></script>
    <script src="assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="assets/plugins/wizard/jquery.steps.min.js"></script>
    <script src="assets/plugins/wizard/jquery.validate.min.js"></script>
    <script src="assets/plugins/sweetalert/sweetalert.min.js"></script>
    <script src="assets/plugins/wizard/steps.js"></script>
    <script src="main/js/dashboard2.js"></script>
    <script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
	<script src="assets/datatables/jquery.dataTables.min.js"></script>
	 
	 <!-- start - This is for export functionality only -->
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
   <script type="text/javascript" src="assets/dist/js/jquery.smartWizard.min.js"></script>
   
   <!-- This page script  -->
    <script src="assets/plugins/switchery/dist/switchery.min.js"></script>
    <script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
    <script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
    <script src="assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
    <script src="assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.js" type="text/javascript"></script>
    <script src="assets/plugins/dff/dff.js" type="text/javascript"></script>
    <script type="text/javascript" src="assets/plugins/multiselect/js/jquery.multi-select.js"></script>
    <script type="text/javascript">
    jQuery(document).ready(function() {
        // Switchery
        var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
        $('.js-switch').each(function() {
            new Switchery($(this)[0], $(this).data());
        });
        // For select 2
        $(".select2").select2();
        $('.selectpicker').selectpicker();
        //Bootstrap-TouchSpin
        $(".vertical-spin").TouchSpin({
            verticalbuttons: true,
            verticalupclass: 'ti-plus',
            verticaldownclass: 'ti-minus'
        });
        var vspinTrue = $(".vertical-spin").TouchSpin({
            verticalbuttons: true
        });
        if (vspinTrue) {
            $('.vertical-spin').prev('.bootstrap-touchspin-prefix').remove();
        }
        $("input[name='tch1']").TouchSpin({
            min: 0,
            max: 100,
            step: 0.1,
            decimals: 2,
            boostat: 5,
            maxboostedstep: 10,
            postfix: '%'
        });
        $("input[name='tch2']").TouchSpin({
            min: -1000000000,
            max: 1000000000,
            stepinterval: 50,
            maxboostedstep: 10000000,
            prefix: '$'
        });
        $("input[name='tch3']").TouchSpin();
        $("input[name='tch3_22']").TouchSpin({
            initval: 40
        });
        $("input[name='tch5']").TouchSpin({
            prefix: "pre",
            postfix: "post"
        });
        // For multiselect
        $('#pre-selected-options').multiSelect();
        $('#optgroup').multiSelect({
            selectableOptgroup: true
        });
        $('#public-methods').multiSelect();
        $('#select-all').click(function() {
            $('#public-methods').multiSelect('select_all');
            return false;
        });
        $('#deselect-all').click(function() {
            $('#public-methods').multiSelect('deselect_all');
            return false;
        });
        $('#refresh').on('click', function() {
            $('#public-methods').multiSelect('refresh');
            return false;
        });
        $('#add-option').on('click', function() {
            $('#public-methods').multiSelect('addOption', {
                value: 42,
                text: 'test 42',
                index: 0
            });
            return false;
        });
        $(".ajax").select2({
            ajax: {
                url: "https://api.github.com/search/repositories",
                dataType: 'json',
                delay: 250,
                data: function(params) {
                    return {
                        q: params.term, // search term
                        page: params.page
                    };
                },
                processResults: function(data, params) {
                    // parse the results into the format expected by Select2
                    // since we are using custom formatting functions we do not need to
                    // alter the remote JSON data, except to indicate that infinite
                    // scrolling can be used
                    params.page = params.page || 1;
                    return {
                        results: data.items,
                        pagination: {
                            more: (params.page * 30) < data.total_count
                        }
                    };
                },
                cache: true
            },
            escapeMarkup: function(markup) {
                return markup;
            }, // let our custom formatter work
            minimumInputLength: 1,
            //templateResult: formatRepo, // omitted for brevity, see the source of this page
            //templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
        });
    });
    </script>
    <!-- ============================================================== -->
    <!-- Style switcher -->
    <!-- ============================================================== -->
   <script>
var open = 'mdi mdi-eye';
var close = 'mdi mdi-hide';
var ele = document.getElementById('password');

document.getElementById('toggleBtn').onclick = function() {
	if( this.classList.contains(open) ) {
  	ele.type="text";
    this.classList.remove(open);
    this.className += ' '+close;
  } else {
  	ele.type="password";
    this.classList.remove(close);
    this.className += ' '+open;
  }
}
</script>

<script>
var openf = 'fa fa-eye';
var closef = 'fa fa-eye-slash';
var elef = document.getElementById('password1');

document.getElementById('toggleBtn1').onclick = function() {
	if( this.classList.contains(openf) ) {
  	elef.type="text";
    this.classList.remove(openf);
    this.className += ' '+closef;
  } else {
  	elef.type="password";
    this.classList.remove(closef);
    this.className += ' '+openf;
  }
}
</script>
	<script>
var myInput = document.getElementById("password");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");
// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("message").style.display = "block";
}
// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("message").style.display = "none";
}
// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }
  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  // Validate length
  if(myInput.value.length >= 6) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }

}

</script>
    <!-- popup modal for take action -->
    <script>
	    $('.li-modal').on('click', function(e){
	      e.preventDefault();
	      $('#theModal').modal('show').find('.modal-content').load($(this).attr('href'));
	    });
  	</script>
	<!-- -->
    <script type="text/javascript">
        $(document).ready(function(){
            // Toolbar extra buttons
            var btnFinish = $('<button></button>').text('Finish')
                                             .addClass('btn btn-info')
                                             .on('click', function(){ alert('Finish Clicked'); });
            var btnCancel = $('<button></button>').text('Cancel')
                                             .addClass('btn btn-danger')
                                             .on('click', function(){ $('#smartwizard').smartWizard("reset"); });

            // Smart Wizard
            $('#smartwizard').smartWizard({
                    selected: 0,
                    theme: 'arrows',
                    transitionEffect:'fade',
                    toolbarSettings: {toolbarPosition: 'bottom',
                                      toolbarExtraButtons: [btnFinish, btnCancel]
                                    }
                 });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function(){

            // Toolbar extra buttons
            var btnFinish = $('<button></button>').text('Finish')
                                             .addClass('btn btn-info')
                                             .on('click', function(){ alert('Finish Clicked'); });
            var btnCancel = $('<button></button>').text('Cancel')
                                             .addClass('btn btn-danger')
                                             .on('click', function(){ $('#smartwizard').smartWizard("reset"); });

            // Smart Wizard
            $('#smartwizard1').smartWizard({
                    selected: 0,
                    theme: 'arrows',
                    transitionEffect:'fade',
                    toolbarSettings: {toolbarPosition: 'bottom',
                                      toolbarExtraButtons: [btnFinish, btnCancel]
                                    }
                 });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function(){

            // Toolbar extra buttons
            var btnFinish = $('<button></button>').text('Finish')
                                             .addClass('btn btn-info')
                                             .on('click', function(){ alert('Finish Clicked'); });
            var btnCancel = $('<button></button>').text('Cancel')
                                             .addClass('btn btn-danger')
                                             .on('click', function(){ $('#smartwizard').smartWizard("reset"); });

            // Smart Wizard
            $('#smartwizard2').smartWizard({
                    selected: 1,
                    theme: 'arrows',
                    transitionEffect:'fade',
                    toolbarSettings: {toolbarPosition: 'bottom',
                                      toolbarExtraButtons: [btnFinish, btnCancel]
                                    }
                 });
        });
    </script>

<script type="text/javascript">
        $(document).ready(function(){

            // Toolbar extra buttons
            var btnFinish = $('<button></button>').text('Finish')
                                             .addClass('btn btn-info')
                                             .on('click', function(){ alert('Finish Clicked'); });
            var btnCancel = $('<button></button>').text('Cancel')
                                             .addClass('btn btn-danger')
                                             .on('click', function(){ $('#smartwizard').smartWizard("reset"); });

            // Smart Wizard
            $('#smartwizard3').smartWizard({
                    selected: 2,
                    theme: 'arrows',
                    transitionEffect:'fade',
                    toolbarSettings: {toolbarPosition: 'bottom',
                                      toolbarExtraButtons: [btnFinish, btnCancel]
                                    }
                 });
        });
    </script>


	<script>
	var table = $('#example').DataTable({order:[[0,"desc"]]});
</script>
<script>
		$(document).ready(function() {
			$('.datatable-1').dataTable();
			$('.dataTables_paginate').addClass("btn-group datatable-pagination");
			$('.dataTables_paginate > a').wrapInner('<span />');
		} );
	</script>
	<script>
	$(document).on('click', '#refresh', function () {
    var $link = $('li.active a[data-toggle="tab"]');
    $link.parent().removeClass('active');
    var tabLink = $link.attr('href');
    $('#mainTabs a[href="' + tabLink + '"]').tab('show');
});

$('a[data-toggle="tab"]').on('shown.bs.tab', function () {
    $('.show-time').html(new Date().toLocaleTimeString());
});</script>
	<script>
function myFunction() {
  location.reload();
}
</script>
    <link rel="stylesheet" href="assets/plugins/html5-editor/bootstrap-wysihtml5.css" >
<script>
function myFunction() {
swal("Oops...!!!", "you can't edit a Under Analaysis,Analysis Completed or Closed complaint", "warning")

}
</script>
<script>
function myFunction1() {
  swal("Oops...!!!", "you can't edit deactivated user","warning")
}
</script>

<script>
		function fileValidation3(){
		    var fileInput = document.getElementById('file');
		    var filePath = fileInput.value;
		      var allowedExtensions = /(\.csv)$/i;
		    if(!allowedExtensions.exec(filePath)){
				swal("Oops...!!!", "Kindly upload a valid file format", "warning")
		        fileInput.value = '';
		        return false;
		    }var size=$('#file')[0].files[0].size;
				
	}
	</script>
	    <script type="text/javascript" src="assets/plugins/multiselect/js/jquery.multi-select.js"></script>


<script>
function maxLengthCheck(object) {
if (object.value.length > object.max.length)
object.value = object.value.slice(0, object.max.length)
}
</script>

<script type="text/javascript">
$(document).ready(function(){

// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard').smartWizard({
selected: 0,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>
<script type="text/javascript">
$(document).ready(function(){

// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard1').smartWizard({
selected: 1,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>
<script type="text/javascript">
$(document).ready(function(){

// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard2').smartWizard({
selected: 2,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>

<script type="text/javascript">
$(document).ready(function(){

// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard3').smartWizard({
selected: 3,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>


</body>
