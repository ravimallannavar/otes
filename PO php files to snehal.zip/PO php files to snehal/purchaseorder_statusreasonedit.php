 
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>   
     <script src="main/js/jquery-1.12.4.js"></script>
    <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/plugins/html5-editor/bootstrap-wysihtml5.css" >
    <!-- This page css -->
     <link href="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/switchery/dist/switchery.min.css"rel="stylesheet" />
    <link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" />
    <link href="assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" />
    <link href="assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
    <link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css" />
    <!--- -->
    <link href="assets/plugins/chartist-js/dist/chartist.min.css" rel="stylesheet">
    <link href="assets/plugins/chartist-js/dist/chartist-init.css" rel="stylesheet">
    <link href="assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.css" rel="stylesheet">
    <link href="assets/plugins/morrisjs/morris.css" rel="stylesheet">
    <link href="assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
    <link href="main/css/style.css" rel="stylesheet">
    <link href="main/css/colors/blue.css" id="theme" rel="stylesheet">
    <link href="assets/plugins/sweetalert/sweetalert.css">
    <link href="assets/plugins/wizard/steps.css">
    <!--[if lt IE 9]>
      <script src="html5shiv.js"></script>
      <script src="respond.min.js"></script>
  <![endif]-->
  <script src="main/js/jquery-ui.js"></script>
  <script src="jquery.min.js"></script>
  <link href="sweetalert.css" rel="stylesheet" />
    <script src="sweetalert.min.js"></script>
    <script src="assets/Chart.min.js"></script>
<style>
    div.scrollmenu 
    {
     overflow: auto;
    }
  </style>
  <style>
.form-control{
  
  font-size:small;
}
@import url('font-awesome.min.css');
.panel-title > a:before {
    float: right !important;
    font-family: FontAwesome;
    content:"\f068";
    padding-right: 5%;
}
.panel-title > a.collapsed:before {
    float: right !important;
    content:"\f067";
}
.panel-title > a:hover, 
.panel-title > a:active, 
.panel-title > a:focus  {
    text-decoration:none;
}
td{
  
  color:#2C3E50;
}
</style>    


<body>
<div class="modal-header">
  <h5>Edit Reason For Status Update</h5>
  <button type="button" class="close" data-dismiss="modal" onclick="window.location.href='purchaseorder_statusreason.php';" >x</button>
 </div>
<div class="modal-body">
<?php 
require_once('includes/dbconfig.php');
include("includes/config.php");
$id=intval($_GET['cid']);
$query=mysql_query("select * from purchaseorder_statusreason where id='$id'");
while($row=mysql_fetch_array($query))
{
?>             
<form method="post" enctype="multipart/form-data" style="margin-top:1%">
  <input type="text" value="<?php echo htmlentities($row['id']);?>" name="id" style="display:none">
     <div class="row">
  <div class="col-md-12">
  <div class="form-group">
  <div class="text-left col-xs-2" style="color:#67757C;font-size:16px">Reason For Status Update<span style="font-size:small;color:red"></span></div>
<textarea class=" form-control" style="background-color:white;line-height:1.6;text-align:justify;margin-top:8px;max-height:200px;resize:vertical;" name="statusreason" maxlength="200"><?php echo htmlspecialchars_decode($row['statusreason'])?></textarea>
    </div>
  </div>
</div> 
<div class="form-group">
  <div class="col-sm-2">
      <input type="submit" class="btn btn-primary" name="update1" value="Submit">   
  </div>
</div>
</form>
<?php } ?>
</div>
   
    <script src="assets/plugins/jquery/jquery.min.js"></script>
    <script src="main/js/jquery-ui.js"></script>
    <script src="assets/plugins/bootstrap/js/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="main/js/jquery.slimscroll.js"></script>
    <script src="main/js/waves.js"></script>
    <script src="main/js/sidebarmenu.js"></script>
    <script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="main/js/custom.min.js"></script>
    <script src="assets/plugins/chartist-js/dist/chartist.min.js"></script>
    <script src="assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="assets/plugins/raphael/raphael-min.js"></script>
    <script src="assets/plugins/morrisjs/morris.min.js"></script>
    <script src="assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="assets/plugins/wizard/jquery.steps.min.js"></script>
    <script src="assets/plugins/wizard/jquery.validate.min.js"></script>
    <script src="assets/plugins/sweetalert/sweetalert.min.js"></script>
    <script src="assets/plugins/wizard/steps.js"></script>
    <script src="main/js/dashboard2.js"></script>
    <script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
  <script src="assets/datatables/jquery.dataTables.min.js"></script>
   <!-- start - This is for export functionality only -->
 
    <!-- popup modal for take action -->
    <script>
      $('.li-modal').on('click', function(e){
        e.preventDefault();
        $('#theModal').modal('show').find('.modal-content').load($(this).attr('href'));
      });
    </script>


    <script type="text/javascript">
        $(document).ready(function(){
            // Toolbar extra buttons
            var btnFinish = $('<button></button>').text('Finish')
                                             .addClass('btn btn-info')
                                             .on('click', function(){ alert('Finish Clicked'); });
            var btnCancel = $('<button></button>').text('Cancel')
                                             .addClass('btn btn-danger')
                                             .on('click', function(){ $('#smartwizard').smartWizard("reset"); });

            // Smart Wizard
            $('#smartwizard').smartWizard({
                    selected: 0,
                    theme: 'arrows',
                    transitionEffect:'fade',
                    toolbarSettings: {toolbarPosition: 'bottom',
                                      toolbarExtraButtons: [btnFinish, btnCancel]
                                    }
                 });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function(){

            // Toolbar extra buttons
            var btnFinish = $('<button></button>').text('Finish')
                                             .addClass('btn btn-info')
                                             .on('click', function(){ alert('Finish Clicked'); });
            var btnCancel = $('<button></button>').text('Cancel')
                                             .addClass('btn btn-danger')
                                             .on('click', function(){ $('#smartwizard').smartWizard("reset"); });

            // Smart Wizard
            $('#smartwizard1').smartWizard({
                    selected: 0,
                    theme: 'arrows',
                    transitionEffect:'fade',
                    toolbarSettings: {toolbarPosition: 'bottom',
                                      toolbarExtraButtons: [btnFinish, btnCancel]
                                    }
                 });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function(){

            // Toolbar extra buttons
            var btnFinish = $('<button></button>').text('Finish')
                                             .addClass('btn btn-info')
                                             .on('click', function(){ alert('Finish Clicked'); });
            var btnCancel = $('<button></button>').text('Cancel')
                                             .addClass('btn btn-danger')
                                             .on('click', function(){ $('#smartwizard').smartWizard("reset"); });

            // Smart Wizard
            $('#smartwizard2').smartWizard({
                    selected: 1,
                    theme: 'arrows',
                    transitionEffect:'fade',
                    toolbarSettings: {toolbarPosition: 'bottom',
                                      toolbarExtraButtons: [btnFinish, btnCancel]
                                    }
                 });
        });
    </script>

<script type="text/javascript">
        $(document).ready(function(){

            // Toolbar extra buttons
            var btnFinish = $('<button></button>').text('Finish')
                                             .addClass('btn btn-info')
                                             .on('click', function(){ alert('Finish Clicked'); });
            var btnCancel = $('<button></button>').text('Cancel')
                                             .addClass('btn btn-danger')
                                             .on('click', function(){ $('#smartwizard').smartWizard("reset"); });

            // Smart Wizard
            $('#smartwizard3').smartWizard({
                    selected: 2,
                    theme: 'arrows',
                    transitionEffect:'fade',
                    toolbarSettings: {toolbarPosition: 'bottom',
                                      toolbarExtraButtons: [btnFinish, btnCancel]
                                    }
                 });
        });
    </script>


  <script>
  var table = $('#example').DataTable({order:[[0,"desc"]]});
</script>
<script>
    $(document).ready(function() {
      $('.datatable-1').dataTable();
      $('.dataTables_paginate').addClass("btn-group datatable-pagination");
      $('.dataTables_paginate > a').wrapInner('<span />');
    } );
  </script>
  <script>
  $(document).on('click', '#refresh', function () {
    var $link = $('li.active a[data-toggle="tab"]');
    $link.parent().removeClass('active');
    var tabLink = $link.attr('href');
    $('#mainTabs a[href="' + tabLink + '"]').tab('show');
});

$('a[data-toggle="tab"]').on('shown.bs.tab', function () {
    $('.show-time').html(new Date().toLocaleTimeString());
});</script>
  <script>
function myFunction() {
  location.reload();
}
</script>
<script>
function myFunction() {
swal("Oops...!!!", "you can't edit a Under Analaysis,Analysis Completed or Closed complaint", "warning")

}
</script>
<script>
function myFunction1() {
  swal("Oops...!!!", "you can't edit deactivated department","warning")
}
</script>
<script>
    function myFunction() {
        var input, filter, ul, li, a, i, txtValue;
        input = document.getElementById("myInput");
        filter = input.value.toUpperCase();
        ul = document.getElementById("myUL");
        li = ul.getElementsByTagName("li");
        for (i = 0; i < li.length; i++) {
            a = li[i].getElementsByTagName("a")[0];
            txtValue = a.textContent || a.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                li[i].style.display = "";
            } else {
                li[i].style.display = "none";
            }
        }
    }
  </script>
<script>
    function fileValidation3(){
        var fileInput = document.getElementById('file');
        var filePath = fileInput.value;
          var allowedExtensions = /(\.csv)$/i;
        if(!allowedExtensions.exec(filePath)){
        swal("Oops...!!!", "Kindly upload a valid file format", "warning")
            fileInput.value = '';
            return false;
        }var size=$('#file')[0].files[0].size;
        
  }
  </script>
      <link rel="stylesheet" href="assets/plugins/html5-editor/bootstrap-wysihtml5.css" >
  </body>
