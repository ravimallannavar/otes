<?php 
session_start();
if(!isset($_SESSION['id'],$_SESSION['department']))
{
header('location:index.php?lmsg=true');
exit;
}
require_once('includes/dbconfig.php');
include("includes/config.php");

?>


<!-- updating PO Order status-->
<?php
if(isset($_POST['update4']))
{

$poid=$_POST['poid'];

$purchasedqty=$_POST['purchasedqty'];
$purchasedqty=htmlspecialchars($purchasedqty,ENT_QUOTES);

$pendingqty=$_POST['pendingqty'];
$pendingqty=htmlspecialchars($pendingqty,ENT_QUOTES);

$purchase_percent=$_POST['purchase_percent'];
$purchase_percent=htmlspecialchars($purchase_percent,ENT_QUOTES);

$orderstatus=$_POST['orderstatus'];
$orderstatus=htmlspecialchars($orderstatus,ENT_QUOTES);

$statusreason=$_POST['statusreason'];
$statusreason=htmlspecialchars($statusreason,ENT_QUOTES);

$priority=$_POST['priority'];
$priority=htmlspecialchars($priority,ENT_QUOTES);

$statusdate=$_POST['statusdate'];
$statusdate=htmlspecialchars($statusdate,ENT_QUOTES);

$statusremark=$_POST['statusremark'];
$statusremark=htmlspecialchars($statusremark,ENT_QUOTES);


if(($pendingqty=='0')||($pendingqty<'0'))
{
$sql3=mysql_query("update purchaseorder_reg set purchasedqty='$purchasedqty',pendingqty='$pendingqty',purchase_percent='$purchase_percent',orderstatus='Completed',statusreason='$statusreason',priority='$priority',statusdate='$statusdate',statusremark='$statusremark' where id='$poid'");


if($sql3=="")
  {
        echo '<script>        
        setTimeout(function() {
        swal({  
                    title: "Oops...!!!",
                    text: "Something went wrong",
                    type: "warning"   
          }, 
           function() 
          {
                    window.location = "purchaseorder_viewup.php";
            });
         }, 1000);
       </script>';       
 }
  else
  {
   
      echo '<script>        
        setTimeout(function() {
        swal({  
                    title: "Success!",
                    text: "Purchase Order Status Updated Successfully",
                    type: "success"   
          }, 
           function() 
          {
                    window.location = "purchaseorder_viewup.php";
            });
         }, 1000);
       </script>';           
  } 
  
} //if pending qty 0 if block end
else if(($pendingqty!='0')&&($orderstatus=="Completed"))
{
  $sql3=mysql_query("update purchaseorder_reg set purchasedqty='$purchasedqty',pendingqty='$pendingqty',purchase_percent='$purchase_percent',orderstatus='Open',statusreason='$statusreason',priority='$priority',statusdate='$statusdate',statusremark='$statusremark' where id='$poid'");


if($sql3=="")
  {
        echo '<script>        
        setTimeout(function() {
        swal({  
                    title: "Oops...!!!",
                    text: "Something went wrong",
                    type: "warning"   
          }, 
           function() 
          {
                    window.location = "purchaseorder_viewup.php";
            });
         }, 1000);
       </script>';       
 }
  else
  {
   
      echo '<script>        
        setTimeout(function() {
        swal({  
                    title: "Success!",
                    text: "Purchase Order Status Updated Successfully",
                    type: "success"   
          }, 
           function() 
          {
                   window.location = "purchaseorder_viewup.php";
            });
         }, 1000);
       </script>';           
  } 
  
} //else if end pending qty not equal to 0
else
{
  $sql3=mysql_query("update purchaseorder_reg set purchasedqty='$purchasedqty',pendingqty='$pendingqty',purchase_percent='$purchase_percent',orderstatus='$orderstatus',statusreason='$statusreason',priority='$priority',statusdate='$statusdate',statusremark='$statusremark' where id='$poid'");


if($sql3=="")
  {
        echo '<script>        
        setTimeout(function() {
        swal({  
                    title: "Oops...!!!",
                    text: "Something went wrong",
                    type: "warning"   
          }, 
           function() 
          {
                    window.location = "purchaseorder_viewup.php";
            });
         }, 1000);
       </script>';       
 }
  else
  {
   
      echo '<script>        
        setTimeout(function() {
        swal({  
                    title: "Success!",
                    text: "Purchase Order Status Updated Successfully",
                    type: "success"   
          }, 
           function() 
          {
                   window.location = "purchaseorder_viewup.php";
            });
         }, 1000);
       </script>';           
  } 
}

}  
?>

<!--add info for hod -->

<?php
if(isset($_POST['addmore']))
{
$uid=$_SESSION['id'];
$name=$_SESSION['fullName'];
$department=$_SESSION['department'];
$devid=$_POST['devid'];

$remark=$_POST['addmoreinfo'];
$remark=htmlspecialchars($remark,ENT_QUOTES);

date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt2=date("Y-m-d h:i:s");

$sqlv=mysql_query("update purchaseorder_reg set hodstatus='Initiated',hodremark='$remark' where pono='$devid'");

$sql1=mysql_query("insert into purchaseorder_hodapproval(pono,hodstatus,hodremark,remarkdate,remarkby,remarkid,department) values('$devid','Add Info','$remark','$dt2','$name','$uid','$department')");

if($sqlv=="")
{
echo '<script>        
setTimeout(function() {
swal({  
title: "Oops...!!!",
text: "Something went wrong",
type: "warning"   
}, 
function() 
{
window.location = "purchaseorder_viewup.php";
});
}, 1000);
</script>';   
}
else
{
echo '<script>        
setTimeout(function() {
swal({  
title: "Success!",
text: "Additional Remark Updated successfully",
type: "success"   
}, 
function() 
{
window.location = "purchaseorder_viewup.php";
});
}, 1000);
</script>';    
}  

}
?>

<!-- add more info for management-->
<?php
if(isset($_POST['addmore_mgmt']))
{
$uid=$_SESSION['id'];
$name=$_SESSION['fullName'];
$department=$_SESSION['department'];

$devid=$_POST['devid'];

$remark=$_POST['addmoreinfo_mgmt'];
$remark=htmlspecialchars($remark,ENT_QUOTES);

date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt2=date("Y-m-d h:i:s");

$sqlv=mysql_query("update purchaseorder_reg set mgmt_status='Initiated',mgmt_remark='$remark' where pono='$devid'");

$sql1=mysql_query("insert into purchaseorder_mgmtapproval(pono,	mgmtstatus,	mgmtremark,remarkdate,remarkby,remarkid,department) values('$devid','Add Info','$remark','$dt2','$name','$uid','$department')");


if($sqlv=="")
{
echo '<script>        
setTimeout(function() {
swal({  
title: "Oops...!!!",
text: "Something went wrong",
type: "warning"   
}, 
function() 
{
window.location = "purchaseorder_viewup.php";
});
}, 1000);
</script>';   
}
else
{
echo '<script>        
setTimeout(function() {
swal({  
title: "Success!",
text: "Additional Remark Updated successfully",
type: "success"   
}, 
function() 
{
window.location = "purchaseorder_viewup.php";
});
}, 1000);
</script>';    
}  

}
?>



<?php
$timezone = 'Asia/Manila';
date_default_timezone_set($timezone);
$today = date('d-m-Y');
$year = date('Y');
if(isset($_GET['year'])){
$year = $_GET['year'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" type="image/png" sizes="16x16" href="OTlogo.png">
<title>ESM | Purchase Order</title>
<link rel="stylesheet" href="main/js/jquery-ui.css">
<script src="main/js/jquery-1.12.4.js"></script>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/plugins/html5-editor/bootstrap-wysihtml5.css">
<!-- This page css -->
<!-- <link href="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" /> -->
<link href="assets/plugins/switchery/dist/switchery.min.css" rel="stylesheet" />
<!-- <link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" /> -->
<link href="assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" />
<link href="assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />

<!-- datatable css-->
<link href="assets/datatables/css/dataTables.bootstrap4.min.css" rel="stylesheet">
<link href="assets/datatables/css/buttons.bootstrap4.min.css" rel="stylesheet">
<link href="assets/datatables/css/jquery.dataTables.css" rel="stylesheet" type="text/css" />
<link href="assets/datatables/css/fixedHeader.dataTables.min.css" rel="stylesheet" />
<link href="assets/datatables/css/select.dataTables.min.css" rel="stylesheet">

<!-- End - This is for export functionality only -->
<link href="main/css/style.css" rel="stylesheet">
<link href="main/css/colors/blue.css" id="theme" rel="stylesheet">
<link href="assets/plugins/sweetalert/sweetalert.css">
<link href="assets/plugins/wizard/steps.css">
<!--  <script src="assets/plugins/Chart.bundle.min.js"></script> -->
<script src="main/js/jquery-ui.js"></script>
<script src="jquery.min.js"></script>
<link href="sweetalert.css" rel="stylesheet" />
<script src="sweetalert.min.js"></script>
<script src="assets/Chart.min.js"></script>
<!--  <script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet">


<style>
div.scrollmenu 
{
overflow: auto;
}
.form-control 
{
font-size:small;
}
@import url('fontawesome.min.css');
.panel-title > a:before {
float: right !important;
font-family: FontAwesome;
content:"\f068";
padding-right: 5%;
}
.panel-title > a.collapsed:before {
float: right !important;
content:"\f067";
}
.panel-title > a:hover, 
.panel-title > a:active, 
.panel-title > a:focus  {
text-decoration:none;
}
.fa option {

font-weight: 900;
}
.fa-share-square  {
font-family: 'FontAwesome', 'Poppins';
font-weight: 400;
}
@import url('fontawesome.min.css');
.fontawesome-select {
font-family: 'FontAwesome', 'Poppins';
font-weight: 900;
}

td{

color:#2C3E50;
}

/* machine status active/deactive buttons colors*/
.act { color:#0F0; }
.deact { color:#F00;}

div.container {
width: 80%;
}

/*printing text wordwrap*/
table {
table-layout:auto;
}
table td {
word-wrap: break-word;
white-space:inherit;
font-size:11px;
vertical-align: middle;
text-align: center;
}
table th {
word-wrap: break-word;
font-size:11px;
vertical-align: middle;
text-align: center;
}

#example {
table-layout: auto;
/*width: 100% !important;*/
}
/* word wrapping content of td*/
#example td, #example th {
vertical-align: middle;
text-align: center;
/*width: auto !important;*/
white-space: normal;
text-overflow: ellipsis;
overflow: hidden;
}


/* Datatables Column Filter with search background same as table header color */
table thead th {
    background-color: #1976D2;
}


/*locating tools button*/
#tools {
margin-left: 88%;
margin-top: 10px;
}
thead input {
width: 100%;
font-size: smaller;
}
/*table resizing according to page view and tableheader background color*/
table {border-collapse:collapse; table-layout:fixed; width:100%;}
table td {border:solid 1px #fab; width:100px; word-wrap:none;}
table.dataTable thead .sorting, table.dataTable thead .sorting_asc, table.dataTable thead .sorting_desc, table.dataTable thead .sorting_asc_disabled, table.dataTable thead .sorting_desc_disabled {
background: #1976d2;
color: white;
margin-top: 20px;
vertical-align: inherit;

}
table.dataTable thead th, table.dataTable tfoot th {
font-weight: 500;
}

/*To maintain space between its content and border*/
table.dataTable thead>tr>th.sorting_asc, table.dataTable thead>tr>th.sorting_desc, table.dataTable thead>tr>th.sorting, table.dataTable thead>tr>td.sorting_asc, table.dataTable thead>tr>td.sorting_desc, table.dataTable thead>tr>td.sorting {
padding-right: inherit;
} 

.dt-buttons .dt-button:hover {
background: indianred;
}

/* background and textcolor for datable tools button*/
a.dt-button.dropdown-item{
background-color: #1976d2;
color:white;
}
a.dt-button.buttons-columnVisibility.active{
background-color: #1976d2;
color:white;
}
a.dt-button.buttons-columnVisibility{
background-color: white ;
color: #333;
}
/* column visibility title background : 'Select Columns to Display'*/
div.dt-button-collection div.dt-button-collection-title {
background-color: indianred;
border: 1px solid rgba(0,0,0,0.15);
border-radius: 0.25rem;
color: white;
width: 560px;
font-size: small;
font-family:Poppins, sans-serif;
font-size:16px;
font-weight:400;
height:auto;
}

/* Table Header break line(<br>) in print */
table.dataTable thead th, table.dataTable tfoot th {
font-weight: 500;
white-space: inherit;
}
/* Table Header margin-left 3px in print */
table.dataTable thead th, table.dataTable thead th {
padding: 10px 3px;
border-bottom: 1px solid #111111; 
}

table.dataTable tbody td {
word-break: break-word;
vertical-align: top;
}

.card-body
{
border-radius: 5px;
}

</style>
<style>
/*--------------------------page-table-content-----------------------------*/

.page-wrapper .page-content {
display: inline-block;
width: 100%;
padding-left: 0px;
padding-top: 20px;
overflow-x: hidden;
flex: auto;
}

.page-wrapper .page-content> div {
padding: 5px 20px;
}
</style>

<!-- style for footer-->
<style type="text/css">
footer div.spanclass{
font-size: small;
}
</style>
<style type="text/css">
[type=checkbox]:checked + label:before {

width: 6px;
height: 10px;

margin-top: 10px;
}
label {
margin-bottom: .0rem;
}</style>
</head>

<body class="fix-header fix-sidebar card-no-border">
<div id="main-wrapper" class="scrollmenu" style="font-size:small">
<?php include("includes/config.php");?>
<?php include("includes/header.php");?>
<?php include("includes/sidebar.php");?>
<div class="page-wrapper">
<div class="row page-titles m-b-0 " style="height:45px">
<div class="col-md-5 align-self-center">
<h4 class="text-themecolor">Purchase Order</h4>
</div>
<div class="col-md-7 align-self-center">
<ol class="breadcrumb">
<li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
<li class="breadcrumb-item"><a href="purchaseorder_viewup.php">Purchase Order</a></li>
<li class="breadcrumb-item active">View / Update</li>
</ol>
</div>
</div>
<div class="row">
<div class="col-md-12" style="background-color:#F0F0F0">
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true"><br>
<div class="panel panel-default">
<div class="panel-heading" role="tab" id="headingTwo" style="height:30px">
<h5 class="panel-title" style="margin-left:2.5%">Local Dashboard
</h5>
</div>
<div style="background-color:white" id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
<div class="panel-body">
<div class="mega-dropdown-menu row">
<div class="col-lg-4">
</div>
<br><br><br>
<div class="col-sm-1">
</div>
</div>
<br>
<br>
</div>
</div>
</div>
</div>
</div>
</div>
<br>
<div class="container-fluid"> 
<div class="row">
<div class="col-12">
<div class="card">
<div class="card-body">
<!-- Nav tabs -->




<!-- settings start-->
<?php 
$queryacc=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($rowacc=mysql_fetch_array($queryacc)) 
{
?> 
<ul class="nav nav-tabs" role="tablist">
<?php
$query21=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($row21=mysql_fetch_array($query21)) 
{  
$complaintarr1=$row21['purchaseorderaccess'];
$comarr1=explode(',',trim( $complaintarr1));
$secondaryarr1=$row21['multidept'];
$secarr2=explode(',',trim($secondaryarr1));
//to remove last comma from multidept array
$lastcomma = '';
foreach($secarr2 as $i=>$k) 
{
$lastcomma .= $k.',';
}
$lastcomma = rtrim($lastcomma,',');
$secarr1=explode(',',trim($lastcomma));
$querydays1=mysql_query("select * from purchaseorder_setting order by id desc limit 1");
while($rowdays1=mysql_fetch_array($querydays1)) 
{ 
$quadept1=$rowdays1['po_regdept'];
$qua1=explode(',',trim($quadept1));
$result1 = array_intersect($secarr1,$qua1);
if((($result1!=array())||(in_array($row21['department'],$qua1))) && (in_array('regpurchaseorder',$comarr1)))
{  ?>

<?php $query1=mysql_query("select * from master order by id desc limit 1");
while($row1=mysql_fetch_array($query1))
{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt3=date("Y-m-d h:i");
if($row1['licend']<= $dt3) 
{ ?>
<li class="nav-item"><a class="nav-link"  onclick="myFunctionstatus()" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span><span class="hidden-xs-down">Register</span></a></li> 
<?php } 
else
{ ?>
<li class="nav-item"><a class="nav-link" href="purchaseorder_register.php" role="tab"><span class="hidden-sm-up"><i class="ti-email"></i></span> <span class="hidden-xs-down"> Register &nbsp;<b>
</b></span></a> 
</li>
<?php } 
} 

}else{

} } } ?>

<?php   
$inhousecomarr=$rowacc['purchaseorderaccess'];
$inhousearr=explode(',',trim( $inhousecomarr));
if(in_array('viewpurchaseorder',$inhousearr))
{ ?>
<?php $query1=mysql_query("select * from master order by id desc limit 1");
while($row1=mysql_fetch_array($query1))
{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt3=date("Y-m-d h:i:s");
if($row1['licend']<= $dt3) 
{
?>
<li class="nav-item"><a class="nav-link active" onclick="myFunctionstatus()" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span><span class="hidden-xs-down">View/Update</span></a></li> 
<?php } 
else
{ ?>
<li class="nav-item"><a class="nav-link active" href="purchaseorder_viewup.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">View/Update</span></a> </li>
<?php } 
} ?>

<?php
} else{

} 
?>

<?php $companymaster=$rowacc['addmanageaccess'];
$compaarr=explode(',',trim($companymaster));
if(in_array('generalmanage',$compaarr))
{?>
<li class="nav-item"> <a class="nav-link"  href="purchaseorder_setting.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Settings</span></a> </li>
<?php } } ?>  
</ul>
<!--settings end --> 




<?php   
$queryde = mysql_query("SELECT * FROM purchaseorder_setting");
$numberde=mysql_num_rows($queryde);
if ( $numberde== '0' ) 
{ ?>
<h5>To view the Purchase Order List please Go to Settings and set the Department for Purchase Order or Contact to Admin</h5>

<?php }

else
{ ?>


<div class="tab-content tabcontent-border">
<div class="tab-pane active" id="home" role="tabpanel">
<br>
</div>
<!-- To take the datatable buttons outside-->


<div id="tools"></div>

<div> 
<table id="example" cellpadding="0" cellspacing="0" border="0" class=" table table-bordered table-striped display" style="width:100%">
<thead>
<tr>
<th style="font-size:10px;" title="Sl No.">Sl<br>No.</th>
<th style="font-size:10px;" title="Invoice No.">PO<br>No.</th>
<th style="font-size:10px;" title="Supplier Name">Supplier Name</th>
<th style="font-size:10px;" title="Part Name[Drawing No.]">Part Name<br>[Dwg No.]</th>
<th style="font-size:10px;" title="Required Quantity">Req<br>Qty</th>
<th style="font-size:10px;" title="Shortage By">Shortage By</th>
<th style="font-size:10px;" title="PO Qty">PO<br>Qty</th>
<th style="font-size:10px;" title="Delivery Date">Delivery<br>Date</th>
<th style="font-size:10px;" title="Purchased Qty">Purchased<br>Qty</th>
<th style="font-size:10px;" title="Rejected Qty">Rej<br>Qty</th>
<th style="font-size:10px;" title="Purchase %">Purchase %</th>
<th style="font-size:10px;" title="Rej[ppm]">Rej<br>[ppm]</th>
<th style="font-size:10px;" title="Item Remark">Remark</th>
<th style="font-size:10px;width:75px;" title="Order Status">Order<br>Status</th>
<th style="font-size:10px;" title="Priority[Commitment Date]">Priority<br>[Commitment Date]</th>
<th style="font-size:10px;width:75px;" title="HOD Status">HOD<br>Status</th>
<th style="font-size:10px;width:75px;" title="Management Status">MGMT<br>Status</th>
</tr>
</thead>
<tbody>

<?php 
$query=mysql_query("select * from purchaseorder_reg order by id desc");
while($row=mysql_fetch_array($query))
{   

?>
<tr>
<td>
  <?php echo htmlentities($row['id']);?></td>
<td><a href="purchaseorder_view.php?cid=<?php echo htmlentities($row['pono']);?>" style="font-size:10px;font-weight:450"><?php echo htmlentities($row['pono']);?><br></a>[<?php echo htmlentities($row['podate']);?>]
</td>
<td><?php echo htmlentities($row['suppliername']);?></td>
<td>
<?php echo htmlspecialchars_decode($row['partname']);?>
[<?php echo htmlspecialchars_decode($row['drawingno']);?>]
</td>
<td>
<?php echo htmlspecialchars_decode($row['reqqty']);?></td>
<td>
<?php echo htmlspecialchars_decode($row['shortageby']);?></td> 
<td>
<?php echo htmlspecialchars_decode($row['poqty']);?>
</td> 
<td>
<?php echo htmlspecialchars_decode($row['deliverydate']);?>
</td>
<td>
<?php echo htmlspecialchars_decode($row['purchasedqty']);?>
</td>
<td>
<?php echo htmlspecialchars_decode($row['pendingqty']);?>
</td>
<td>
<?php 
if($row['purchase_percent']>'0')
{
echo htmlspecialchars_decode($row['purchase_percent'])."%";
}
?>
</td>
<td>
rej ppm
</td>
<td>
<a href="purchaseorder_viewremark.php?cid=<?php echo htmlentities($row['id']);?>" class='li-modal' style="color:blue">View</a>
<div id="theModal" class="modal fade text-center">
<div class="modal-dialog">
<div class="modal-content">
</div>
</div>
</div>
</td>
  <td style="font-size:11px;">
  <?php   
  $orderstatus=$row['orderstatus'];
  if($orderstatus=='Open')
  {
  ?>
  <button class="btn" style="font-size:9px;background-color:#F38330;padding:4px;"><a style="color:white"><?php echo htmlentities($row['orderstatus']);?></a></button>
  <?php 
  } 
  if($orderstatus=='Completed')
  {
  ?> 
  <button class="btn" style="font-size:9px;background-color:#006400;padding:4px;"><a style="color:white"><?php echo htmlentities($row['orderstatus']);?></a></button>
  <?php 
  }
    if($orderstatus=='On Hold')
  {
  ?> 
  <button class="btn" style="font-size:9px;background-color:#ffc125;padding:4px;"><a style="color:white"><?php echo htmlentities($row['orderstatus']);?></a></button>
  <?php 
  }
    if($orderstatus=='Short Closed')
  {
  ?> 
  <button class="btn" style="font-size:9px;background-color:#00c851;padding:4px;"><a style="color:white"><?php echo htmlentities($row['orderstatus']);?></a></button>
  <?php 
  }
    if($orderstatus=='Cancelled')
  {
  ?> 
  <button class="btn" style="font-size:9px;background-color:#ff4444;padding:4px;"><a style="color:white"><?php echo htmlentities($row['orderstatus']);?></a></button>
  <?php 
  }

?>
<br>
<a href="purchaseorder_orderstatus.php?cid=<?php echo htmlentities($row['id']);?>" class='li-modal' style="color:blue">Edit</a>
<div id="theModal" class="modal fade text-center">
<div class="modal-dialog">
<div class="modal-content">
</div>
</div>
</div>
  </td>
<td>
<?php echo htmlentities($row['priority']);?>
<?php
if($row['statusdate']!="")
{ ?>
[<?php echo htmlentities($row['statusdate']);?>]
<?php } ?>
</td>


<!--Dept check for hod start-->
<?php 
$queryacc=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($rowacc=mysql_fetch_array($queryacc)) 
{
?> 
<?php
$query21=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($row21=mysql_fetch_array($query21)) 
{  
$complaintarr1=$row21['purchaseorderaccess'];
$comarr1=explode(',',trim( $complaintarr1));
$secondaryarr1=$row21['multidept'];
$secarr2=explode(',',trim($secondaryarr1));
//to remove last comma from multidept array
$lastcomma = '';
foreach($secarr2 as $i=>$k) 
{
$lastcomma .= $k.',';
}
$lastcomma = rtrim($lastcomma,',');
$secarr1=explode(',',trim($lastcomma));
$querydays1=mysql_query("select * from purchaseorder_setting order by id desc limit 1");
while($rowdays1=mysql_fetch_array($querydays1)) 
{ 
$quadept1=$rowdays1['approvebyhod'];
$qua1=explode(',',trim($quadept1));
$result1 = array_intersect($secarr1,$qua1);
if((($result1!=array())||(in_array($row21['department'],$qua1))) && (in_array('takeactionpurchaseorder',$comarr1)) && ($rowdays1['hod_approve']=='Yes'))
{  
//  if($rowdays1['hod_approve']=='Yes')
// { ?>

<td>
<?php   
$statusdis2=$row['hodstatus'];
if(($statusdis2=="")||($statusdis2=="Initiated"))
{
?>
<button class="btn" style="font-size:9px;background-color:#D35400;padding:4px;"><a href="purchaseorder_hodview.php?cid=<?php echo htmlentities($row['pono']);?>"style="color:white">Initiated</a></button>
<?php 
} 
$statusdis2=$row['hodstatus'];
if($statusdis2=='Approved')
{
?>
<button class="btn" style="font-size:9px;background-color:#006600;padding:4px;"><a href="purchaseorder_hodview.php?cid=<?php echo htmlentities($row['pono']);?>" style="color:white;">Approved</a></button>
<?php 
} 
if($statusdis2=='Need More Info')
{
?> 
<button class="btn" style="font-size:9px;background-color:#0d47a1;padding:4px;"><a style="color:white" href="purchaseorder_hodview.php?cid=<?php echo htmlentities($row['pono']);?>">Need Info</a></button>
<a href="purchaseorder_hodaddinfo.php?cid=<?php echo htmlentities($row['pono']);?>" class='li-modal' style="color:white"><button class="btn-primary" style="font-size:7px;border:none">ADD</button></a>
<div id="theModal" class="modal fade text-center">
<div class="modal-dialog">
<div class="modal-content">
</div>
</div>
</div>

<?php 
}
if($statusdis2=='Reject')
{
?> 
<button class="btn" style="font-size:9px;background-color:#cc0000;padding:4px;"><a style="color:white" href="purchaseorder_hodview.php?cid=<?php echo htmlentities($row['pono']);?>">Rejected</a></button>
<?php 
}

?>
</td>


<?php 
 }else
{ ?>

<td>
<?php   
$statusdis2=$row['hodstatus'];
if(($statusdis2=="")||($statusdis2=="Initiated"))
{
?>
<button class="btn" style="font-size:9px;background-color:#D35400;padding:4px;"><a onclick="hod_deptcheck()" style="color:white">Initiated</a></button>
<?php 
} 
$statusdis2=$row['hodstatus'];
if($statusdis2=='Approved')
{
?>
<button class="btn" style="font-size:9px;background-color:#006600;padding:4px;"><a onclick="hod_deptcheck()" style="color:white;">Approved</a></button>
<?php 
} 
if($statusdis2=='Need More Info')
{
?> 
<button class="btn" style="font-size:9px;background-color:#0d47a1;padding:4px;"><a style="color:white" onclick="hod_deptcheck()">Need Info</a></button>
<a href="purchaseorder_hodaddinfo.php?cid=<?php echo htmlentities($row['pono']);?>" class='li-modal' style="color:white"><button class="btn-primary" style="font-size:7px;border:none">ADD</button></a>
<div id="theModal" class="modal fade text-center">
<div class="modal-dialog">
<div class="modal-content">
</div>
</div>
</div>

<?php 
}
if($statusdis2=='Reject')
{
?> 
<button class="btn" style="font-size:9px;background-color:#cc0000;padding:4px;"><a style="color:white" onclick="hod_deptcheck()">Rejected</a></button>
<?php 
}

?>
</td>

<?php } } } } ?>

<!--Dept check for hod end-->

<!--MGMT check for hod start-->
<?php 
$queryacc=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($rowacc=mysql_fetch_array($queryacc)) 
{
?> 
<?php
$query21=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($row21=mysql_fetch_array($query21)) 
{  
$complaintarr1=$row21['purchaseorderaccess'];
$comarr1=explode(',',trim( $complaintarr1));
$secondaryarr1=$row21['multidept'];
$secarr2=explode(',',trim($secondaryarr1));
//to remove last comma from multidept array
$lastcomma = '';
foreach($secarr2 as $i=>$k) 
{
$lastcomma .= $k.',';
}
$lastcomma = rtrim($lastcomma,',');
$secarr1=explode(',',trim($lastcomma));
$querydays1=mysql_query("select * from purchaseorder_setting order by id desc limit 1");
while($rowdays1=mysql_fetch_array($querydays1)) 
{ 
$quadept1=$rowdays1['approvebymgmt'];
$qua1=explode(',',trim($quadept1));
$result1 = array_intersect($secarr1,$qua1);
if((($result1!=array())||(in_array($row21['department'],$qua1))) && (in_array('takeactionpurchaseorder',$comarr1)) && ($rowdays1['mgmt_approve']=='Yes'))
{  
//  if($rowdays1['hod_approve']=='Yes')
// { 
if($rowdays1['hod_approve']=='Yes')
{ ?>

<td>
<?php   
$statusdis2=$row['mgmt_status'];
$statusdis3=$row['hodstatus'];
if(($statusdis2=="")||($statusdis2=="Initiated"))
{
if($statusdis3=='Reject')
{ ?>

<button class="btn" style="font-size:9px;background-color:#D35400;padding:4px;"><a onclick="hod_reject()" style="color:white">Initiated</a></button>
<?php }
else if($statusdis3=='Need More Info')
{ ?>
<button class="btn" style="font-size:9px;background-color:#D35400;padding:4px;"><a onclick="hod_needinfo()" style="color:white">Initiated</a></button>
<?php }
else
{ ?>
<button class="btn" style="font-size:9px;background-color:#D35400;padding:4px;"><a href="purchaseorder_mgmtview.php?cid=<?php echo htmlentities($row['pono']);?>"style="color:white">Initiated</a></button>
<?php } }

//if approved 
if($statusdis2=='Approved')
{
if($statusdis3=='Reject')
{ ?>
<button class="btn" style="font-size:9px;background-color:#D35400;padding:4px;"><a onclick="hod_reject()" style="color:white">Initiated</a></button>
<?php }
else if($statusdis3=='Need More Info')
{ ?>
<button class="btn" style="font-size:9px;background-color:#D35400;padding:4px;"><a onclick="hod_needinfo()" style="color:white">Initiated</a></button>
<?php }
else
{ ?>
  <button class="btn" style="font-size:9px;background-color:#006600;padding:4px;"><a href="purchaseorder_mgmtview.php?cid=<?php echo htmlentities($row['pono']);?>" style="color:white">Approved</a></button>
<?php } } 

//need info
if($statusdis2=='Need More Info')
{
if($statusdis3=='Reject')
{ ?>
<button class="btn" style="font-size:9px;background-color:#D35400;padding:4px;"><a onclick="hod_reject()" style="color:white">Initiated</a></button>
<?php }
else if($statusdis3=='Need More Info')
{ ?>
<button class="btn" style="font-size:9px;background-color:#D35400;padding:4px;"><a onclick="hod_needinfo()" style="color:white">Initiated</a></button>
<?php }
else
{ ?>
<button class="btn" style="font-size:9px;background-color:#0d47a1;padding:4px;"><a style="color:white" href="purchaseorder_mgmtview.php?cid=<?php echo htmlentities($row['pono']);?>">Need Info</a></button>
<a href="purchaseorder_mgmtaddinfo.php?cid=<?php echo htmlentities($row['pono']);?>" class='li-modal' style="color:white"><button class="btn-primary" style="font-size:7px;border:none">ADD</button></a>
<div id="theModal" class="modal fade text-center">
<div class="modal-dialog">
<div class="modal-content">
</div>
</div>
</div>
<?php } }

//reject
if($statusdis2=='Reject')
{
if($statusdis3=='Reject')
{ ?>
<button class="btn" style="font-size:9px;background-color:#D35400;padding:4px;"><a onclick="hod_reject()" style="color:white">Initiated</a></button>
<?php }
else if($statusdis3=='Need More Info')
{ ?>
<button class="btn" style="font-size:9px;background-color:#D35400;padding:4px;"><a onclick="hod_needinfo()" style="color:white">Initiated</a></button>
<?php }
else
{ ?>
  <button class="btn" style="font-size:9px;background-color:#cc0000;padding:4px;"><a style="color:white" href="purchaseorder_mgmtview.php?cid=<?php echo htmlentities($row['pono']);?>">Rejected</a></button>
<?php } } ?>
</td>

<?php } // if hod_approve==yes closing

else
{ ?>

<td>
<?php   
$statusdis2=$row['mgmt_status'];
if(($statusdis2=="")||($statusdis2=="Initiated"))
{
?>
<button class="btn" style="font-size:9px;background-color:#D35400;padding:4px;"><a href="purchaseorder_mgmtview.php?cid=<?php echo htmlentities($row['pono']);?>"style="color:white">Initiated</a></button>
<?php 
} 
$statusdis2=$row['mgmt_status'];
if($statusdis2=='Approved')
{
?>
<button class="btn" style="font-size:9px;background-color:#006600;padding:4px;"><a href="purchaseorder_mgmtview.php?cid=<?php echo htmlentities($row['pono']);?>" style="color:white">Approved</a></button>
<?php 
} 
if($statusdis2=='Need More Info')
{
?> 
<button class="btn" style="font-size:9px;background-color:#0d47a1;padding:4px;"><a style="color:white" href="purchaseorder_mgmtview.php?cid=<?php echo htmlentities($row['pono']);?>">Need Info</a></button>
<a href="purchaseorder_mgmtaddinfo.php?cid=<?php echo htmlentities($row['pono']);?>" class='li-modal' style="color:white"><button class="btn-primary" style="font-size:7px;border:none">ADD</button></a>
<div id="theModal" class="modal fade text-center">
<div class="modal-dialog">
<div class="modal-content">
</div>
</div>
</div>

<?php 
}
if($statusdis2=='Reject')
{
?> 
<button class="btn" style="font-size:9px;background-color:#cc0000;padding:4px;"><a style="color:white" href="purchaseorder_mgmtview.php?cid=<?php echo htmlentities($row['pono']);?>">Rejected</a></button>
<?php 
}

?>
</td>
<?php } ?>

<?php 
 } //main if block of dept check closing
else
{ ?>

<td>
<?php   
$statusdis2=$row['mgmt_status'];
if(($statusdis2=="")||($statusdis2=="Initiated"))
{
?>
<button class="btn" style="font-size:9px;background-color:#D35400;padding:4px;"><a onclick="mgmt_deptcheck()" style="color:white">Initiated</a></button>
<?php 
} 
$statusdis2=$row['mgmt_status'];
if($statusdis2=='Approved')
{
?>
<button class="btn" style="font-size:9px;background-color:#006600;padding:4px;"><a onclick="mgmt_deptcheck()" style="color:white">Approved</a></button>
<?php 
} 
if($statusdis2=='Need More Info')
{
?> 
<button class="btn" style="font-size:9px;background-color:#0d47a1;padding:4px;"><a style="color:white" onclick="mgmt_deptcheck()">Need Info</a></button>
<a href="purchaseorder_mgmtaddinfo.php?cid=<?php echo htmlentities($row['pono']);?>" class='li-modal' style="color:white"><button class="btn-primary" style="font-size:7px;border:none">ADD</button></a>
<div id="theModal" class="modal fade text-center">
<div class="modal-dialog">
<div class="modal-content">
</div>
</div>
</div>

<?php 
}
if($statusdis2=='Reject')
{
?> 
<button class="btn" style="font-size:9px;background-color:#cc0000;padding:4px;"><a style="color:white" onclick="mgmt_deptcheck()">Rejected</a></button>
<?php 
}

?>
</td>

<?php } } } } ?>

<!--MGMT check for hod end-->




</tr>

<?php } ?>
</tbody>

</table>
</div>
<br> <?php } ?>
</div>
<br>
<?php 
$setting=mysql_query("select * from purchaseorder_setting limit 1");
while($rowset=mysql_fetch_array($setting))
{ 
?>
<hr style="background-color:lightgray">
<div class="row">
<label style="color:black;margin-left:15px"></label><span style="color:black;font-weight:bold;"><?php echo htmlspecialchars_decode($rowset['isoformatno']);?></span>
<label style="color:black;">&nbsp;|&nbsp;Rev. No.</label>&nbsp;<span style="color:black;font-weight:bold;"><?php echo htmlspecialchars_decode($rowset['isoformatrevno']);?></span>
</div>
<?php  } ?> 

</div><!-- /content-panel -->

</div><!-- /col-lg-4 -->
</div><!-- /row -->


</div>
</div>
</div>
</div>

<?php 
include("includes/footer.php");
?>

<script src="assets/plugins/jquery/jquery.min.js"></script>
<script src="main/js/jquery-ui.js"></script>
<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="main/js/jquery.slimscroll.js"></script>
<script src="main/js/waves.js"></script>
<script src="main/js/sidebarmenu.js"></script>
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<script src="main/js/custom.min.js"></script>
<script src="assets/plugins/chartist-js/dist/chartist.min.js"></script>
<script src="assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
<script src="assets/plugins/raphael/raphael-min.js"></script>
<script src="assets/plugins/morrisjs/morris.min.js"></script>
<script src="assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
<script src="assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="assets/plugins/wizard/jquery.steps.min.js"></script>
<script src="assets/plugins/wizard/jquery.validate.min.js"></script>
<script src="assets/plugins/sweetalert/sweetalert.min.js"></script>
<script src="assets/plugins/wizard/steps.js"></script>
<script src="main/js/dashboard2.js"></script>
<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>

<!--datatable scripts-->
<script src="assets/datatables/js/jquery.dataTables.js"></script>
<script src="assets/datatables/js/dataTables.buttons.min.js"></script>
<script src="assets/datatables/js/jszip.min.js"></script>
<script src="assets/datatables/js/pdfmake.min.js"></script>
<script src="assets/datatables/js/vfs_fonts.js"></script>
<script src="assets/datatables/js/buttons.html5.min.js"></script>
<script src="assets/datatables/js/buttons.colVis.min.js"></script>
<script src="assets/datatables/js/buttons.print.min.js"></script>
<script src="assets/datatables/js/dataTables.bootstrap4.min.js"></script>
<script src="assets/datatables/js/buttons.bootstrap4.min.js"></script>
<!--fixed Header-->
<script src="assets/datatables/js/dataTables.fixedHeader.min.js"></script>


<script>
function hod_deptcheck() {
swal("Opps Sorry", "You do not have access to Take Action ","warning")
}
</script>

 <script>
function mgmt_deptcheck() {
swal("Opps Sorry", "You do not have access to Take Action ","warning")
}
</script>

<script>
function hod_reject() {
swal("Opps Sorry", "You cannot Take Action since HOD has rejected this PO","warning")
}
</script>

<script>
function hod_needinfo() {
swal("Opps Sorry", "You cannot Take Action since HOD's Approval is pending","warning")
}
</script>

<script>
function myFunctionstatus() {
swal("We are Sorry !", "Your license has expired.\n Please contact your administrator","warning")
}
</script>


<script>
$('.li-modal').on('click', function(e){
e.preventDefault();
$('#theModal').modal('show').find('.modal-content').load($(this).attr('href'));
});
</script>

<!-- Datatable Buttons and Fixedheader-->
<script>
$(document).ready(function() {
// Filter Setup - add a text input to each header cell w.r.t Fixed Header
$('#example thead tr').clone(true).appendTo('#example thead');
$('#example thead tr:eq(1) th').each(function(i) {
var title = $(this).text();
$(this).html('<input type="text" placeholder="Search" />');
$('input', this).on('keyup change', function() {
if (table.column(i).search() !== this.value) {
table.column(i).search(this.value).draw();
}
});
});
var table = $("#example").DataTable({
orderCellsTop: true,
//scrollX: true,
order: [
[0, "desc"]
],
lengthMenu: [
[10, 25, 50, 100, -1],
[10, 25, 50, 100, "All"]
],
dom: 'l<"toolbar">frtip',
// "footerCallback": function(row, data, start, end, display) {
// var api = this.api(),
// data;
// // Remove the formatting to get integer data for summation
// var intVal = function(i) {
// return typeof i === 'string' ?
// i.replace(/[\$,]/g, '') * 1 :
// typeof i === 'number' ?
// i : 0;
// };
// // Update div.toolbar with comma seperated values
// var numFormat = $.fn.dataTable.render.number('\,', '.', 2, ).display;
// // Total over all pages
// alltotal = api.column(6).data().reduce(function(a, b) {
// return intVal(a) + intVal(b);
// }, 0);
// // Total over this page
// pageTotal = api.column(6, {
// page: 'current'
// }).data().reduce(function(a, b) {
// return intVal(a) + intVal(b);
// }, 0);
// // Update footer on top betweeb DOM Elements
// $("div.toolbar").html('Sub-Total (Current View) :&nbsp;<i class="fa fa-rupee"></i>&nbsp;' + numFormat(pageTotal) + ' <br>Total RC Amount :&nbsp;<i class="fa fa-rupee"></i>&nbsp;' + numFormat(alltotal));
// },
// Update Column 6 (Monthly Increase/Reduction) to show Indian Rupees with comma seperated values.
// "columnDefs": [{
// "targets": [5, 6],
// "render": function(data, type, row) {
// return Number(data).toLocaleString('en-IN', {
// maximumFractionDigits: 2,
// style: 'currency',
// currency: 'INR'
// });
// }
// }]
});
var fixNewLine = {
exportOptions: {
format: {
body: function(data, row, column, node) {
// Strip $ from salary column to make it numeric
return column === 1, 2 ?
data.replace(/<br\s*\/?>/ig, "\n") : data;
},
header: function(data, row, column, node) {
// Strip $ from salary column to make it numeric
return column === 1, 2 ?
data.replace(/<br>/g, "\n") : data;
}
}
}
};
var buttons = new $.fn.dataTable.Buttons(table, {
buttons: [{
extend: "collection",
text: '<i class="fa fa-share-square"></i>&nbsp; Tools',
buttons: [{
extend: "print",
text: '<i class="fa fa-print"></i>&nbsp; Print',
//filename: 'customer_RC',
exportOptions: {
columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
}
},
{
extend: "copyHtml5",
text: '<i class="fa fa-copy"></i>&nbsp; Copy',
title: 'ESM | Purchase Order',
filename: 'ESM | Purchase Order',
exportOptions: {
columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
}
},
{
extend: "excelHtml5",
text: '<i class="fa fa-file-excel-o"></i>&nbsp; Excel',
title: 'ESM | Purchase Order',
filename: 'ESM | Purchase Order',
exportOptions: {
columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
}
},
{
extend: "csvHtml5",
text: '<i class="fa fa-table"></i>&nbsp; CSV',
// title: 'Customized CSV Title',
title: 'ESM | Purchase Order',
filename: 'ESM | Purchase Order',
exportOptions: {
columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
}
},
{
extend: "pdfHtml5",
orientation: 'landscape',
pageSize: 'A3',
text: '<i class="fa fa-file-pdf-o"></i>&nbsp; PDF',
title: 'ESM | Purchase Order',
filename: 'ESM | Purchase Order',
exportOptions: {
columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
stripNewlines: false
}
},
{
extend: "colvis",
text: '<i class="fa fa-barcode"></i><i class="fa fa-grip-lines-vertical"></i>&nbsp; Display Columns',
//text: 'Column Selection',
collectionLayout: "fixed two-column",
collectionTitle: "Select Columns to Display",
postfixButtons: ["colvisRestore"],
columnText: function(dt, idx, title) {
return idx + 1 + ": " + title;
}
},
{
text: '<i class="fa fa-database"></i>&nbsp; Export Database',
action: function(e, dt, button, config) {
window.location = 'purchaseorder_exportdb.php';
}
}
]
}]
}).container().appendTo($('#tools'));
new $.fn.dataTable.FixedHeader(table, {
header: true,
headerOffset: $('.topbar').height() //offset added to show tableheader just below theme header
});
//To clear the filtered value upon column-visibility button click
$('#example').on('column-visibility.dt', function(e, settings, column, state) {
console.log(
'Column ' + column + ' has changed to ' + (state ? 'visible' : 'hidden')
);
if (state) {
$('#example thead tr:eq(' + column + ') th:eq(1) input').val('')
} else {
table.columns(column).search('').draw();
}
});
//fixed header when side bar is toggled
$(".sidebartoggler").on('click', function() {
$(".page-wrapper").removeClass("toggled");
table.columns.adjust().draw();
table.draw();
});
$(".sidebartoggler").on('click', function() {
$(".page-wrapper").addClass("toggled");
table.columns.adjust().draw();
//table.draw();
});
});
</script>



<script>
$(document).ready(function() {
$('.datatable-1').dataTable();
$('.dataTables_paginate').addClass("btn-group datatable-pagination");
$('.dataTables_paginate > a').wrapInner('<span />');
});

</script>

<link rel="stylesheet" href="assets/plugins/html5-editor/bootstrap-wysihtml5.css">
</body>

</html>
