<?php 
error_reporting(E_ERROR | E_PARSE);
session_start();
if(!isset($_SESSION['id'],$_SESSION['department']))
{
header('location:index.php?lmsg=true');
exit;
}
require_once('includes/dbconfig.php');
include("includes/config.php");

?>


<?php  
//hodstatus update need info
if(isset($_POST['update1']))
{
$fullName=$_SESSION['fullName'];
$department=$_SESSION['department'];
$uid=$_SESSION['id'];

$id=$_POST['pono'];

$status=$_POST['status'];
$status=htmlspecialchars($status,ENT_QUOTES);

$needremark=$_POST['needremark'];
$needremark=htmlspecialchars($needremark,ENT_QUOTES);

date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt2=date("d-m-Y h:i:s");


$sql5=mysql_query("update purchaseorder_reg set hodstatus='$status',hodremark='$needremark',hoddept='$department',hodrmkdate='$dt2',hodrmkid='$uid',hodrmkby='$fullName' where pono='$id'");

$sql7=mysql_query("insert into purchaseorder_hodapproval(pono,hodstatus,hodremark,remarkdate,remarkby,remarkid,department)values('$id','$status','$needremark','$dt2','$fullName','$uid','$department')");


if($sql5=="")    
{
echo '<script>        
setTimeout(function() {
swal({  
title: "warning",
text: "something went wrong",
type: "warning"   
}, 
function() 
{
window.location = "purchaseorder_hodview.php?cid="+"'.$_GET['cid'].'";
});
}, 1000);
</script>';       

}
else 
{
echo '<script>        
setTimeout(function() {
swal({  
title: "Success!",
text: "Purchase Order HOD Approval Status and remark Updated Successfully",
type: "success"   
}, 
function() 
{
window.location = "purchaseorder_viewup.php";
});
}, 1000);
</script>';     
}
}
else
{

} ?>


<?php  
//hodstatus update approved
if(isset($_POST['update2']))
{
$fullName=$_SESSION['fullName'];
$department=$_SESSION['department'];
$uid=$_SESSION['id'];
$id=$_POST['pono'];
$status=$_POST['status'];
$status=htmlspecialchars($status,ENT_QUOTES);
$approveremark=$_POST['approveremark'];
$approveremark=htmlspecialchars($approveremark,ENT_QUOTES);
date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt2=date("d-m-Y h:i:s");

$sql51=mysql_query("update purchaseorder_reg set hodstatus='$status',hodremark='$approveremark',hoddept='$department',hodrmkdate='$dt2',hodrmkid='$uid',hodrmkby='$fullName' where pono='$id'");

$sql7=mysql_query("insert into purchaseorder_hodapproval(pono,hodstatus,hodremark,remarkdate,remarkby,remarkid,department)values('$id','$status','$approveremark','$dt2','$fullName','$uid','$department')");



if($sql7=="")    
{
echo '<script>        
setTimeout(function() {
swal({  
title: "warning",
text: "something went wrong",
type: "warning"   
}, 
function() 
{
window.location = "purchaseorder_hodview.php?cid="+"'.$_GET['cid'].'";
});
}, 1000);
</script>';       

}
else 
{
echo '<script>        
setTimeout(function() {
swal({  
title: "Success!",
text: "Purchase Order HOD Approval Status and remark Updated Successfully",
type: "success"   
}, 
function() 
{
window.location = "purchaseorder_viewup.php";
});
}, 1000);
</script>';     
}
}
else
{

} ?>

<?php  
//hodstatus update reject
if(isset($_POST['update3']))
{
$fullName=$_SESSION['fullName'];
$department=$_SESSION['department'];
$uid=$_SESSION['id'];
$id=$_POST['pono'];
$status=$_POST['status'];
$status=htmlspecialchars($status,ENT_QUOTES);
$rejectremark=$_POST['rejectremark'];
$rejectremark=htmlspecialchars($rejectremark,ENT_QUOTES);
date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt2=date("d-m-Y h:i:s");

$sql51=mysql_query("update purchaseorder_reg set hodstatus='$status',hodremark='$rejectremark',hoddept='$department',hodrmkdate='$dt2',hodrmkid='$uid',hodrmkby='$fullName' where pono='$id'");

$sql7=mysql_query("insert into purchaseorder_hodapproval(pono,hodstatus,hodremark,remarkdate,remarkby,remarkid,department)values('$id','$status','$rejectremark','$dt2','$fullName','$uid','$department')");



if($sql7=="")    
{
echo '<script>        
setTimeout(function() {
swal({  
title: "warning",
text: "something went wrong",
type: "warning"   
}, 
function() 
{
window.location = "purchaseorder_hodview.php?cid="+"'.$_GET['cid'].'";
});
}, 1000);
</script>';       

}
else 
{
echo '<script>        
setTimeout(function() {
swal({  
title: "Success!",
text: "Purchase Order HOD Approval Status and remark Updated Successfully",
type: "success"   
}, 
function() 
{
window.location = "purchaseorder_viewup.php";
});
}, 1000);
</script>';     
}
}
else
{

} ?>



<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" type="image/png" sizes="16x16" href="OTlogo.png">
<title>ESM | Purchase Order</title>
<title>ESM | Purchase Order</title>
<link rel="icon" type="image/png" sizes="16x16" href="OTlogo.png">  
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<!-- <link rel="stylesheet" href="/resources/demos/style.css"> -->
<link href="assets/plugins/wizard/steps.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>   
<script src="main/js/jquery-1.12.4.js"></script>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/plugins/html5-editor/bootstrap-wysihtml5.css" >
<!-- This page css -->
<link href="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="assets/plugins/switchery/dist/switchery.min.css"rel="stylesheet" />
<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" />
<link href="assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" />
<link href="assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css" />
<!--- -->
<link href="assets/plugins/chartist-js/dist/chartist.min.css" rel="stylesheet">
<link href="assets/plugins/chartist-js/dist/chartist-init.css" rel="stylesheet">
<link href="assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.css" rel="stylesheet">
<link href="assets/plugins/morrisjs/morris.css" rel="stylesheet">
<link href="assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
<link href="main/css/style.css" rel="stylesheet">
<link href="main/css/colors/blue.css" id="theme" rel="stylesheet">
<link href="assets/plugins/sweetalert/sweetalert.css">
<script src="main/js/jquery-ui.js"></script>
<script src="jquery.min.js"></script>
<link href="sweetalert.css" rel="stylesheet" />
<script src="sweetalert.min.js"></script>
<script src="assets/Chart.min.js"></script>

<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.7/angular.min.js"></script>


<!-- scripts for auto save -->
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jsgrid/1.5.3/jsgrid.min.css" />
<link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jsgrid/1.5.3/jsgrid-theme.min.css" />
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jsgrid/1.5.3/jsgrid.min.js"></script> -->
<!--  scripts for auto save-->


<style>
div.scrollmenu 
{
overflow: 1;
}

form label {
color: black;
font-weight: 550;
font-size:12px;
/*margin-bottom: 0.2rem;*/
display: inline;
}


#cusdetails td
{
font-weight:400;
color: black;
font-size:12px;
vertical-align: middle;
border:none;
padding:0px;
}

#vendor td
{
font-weight:400;
color: black;
font-size:12px;
vertical-align: middle;
border:none;
padding:0px;
}

#cusdetails3 td
{
/*  border-left:solid 1px #7f7f7f;*/
border-bottom:solid 1px #7f7f7f;
font-size:10px; 
color:black;
font-weight:410;
margin-bottom: 0.1rem;
padding: 1px;
vertical-align:middle;
}

#cusdetails3 th
{
border-bottom:solid 1px #7f7f7f;
font-size:10px;
color:white;
font-weight:500;
margin-bottom: 0.1rem;
padding: 1px;
vertical-align:middle;
}

#logtable td
{
border:solid 1px #7f7f7f;
color:black;
font-weight:500;
text-align:center;
font-size:10px;
}

#logtable th
{
border:solid 1px #7f7f7f;
color:white;
font-weight:500;
text-align:center;
font-size:10px;
}

#headdet td
{
border:solid 1px lightgrey;
font-weight:400;
color: black;
font-size:11px;
padding:1px;
}
</style>

<style>
.circle {
width: 60px;
height: 60px;

font-size: 15px;
color: #fff;
text-align: center;
background:black;
}

.body{
font-family:Poppins, sans-serif;
}
.text{
width:170px;
background-color: white;
}
.btn-outline{
border-color: white;
}
</style>


<!-- Using Poppins font to print the document using browser window -->
<style type="text/css" media="print">
@import url("https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700");
@font-face {
font-family: "Poppins";
font-weight: normal;
font-style: normal;
}


@media only print {
body {
font-family: "Poppins", sans-serif;
}
}

.printfont {
font-family: "Poppins", sans-serif;
}
</style>

<style type="text/css">
footer div.spanclass{
font-size: small;
}
</style>

</head>
<body class="fix-header fix-sidebar card-no-border">
<div id="main-wrapper" class="scrollmenu" style="font-size:small">
<?php include("includes/config.php");?>
<?php include("includes/header.php");?> 
<?php include("includes/sidebar.php");?>
<div class="page-wrapper">
<div class="row page-titles"style="height:45px">
<div class="col-md-5 align-self-center" >
<h5 class="text-themecolor" style="font-weight:400">Purchase Order</h5>
</div>
<div class="col-md-7 align-self-center">
<ol class="breadcrumb">
<li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
<li class="breadcrumb-item"><a href="purchaseorder_viewup.php">Purchase Order</a></li>
<li class="breadcrumb-item active">View / Update</li>
</ol>
</div> 
</div>
<?php 
$query=mysql_query("select * from purchaseorder_reg where pono='".$_GET['cid']."' limit 1");
while($row=mysql_fetch_array($query))
{

$supplierid=$row['supplierid'];
$ssid=$row['ssid'];
$totalrupee=$row['totalrs'];


//calculation of discount amount (i.e subtotal-totalpr_wo_dis)
$subtotal=$row['subtotal'];
$roundoffvalue=$row['roundoff'];

$totalrswodis1=$row['totalpr_wo_dis_sum'];
$totalrswodis=$packing_totalprwodis+$any_totalprwodis+$totalrswodis1;

?>
<div class="container-fluid">
<div class="row">
<div class="col-12">
<div class="card">
<div class="card-body">

<!-- settings start-->
<?php 
$queryacc=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($rowacc=mysql_fetch_array($queryacc)) 
{
?> 
<ul class="nav nav-tabs" role="tablist">
<?php
$query21=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($row21=mysql_fetch_array($query21)) 
{  
$complaintarr1=$row21['purchaseorderaccess'];
$comarr1=explode(',',trim( $complaintarr1));
$secondaryarr1=$row21['multidept'];
$secarr2=explode(',',trim($secondaryarr1));
//to remove last comma from multidept array
$lastcomma = '';
foreach($secarr2 as $i=>$k) 
{
$lastcomma .= $k.',';
}
$lastcomma = rtrim($lastcomma,',');
$secarr1=explode(',',trim($lastcomma));
$querydays1=mysql_query("select * from purchaseorder_setting order by id desc limit 1");
while($rowdays1=mysql_fetch_array($querydays1)) 
{ 
$quadept1=$rowdays1['po_regdept'];
$qua1=explode(',',trim($quadept1));
$result1 = array_intersect($secarr1,$qua1);
if((($result1!=array())||(in_array($row21['department'],$qua1))) && (in_array('regpurchaseorder',$comarr1)))
{  ?>

<?php $query1=mysql_query("select * from master order by id desc limit 1");
while($row1=mysql_fetch_array($query1))
{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt3=date("Y-m-d h:i");
if($row1['licend']<= $dt3) 
{ ?>
<li class="nav-item"><a class="nav-link"  onclick="myFunctionstatus()" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span><span class="hidden-xs-down">Register</span></a></li> 
<?php } 
else
{ ?>
<li class="nav-item"><a class="nav-link" href="purchaseorder_register.php" role="tab"><span class="hidden-sm-up"><i class="ti-email"></i></span> <span class="hidden-xs-down"> Register &nbsp;<b>
</b></span></a> 
</li>
<?php } 
} 

}else{

} } } ?>

<?php   
$inhousecomarr=$rowacc['purchaseorderaccess'];
$inhousearr=explode(',',trim( $inhousecomarr));
if(in_array('viewpurchaseorder',$inhousearr))
{ ?>
<?php $query1=mysql_query("select * from master order by id desc limit 1");
while($row1=mysql_fetch_array($query1))
{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt3=date("Y-m-d h:i:s");
if($row1['licend']<= $dt3) 
{
?>
<li class="nav-item"><a class="nav-link" onclick="myFunctionstatus()" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span><span class="hidden-xs-down">View/Update</span></a></li> 
<?php } 
else
{ ?>
<li class="nav-item"><a class="nav-link" href="purchaseorder_viewup.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">View/Update</span></a> </li>
<?php } 
} ?>

<?php
} else{

} 
?>

<li class="nav-item"> <a class="nav-link active"  href="purchaseorder_hodview.php?cid=<?php echo $_GET['cid'];?>" role="tab"><span class="hidden-sm-up"><i class="ti-email"></i></span> <span class="hidden-xs-down">PO No.&nbsp;<b><?php echo $_GET['cid'];?> </b></span></a> </li>


<?php $companymaster=$rowacc['addmanageaccess'];
$compaarr=explode(',',trim($companymaster));
if(in_array('generalmanage',$compaarr))
{?>
<li class="nav-item"> <a class="nav-link"  href="purchaseorder_setting.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Settings</span></a> </li>
<?php } } ?>  
</ul>
<!--settings end -->

<br>
<form role="form" method="POST" class="form" name="partdef_form" enctype="multipart/form-data">      

<div class="col-sm-12" style="margin-left:60%">
<button class="btn btn-default btn-outline"><a href="purchaseorder_edit.php?cid=<?php echo $_GET['cid'];?>" class="text-muted"><i class="fa fa-pencil"></i>&nbsp;Edit PO</a></button>
<button class="btn btn-default btn-outline"><a href="purchaseorder_viewup.php" class="text-muted"><i class="fa fa-reply"></i>&nbsp;Back</a></button>
<!-- <a id="reportprint2" target="_blank"><button type="submit" class="btn btn-default btn-outline"><span class="text-muted"><i class="fa fa-print"></i>&nbsp;Print with status</span></button></a> -->
<a id="reportprint3" target="_blank"><button type="submit" class="btn btn-default btn-outline"><span class="text-muted"><i class="fa fa-print"></i>&nbsp;Print</span></button></a>
<a onclick="myFunction()"><button type="submit" class="btn btn-default btn-outline"><span class="text-muted"><i class="fa fa-refresh"></i>&nbsp;Refresh</span></button></a>
</div><!-- <br> -->

<!-- Fetching Supplier details -->
<?php 
$queryf=mysql_query("select * from supplier where id='$supplierid'");
while($row11=mysql_fetch_array($queryf))
{
$suppliername=$row11['suppliername'];
$add1=$row11['address'];
$add2=$row11['address2'];
$add3=$row11['address3'];
$city1=$row11['city'];
$district1=$row11['district'];
$state1=$row11['state'];
$country1=$row11['country'];
$pincode1=$row11['pincode'];
$email1=$row11['email'];
$contactno1=$row11['contactno'];
$gstno1=$row11['gstno'];
}

?> 

<!--fetching shipping address of customer -->
<?php 
$query12=mysql_query("select * from company_address where id='$ssid'");
while($row12=mysql_fetch_array($query12))
{        
$pos = $row12['shipping_address'];
list($number1, $number2, $number3, $number4, $number5, $number6, $number7, $number8) = explode('<br>', $pos);
}
?>
<!-- COMPANY ADDRESS -->
<?php 
$querycom=mysql_query("select * from company order by id desc limit 1");
while($rowcompany=mysql_fetch_array($querycom)) 
{
$companyname=$rowcompany['name'];
$address1=$rowcompany['address1'];
$address2=$rowcompany['address2'];
$address3=$rowcompany['address3'];
$city=$rowcompany['city'];
$state=$rowcompany['state'];
$country=$rowcompany['country'];
$pincode=$rowcompany['pincode'];
$logo=$rowcompany['logo'];
$gstno=$rowcompany['gstno'];
$bankname=$rowcompany['bankname'];
$branch=$rowcompany['branch'];
$accno=$rowcompany['accno'];
$ifsc=$rowcompany['ifsc'];
$micr=$rowcompany['micr'];
}
?>  

<div id="report">

<div id="companydetails" style="display:none;">
<table class="table table-sm">
<tr>
<td style="width:200px;border:none;text-align:left;vertical-align:middle;padding:0px;">
<img style='width:75px;height:60px;' src='complaintdocs/<?php echo htmlentities($logo);?>'>
</td>
<td style="width:950px;border:none;text-align:center;vertical-align:middle;padding:0px;">
<label style="color:black;font-weight:550;font-size:20px;">
<?php echo htmlspecialchars_decode($companyname);?>
</label><br>
<label>GSTIN : <?php echo $gstno; ?></label>
</td>
<td style="text-align:right;width:250px;font-weight:400;color:black;font-size:12px;border:none;">
<?php echo $address1; ?>,<?php echo $address2; ?>,<br><?php echo $address3; ?>,<br>
<?php echo $city; ?>&nbsp;-&nbsp;<?php echo $pincode; ?><br>
<?php echo $state; ?>,&nbsp;<?php echo $country; ?><br>
</td>
</tr>
</table>
</div>

<!-- <br> -->

<?php
$result = mysql_query("select sum(poqty) as value_sum from purchaseorder_reg where pono='".$_GET['cid']."'"); 
$rowsum = mysql_fetch_assoc($result); 
$sum = $rowsum['value_sum'];
$sum4=round($sum);
?>
<?php
$result = mysql_query("select sum(totalprice) as value_sum from purchaseorder_reg where pono='".$_GET['cid']."'"); 
$rowsum = mysql_fetch_assoc($result); 
$sum2 = $rowsum['value_sum'];
?>

<?php
$result2 = mysql_query("select sum(totalpr_wo_dis) as value_sum from purchaseorder_reg where pono='".$_GET['cid']."'"); 
$rowsum2 = mysql_fetch_assoc($result2); 
$totalpr_wo_disdb = $rowsum2['value_sum'];

$discountamount1=$totalpr_wo_disdb-$sum2;
$discountamount=round($discountamount1,2);
?>

<?php
$resultcess = mysql_query("select sum(cessamt) as value_sum from purchaseorder_reg where pono='".$_GET['cid']."'"); 
$cessamt2 = mysql_fetch_assoc($resultcess); 
$cessamt3 = $cessamt2['value_sum'];
$cessamt=round($cessamt3,2);
?>


<?php
$resultcg = mysql_query("select sum(cgstamt) as value_sum from purchaseorder_reg where pono='".$_GET['cid']."'"); 
$cgstamt2 = mysql_fetch_assoc($resultcg); 
$cgstamt3 = $cgstamt2['value_sum'];
$cgstamt=round($cgstamt3,2);
?>

<?php
$resultcg = mysql_query("select sum(sgstamt) as value_sum from purchaseorder_reg where pono='".$_GET['cid']."'"); 
$sgstamt2 = mysql_fetch_assoc($resultcg); 
$sgstamt3 = $sgstamt2['value_sum'];
$sgstamt=round($sgstamt3,2);
?>

<?php
$resultcg = mysql_query("select sum(igstamt) as value_sum from purchaseorder_reg where pono='".$_GET['cid']."'"); 
$igstamt2 = mysql_fetch_assoc($resultcg); 
$igstamt3 = $igstamt2['value_sum'];
$igstamt=round($igstamt3,2);

$totalrs2=$sum6+$cgstamt+$sgstamt+$igstamt+$cessamt+$roundoffvalue;
$totalrs=round($totalrs2,2);

//total amount without cess
$totalrs_wocess=$totalrs2-$totalcess;

?>

<table class="table table-sm">
<tr>
<td style="text-align:left;border:none;padding:0px;width:350px;">
<?php
$querypt12=mysql_query("select * from purchaseorder_reg where pono='".$_GET['cid']."' limit 1");
while($rowpt12=mysql_fetch_array($querypt12))                     
{ ?>
<?php if($rowpt12['hodstatus']=="Approved")
{ ?>
<label style="font-size:12px;">HOD Status&nbsp;:</label>
<label style="font-size:17px;color:#458B00;font-weight:600;">Approved</label>
<?php }
else if($rowpt12['hodstatus']=="Reject")
{ ?>
<label style="font-size:12px;">HOD Status&nbsp;:</label>
<label style="font-size:17px;color:#ff4444;font-weight:600;">Rejected</label>
<?php  } 
else if($rowpt12['hodstatus']=="Need More Info")
{ ?>
<label style="font-size:12px;">HOD Status&nbsp;:</label>
<label style="font-size:17px;color:#1976d2;font-weight:600;">Need More Info</label>
<?php  } 
else if(($rowpt12['hodstatus']=="Initiated")||($rowpt12['hodstatus']==""))
{ ?>
<label style="font-size:12px;">HOD Status&nbsp;:</label>
<label style="font-size:17px;color:#f38330;font-weight:600;">Initiated</label>
<?php } } ?>
</td>

<td style="text-align:right;border:none;padding:0px;width:400px;">
<?php
$querypt12=mysql_query("select * from purchaseorder_reg where pono='".$_GET['cid']."' limit 1");
while($rowpt12=mysql_fetch_array($querypt12))                     
{ ?>
<?php if($rowpt12['mgmt_status']=="Approved")
{ ?>
<label style="font-size:12px;">MGMT Status&nbsp;:</label>
<label style="font-size:17px;color:#458B00;font-weight:600;">Approved</label>
<?php }
else if($rowpt12['mgmt_status']=="Reject")
{ ?>
<label style="font-size:12px;">MGMT Status&nbsp;:</label>
<label style="font-size:17px;color:#ff4444;font-weight:600;">Rejected</label>
<?php  } 
else if($rowpt12['mgmt_status']=="Need More Info")
{ ?>
<label style="font-size:12px;">MGMT Status&nbsp;:</label>
<label style="font-size:17px;color:#1976d2;font-weight:600;">Need More Info</label>
<?php  } 
else if(($rowpt12['mgmt_status']=="Initiated")||($rowpt12['mgmt_status']==""))
{ ?>
<label style="font-size:12px;">MGMT Status&nbsp;:</label>
<label style="font-size:17px;color:#f38330;font-weight:600;">Initiated</label>
<?php } } ?>
</td>
</tr>

</table>

<table class="table table-sm" id="headdet">
<tr>
<td style="color:black;font-weight:500;text-align:center;width:500px;vertical-align:middle;">
<label style="font-size:20px;">PURCHASE ORDER</label>
</td>
<td style="width:150px;vertical-align:middle;text-align:center;"><label>PO No.&nbsp;&nbsp;:&nbsp;&nbsp;</label><span style="color:black;font-weight:400;"><?php echo $_GET['cid'] ?></span></td>
<td style="width:300px;vertical-align:middle;text-align:center;"><label>PO Date&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;</label><span style="color:black;font-weight:400;"> <?php echo htmlspecialchars_decode($row['podate']);?> </span></td>
</tr>
</table>


<!-- <table class="table table-sm" id="cusdetails">
<thead>
<tr>
<td style="width:300px;" rowspan="6">
<label>Supplier Details</label><br>
<span style="font-size:12px;font-weight:500;"><?php echo $suppliername; ?></span><br>
<?php echo $add1; ?>,<br>
<?php echo $add2; ?>,&nbsp;<?php echo $add3; ?>,<br>
<?php echo $city1; ?>&nbsp;-&nbsp;<?php echo $pincode1; ?><br>
<?php echo $state1; ?>,&nbsp;<?php echo $country1; ?>
<br>GSTIN : <?php echo $gstno1; ?> 
</td>

<td style="width:300px;" rowspan="6">
<label>Billing Address</label><br>
<span style="font-size:12px;font-weight:500;"><?php echo htmlspecialchars_decode($companyname);?></span><br>
<?php echo $address1; ?>,<?php echo $address2; ?>,<br>
<?php echo $address3; ?>,<br>
<?php echo $city; ?>&nbsp;-&nbsp;<?php echo $pincode; ?><br>
<?php echo $state; ?>,&nbsp;<?php echo $country; ?><br>
<?php echo $gstno; ?>
</td>
<?php
if($row['sameasbill']=="Yes")
{ ?>

<td style="width:300px;" rowspan="6">
<label>Shipping Address</label><br>
<span style="font-size:12px;font-weight:500;"><?php echo htmlspecialchars_decode($companyname);?></span><br>
<?php echo $address1; ?>,<?php echo $address2; ?>,<br>
<?php echo $address3; ?>,<br>
<?php echo $city; ?>&nbsp;-&nbsp;<?php echo $pincode; ?><br>
<?php echo $state; ?>,&nbsp;<?php echo $country; ?><br>  
<?php echo $gstno; ?>
</td>
<?php }
else
{?>
<td style="width:300px;" rowspan="6">
<label>Shipping Address</label><br>
<span style="font-size:12px;font-weight:500;"><?php echo htmlspecialchars_decode($companyname);?></span><br>
<?php echo $number1; ?>,&nbsp;<?php echo $number2; ?>,<br>
<?php echo $number3; ?>,<br>
<?php echo $number4; ?>&nbsp;<?php echo $number7; ?><br>
<?php echo $number5; ?>,&nbsp;<?php echo $number6; ?><br>
<?php echo $number8; ?>
</td>
<?php } ?>
</tr>
<tr>
<td style="width:200px;"><label>Vendor Code</label></td>
<td>:&nbsp;&nbsp;<?php echo htmlspecialchars_decode($row['vendorcode']);?></td>
</tr>
<tr>
<td style="width:200px;"><label>Reverse Charges</label></td>
<td>:&nbsp;&nbsp;<?php echo htmlspecialchars_decode($row['reversecharges']);?></td>
</tr>
<tr>
<td><label>Payment Term in Days</label></td>
<td>:&nbsp;&nbsp;<?php echo htmlspecialchars_decode($row['paymentterm']);?></td>
</tr>
<tr>
<td><label>Delivery Mode</label></td>
<td>:&nbsp;&nbsp;<?php echo htmlspecialchars_decode($row['deliverymode']);?></td>
</tr>
<tr>
<td><label>Freight</label></td>
<td>:&nbsp;&nbsp;<?php echo htmlspecialchars_decode($row['freight']);?></td>
</tr>
</thead>
</table> -->


<table class="table table-sm" id="cusdetails">
<thead>
<tr>
<td><label>Supplier Details</label></td>
<td><label>Billing Address</label></td>
<td><label>Shipping Address</label></td>
</tr>
<tr>
<td style="width:300px;">
<span style="font-size:12px;font-weight:500;"><?php echo $suppliername; ?></span>
<br>
<?php echo $add1; ?>,<br>
<?php echo $add2; ?>,&nbsp;<?php echo $add3; ?>,<br>
<?php echo $city1; ?>&nbsp;-&nbsp;<?php echo $pincode1; ?><br>
<?php echo $state1; ?>,&nbsp;<?php echo $country1; ?><br>
GSTIN/UIN : <?php echo $gstno1; ?> 
</td>
<td style="width:300px;">
<span style="font-size:12px;font-weight:500;"><?php echo htmlspecialchars_decode($companyname);?></span><br>
<?php echo $address1; ?>,<?php echo $address2; ?>,<br>
<?php echo $address3; ?>,<br>
<?php echo $city; ?>&nbsp;-&nbsp;<?php echo $pincode; ?><br>
<?php echo $state; ?>,&nbsp;<?php echo $country; ?><br>
GSTIN/UIN : <?php echo $gstno; ?>
</td>
<?php
if($row['sameasbill']=="Yes")
{ ?>
<!--if shipping address is same as billing address-->
<td style="width:300px;">
<span style="font-size:12px;font-weight:500;"><?php echo htmlspecialchars_decode($companyname);?></span><br>
<?php echo $address1; ?>,<?php echo $address2; ?>,<br>
<?php echo $address3; ?>,<br>
<?php echo $city; ?>&nbsp;-&nbsp;<?php echo $pincode; ?><br>
<?php echo $state; ?>,&nbsp;<?php echo $country; ?><br>  
GSTIN/UIN : <?php echo $gstno; ?>
</td>
<?php }
else
{?>
<td style="width:300px;">
<span style="font-size:12px;font-weight:500;"><?php echo htmlspecialchars_decode($companyname);?></span><br>
<?php echo $number1; ?>,&nbsp;<?php echo $number2; ?>,<br>
<?php echo $number3; ?>,<br>
<?php echo $number4; ?>&nbsp;<?php echo $number7; ?><br>
<?php echo $number5; ?>,&nbsp;<?php echo $number6; ?><br>
<?php echo $number8; ?>
</td>
<?php } ?>
</tr>
</thead>
</table>
<br>

<table class="table table-sm" id="vendor">
<td style="width:200px;"><label>Vendor Code</label>&nbsp;&nbsp;:&nbsp;&nbsp;
<?php 
if($row['vendorcode']=="")
{
echo"-";
} 
else{
echo htmlspecialchars_decode($row['vendorcode']);
}
?>
</td>
<td style="width:200px;"><label>Payment Term</label>&nbsp;&nbsp;:&nbsp;&nbsp;
<?php 
if($row['paymentterm']=="")
{
echo"-";
} 
else{
echo htmlspecialchars_decode($row['paymentterm']);
}
?>
</td>
<td style="width:200px;"><label>Delivery Mode</label>&nbsp;&nbsp;:&nbsp;&nbsp;
<?php 
if($row['deliverymode']=="")
{
echo"-";
} 
else{
echo htmlspecialchars_decode($row['deliverymode']);
}
?>
</td>
<td style="width:200px;"><label>Freight</label>&nbsp;&nbsp;:&nbsp;&nbsp;
<?php 
if($row['freight']=="")
{
echo"-";
} 
else{
echo htmlspecialchars_decode($row['freight']);
}
?>
</td>
</table>

<br>
<?php

function convertToIndianCurrency($number) {
$no = round($number);
$decimal = round($number - ($no = floor($number)), 2) * 100;    
$digits_length = strlen($no);    
$i = 0;
$str = array();
$words = array(
0 => '',
1 => 'One',
2 => 'Two',
3 => 'Three',
4 => 'Four',
5 => 'Five',
6 => 'Six',
7 => 'Seven',
8 => 'Eight',
9 => 'Nine',
10 => 'Ten',
11 => 'Eleven',
12 => 'Twelve',
13 => 'Thirteen',
14 => 'Fourteen',
15 => 'Fifteen',
16 => 'Sixteen',
17 => 'Seventeen',
18 => 'Eighteen',
19 => 'Nineteen',
20 => 'Twenty',
30 => 'Thirty',
40 => 'Forty',
50 => 'Fifty',
60 => 'Sixty',
70 => 'Seventy',
80 => 'Eighty',
90 => 'Ninety');
$digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
while ($i < $digits_length) {
$divider = ($i == 2) ? 10 : 100;
$number = floor($no % $divider);
$no = floor($no / $divider);
$i += $divider == 10 ? 1 : 2;
if ($number) {
$plural = (($counter = count($str)) && $number > 9) ? 's' : null;            
$str [] = ($number < 21) ? $words[$number] . ' ' . $digits[$counter] . $plural : $words[floor($number / 10) * 10] . ' ' . $words[$number % 10] . ' ' . $digits[$counter] . $plural;
} else {
$str [] = null;
}  
}

$Rupees = implode(' ', array_reverse($str));
$paise = ($decimal) ? ($words[$decimal - $decimal%10]) ." " .($words[$decimal%10])  : '';
if($paise!="")
{
return ($Rupees ? 'Rupees ' . $Rupees : '') ."and ". $paise ." Paise" ." Only";
}
else
{
return ($Rupees ? 'Rupees ' . $Rupees : '') ." Only";
}

}

?>

<?php 
$retap2=mysql_query("select * from cess_applicability order by id desc limit 1");
while($rwap2=mysql_fetch_array($retap2))
{ 

if($rwap2['cess_yesno']=='Yes')
{ ?>
<div class=""> 
<table class="table table-bordered table-sm" id="cusdetails3">
<thead>
<tr style="background-color:#0080FF;">
<th style="width:10px;">Sl No.</th>
<th style="width:350px;">Part Name [Dwg No.]</th>
<th style="width:60px;">HSN Code</th>
<th style="width:50px;">PO Qty</th>
<th style="width:80px;">Delivery Date</th>
<th style="width:80px;">Unit Price</th>
<th style="width:30px;">Discount</th>
<th style="width:150px;">Tax</th>
<th style="width:150px;">CESS %</th>
<th style="width:80px;">Total Price</th>
</tr>
</thead>
<?php
$cnt=1;
$query13=mysql_query("select *  from purchaseorder_reg where pono='".$_GET['cid']."'");
while($row3=mysql_fetch_array($query13))                     
{ 
$offstate=$row3['officeaddstate'];
$shipstate=$row3['shippingstate'];
$taxvalue=$row3['tax'];
$discount=$row3['discount'];

$cgstamtdb=$row3['cgstamt'];
$sgstamtdb=$row3['sgstamt'];
$igstamtdb=$row3['igstamt'];

$cgstperdb=$row3['cgstper'];
$sgstperdb=$row3['sgstper'];
$igstperdb=$row3['igstper'];

?>
<tr>
<td><?php echo $cnt;?></td>
<td><?php echo htmlspecialchars_decode($row3['partname']);?>
[<?php echo htmlspecialchars_decode($row3['drawingno']);?>]<br>
<?php
if($row3['remark']!="")
{ ?>
<?php echo htmlspecialchars_decode($row3['remark']);?> 
<?php } ?>
</td>
<td>
<?php 
if($row['hsncode']=="")
{
echo"-";
} 
else{
echo htmlspecialchars_decode($row['hsncode']);
}
?>

</td>
<td>
<?php echo htmlspecialchars_decode($row3['poqty']);?>&nbsp;<?php echo htmlspecialchars_decode($row3['unit']);?>
</td>
<td>
<?php 
if($row['deliverydate']=="")
{
echo"-";
} 
else{
echo htmlspecialchars_decode($row['deliverydate']);
}
?>
</td>
<td>
<span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo htmlspecialchars_decode($row3['unitprice']);?>
</td>
<td>
<?php 
if($discount!="")
{
echo "$discount %";
}
else
{
echo"-";
}
?>
</td>

<td>
<?php
if(($row3['cgstamt']!='0'))
{ ?>
CGST&nbsp;:&nbsp;<span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo "$cgstamtdb"." "."@"." "."$cgstperdb"."%".'<br>'; ?>
<?php }
if(($row3['sgstamt']!='0'))
{ ?>
CGST&nbsp;:&nbsp;<span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo "$sgstamtdb"." "."@"." "."$sgstperdb"."%".'<br>'; ?>
<?php }
if(($row3['igstamt']!='0'))
{ ?>
CGST&nbsp;:&nbsp;<span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo "$igstamtdb"." "."@"." "."$igstperdb"."%".'<br>'; ?>
<?php } ?>
</td>

<td>
<?php 
if($row['cesstype']=="")
{ ?>
<?php echo"-"; ?>
<?php } 
else
{ ?>
<?php echo htmlspecialchars_decode($row3['cesstype']);?><br>
<span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo htmlspecialchars_decode($row3['cessamt']);?>
<?php } ?>

</td>

<td style="text-align:right;"><span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo htmlspecialchars_decode($row3['totalprice']);?></td>
</tr><?php $cnt=$cnt+1; } ?>

<input id="number" type="text" value="<?php echo $totalrupee2; ?>" style="display:none;"/>


<tr>
<td colspan="3" style="text-align:right;"><label>Total Quantity&nbsp;:&nbsp;</label></td>
<!-- <td></td> -->
<td><b><?php echo htmlspecialchars_decode($sum4);?></b></td>
<td  colspan="4"></td>
<td style="text-align:right;"><label>Amt Before Tax</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;"><span style="font-family:sans-serif; font-size: 12px;">&#8377</span>&nbsp;
<!--  <?php echo $sum6;?> -->
<?php echo htmlspecialchars_decode($row['subtotal']);?>
</td>
</tr>
<tr>
<!-- <td colspan="3"><label>Packing</label>&nbsp;&nbsp;&nbsp;<?php echo htmlspecialchars_decode($row['packing']);?></td>-->
<td colspan="8">
<label>Amount in Words&nbsp;:&nbsp;&nbsp;</label>
<?php
echo convertToIndianCurrency($totalrupee);
?>
</td>
<td style="text-align:right;"><label>CGST</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;"><span style="font-family:sans-serif;font-size:12px;">&#8377</span>&nbsp;
<!--  <?php echo $cgstamt;?> -->
<?php echo htmlspecialchars_decode($row['cgstvalue']);?>
</td>
</tr>
<tr>
<td colspan="8" rowspan="3" style="vertical-align:middle;text-align:justify;">
<?php 
if($row['notes']=="")
{ ?>
<?php echo"-"; ?>
<?php } 
else
{ ?>
<label>Notes&nbsp;:&nbsp;</label>&nbsp;&nbsp;<?php echo htmlspecialchars_decode($row['notes']);?>
<?php }
?>
</td> 
<td style="text-align:right;"><label>SGST</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;"><span style="font-family:sans-serif;font-size:12px;">&#8377</span>&nbsp;
<?php echo htmlspecialchars_decode($row['sgstvalue']);?>
</td>
</tr>
<tr>

<td style="text-align:right;"><label>IGST</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;"><span style="font-family:sans-serif; font-size: 12px;">&#8377</span>&nbsp;
<!-- <?php echo $igstamt;?> -->
<?php echo htmlspecialchars_decode($row['igstvalue']);?>
</td>
</tr> 
<tr>
<td style="text-align:right;"><label>CESS</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;"><span style="font-family:sans-serif; font-size: 12px;">&#8377</span>&nbsp;
<!--  <?php echo $cessamt;?> -->
<?php echo htmlspecialchars_decode($row['totalcess']);?>
</td>
</tr>

<tr>
<td colspan="8" rowspan="3" style="vertical-align:middle;text-align:justify;">
<?php 
if($row['termsandcond']=="")
{ ?>
<?php echo"-"; ?>
<?php } 
else
{ ?>
<label>Terms & Condition&nbsp;:&nbsp;</label><br><?php echo htmlspecialchars_decode($row['termsandcond']);?>
<?php }
?>
</td>
<td style="text-align:right;"><label>Round Off</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;"><span style="font-family:sans-serif;font-size:12px;">&#8377</span>&nbsp;
<?php 
if(($row['roundoff']=="")||($row['roundoff']=='0'))
{ 
echo "0.00";
}
else if($row['roundoff']>'0')
{ 
echo htmlspecialchars_decode($row['roundoff']);
} ?>
</td>
</tr>
<tr>
<td style="text-align:right;"><label>Discount</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;"><span style="font-family:sans-serif; font-size: 12px;">&#8377</span>&nbsp;
<?php echo $discountamount;?>
</td>
</tr>

<tr>
<td style="text-align:right;"><label>Total Amount</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;">
<span style="font-family:sans-serif;font-size:12px;">&#8377</span>
<?php echo htmlspecialchars_decode($row['totalrs']);?>
</td>
</tr>
<tr>
<td colspan="5" style="vertical-align:middle;text-align:justify;">
<?php
$retap1=mysql_query("select * from purchaseorder_setting order by id desc limit 1");
while($rwap1=mysql_fetch_array($retap1))
{ 
if($rwap1['mandatorynote1']!="")
{ ?>
1.&nbsp;<?php echo htmlspecialchars_decode($rwap1['mandatorynote1']);?><br>
<?php }
if($rwap1['mandatorynote2']!="")
{ ?>
2.&nbsp;<?php echo htmlspecialchars_decode($rwap1['mandatorynote2']);?><br>
<?php }
if($rwap1['mandatorynote3']!="")
{ ?>
3.&nbsp;<?php echo htmlspecialchars_decode($rwap1['mandatorynote3']);?><br>
<?php }
if($rwap1['mandatorynote4']!="")
{ ?>
4.&nbsp;<?php echo htmlspecialchars_decode($rwap1['mandatorynote4']);?><br>
<?php }
if($rwap1['mandatorynote5']!="")
{ ?>
5.&nbsp;<?php echo htmlspecialchars_decode($rwap1['mandatorynote5']);?><br>
<?php } } ?>
</td>
<td colspan="3" style="vertical-align:bottom;text-align:center;">
Prepared By&nbsp;&nbsp;:&nbsp;&nbsp;<?php echo htmlspecialchars_decode($row['reg_by']);?>
</td>
<td colspan="2" style="vertical-align:bottom;text-align:right;">
<label style="font-size:10px;vertical-align:top;text-align:right;">E. & O. E.</label>

<br><br>
<!-- 
<div class="input-group">
<div class="input-group-prepend"> -->
<!--displaying digital signature of the person who will approve the PO -->
<?php 
$retap=mysql_query("select * from purchaseorder_reg where pono='".$_GET['cid']."' and hodstatus='Approved' limit 1");
while($rwap=mysql_fetch_array($retap))
{
$hodremarkby=$rwap['hodrmkby'];

//fetching digital signature of the person who has approved the PO from purchaseorder_setting table
$retap1=mysql_query("select * from purchaseorder_setting order by id desc limit 1");
while($rwap1=mysql_fetch_array($retap1))
{
if($rwap1['poapprovalby']== $rwap['hodrmkby'])
{
$cfile1=$rwap1['dig_signature'];
if($cfile1==""  )
{

}
else if($cfile1=="NULL"||$cfile1=="default.png")
{
echo "No Attachments";
}
else
{
$cfile2=pathinfo($rwap1['dig_signature']);
$cfile2['extension'];
$cool_extensions = Array('doc','docx','DOCX','DOC');
$cool_extensions1 = Array('pdf','PDF');
$cool_extensions2=Array('xls','xlsx','XLS','XLSX');
$cool_extensions3=Array('jpg','png','jpeg','JPG','JPEG','PNG');
if (in_array($cfile2['extension'], $cool_extensions))
{ ?>
<img src="complaintdocs/doc.png" style="height:40px;width:45px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" target="_blank"></a>
<?php
}
else if(in_array($cfile2['extension'], $cool_extensions1))
{ ?>
<img src="complaintdocs/pdf.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions2))
{ ?>
<img src="complaintdocs/xls.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions3))
{
?>  
<img style="width:50px;height:30px;"src="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" ?>&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" target="_blank"></a>
<?php 
}else{ ?>
<img src="complaintdocs/unknown.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" target="_blank"></a>
<?php }
} ?>

<?php }
else if($rwap1['poapprovalby2']== $rwap['hodrmkby'])
{
$cfile1=$rwap1['dig_signature2'];
if($cfile1==""  )
{

}
else if($cfile1=="NULL"||$cfile1=="default.png")
{
echo "No Attachments";
}
else
{
$cfile2=pathinfo($rwap1['dig_signature2']);
$cfile2['extension'];
$cool_extensions = Array('doc','docx','DOCX','DOC');
$cool_extensions1 = Array('pdf','PDF');
$cool_extensions2=Array('xls','xlsx','XLS','XLSX');
$cool_extensions3=Array('jpg','png','jpeg','JPG','JPEG','PNG');
if (in_array($cfile2['extension'], $cool_extensions))
{ ?>
<img src="complaintdocs/doc.png" style="height:40px;width:45px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" target="_blank"></a>
<?php
}
else if(in_array($cfile2['extension'], $cool_extensions1))
{ ?>
<img src="complaintdocs/pdf.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions2))
{ ?>
<img src="complaintdocs/xls.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions3))
{
?>  
<img style="width:50px;height:30px;"src="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" ?>&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" target="_blank"></a>
<?php 
}else{ ?>
<img src="complaintdocs/unknown.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" target="_blank"></a>
<?php } } ?>
<?php }
else if($rwap1['poapprovalby3']== $rwap['hodrmkby'])
{
$cfile1=$rwap1['dig_signature3'];
if($cfile1==""  )
{

}
else if($cfile1=="NULL"||$cfile1=="default.png")
{
echo "No Attachments";
}
else
{
$cfile2=pathinfo($rwap1['dig_signature3']);
$cfile2['extension'];
$cool_extensions = Array('doc','docx','DOCX','DOC');
$cool_extensions1 = Array('pdf','PDF');
$cool_extensions2=Array('xls','xlsx','XLS','XLSX');
$cool_extensions3=Array('jpg','png','jpeg','JPG','JPEG','PNG');
if (in_array($cfile2['extension'], $cool_extensions))
{ ?>
<img src="complaintdocs/doc.png" style="height:40px;width:45px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature3']);?>" target="_blank"></a>
<?php
}
else if(in_array($cfile2['extension'], $cool_extensions1))
{ ?>
<img src="complaintdocs/pdf.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature3']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions2))
{ ?>
<img src="complaintdocs/xls.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature3']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions3))
{
?>  
<img style="width:50px;height:30px;"src="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature3']);?>" ?>&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature3']);?>" target="_blank"></a>
<?php 
}else{ ?>
<img src="complaintdocs/unknown.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature3']);?>" target="_blank"></a>
<?php } } ?>
<?php }
}
}
?>

<!--DIGITAL SIGNATURE FOR MANAGEMENT -->
<?php 
$retap=mysql_query("select * from purchaseorder_reg where pono='".$_GET['cid']."' and mgmt_status='Approved' limit 1");
while($rwap=mysql_fetch_array($retap))
{
$hodremarkby=$rwap['mgmt_rmkby'];

//fetching digital signature of the person who has approved the PO from purchaseorder_setting table
$retap1=mysql_query("select * from purchaseorder_setting order by id desc limit 1");
while($rwap1=mysql_fetch_array($retap1))
{
if($rwap1['poapprovalby']== $rwap['mgmt_rmkby'])
{
$cfile1=$rwap1['dig_signature'];
if($cfile1==""  )
{

}
else if($cfile1=="NULL"||$cfile1=="default.png")
{
echo "No Attachments";
}
else
{
$cfile2=pathinfo($rwap1['dig_signature']);
$cfile2['extension'];
$cool_extensions = Array('doc','docx','DOCX','DOC');
$cool_extensions1 = Array('pdf','PDF');
$cool_extensions2=Array('xls','xlsx','XLS','XLSX');
$cool_extensions3=Array('jpg','png','jpeg','JPG','JPEG','PNG');
if (in_array($cfile2['extension'], $cool_extensions))
{ ?>
<img src="complaintdocs/doc.png" style="height:40px;width:45px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" target="_blank"></a>
<?php
}
else if(in_array($cfile2['extension'], $cool_extensions1))
{ ?>
<img src="complaintdocs/pdf.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions2))
{ ?>
<img src="complaintdocs/xls.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions3))
{
?>  
<img style="width:50px;height:30px;"src="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" ?>&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" target="_blank"></a>
<?php 
}else{ ?>
<img src="complaintdocs/unknown.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" target="_blank"></a>
<?php }
} ?>

<?php }
else if($rwap1['poapprovalby2']== $rwap['mgmt_rmkby'])
{
$cfile1=$rwap1['dig_signature2'];
if($cfile1==""  )
{

}
else if($cfile1=="NULL"||$cfile1=="default.png")
{
echo "No Attachments";
}
else
{
$cfile2=pathinfo($rwap1['dig_signature2']);
$cfile2['extension'];
$cool_extensions = Array('doc','docx','DOCX','DOC');
$cool_extensions1 = Array('pdf','PDF');
$cool_extensions2=Array('xls','xlsx','XLS','XLSX');
$cool_extensions3=Array('jpg','png','jpeg','JPG','JPEG','PNG');
if (in_array($cfile2['extension'], $cool_extensions))
{ ?>
<img src="complaintdocs/doc.png" style="height:40px;width:45px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" target="_blank"></a>
<?php
}
else if(in_array($cfile2['extension'], $cool_extensions1))
{ ?>
<img src="complaintdocs/pdf.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions2))
{ ?>
<img src="complaintdocs/xls.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions3))
{
?>  
<img style="width:50px;height:30px;"src="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" ?>&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" target="_blank"></a>
<?php 
}else{ ?>
<img src="complaintdocs/unknown.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" target="_blank"></a>
<?php } } ?>
<?php }
else if($rwap1['poapprovalby3']== $rwap['mgmt_rmkby'])
{
$cfile1=$rwap1['dig_signature3'];
if($cfile1==""  )
{

}
else if($cfile1=="NULL"||$cfile1=="default.png")
{
echo "No Attachments";
}
else
{
$cfile2=pathinfo($rwap1['dig_signature3']);
$cfile2['extension'];
$cool_extensions = Array('doc','docx','DOCX','DOC');
$cool_extensions1 = Array('pdf','PDF');
$cool_extensions2=Array('xls','xlsx','XLS','XLSX');
$cool_extensions3=Array('jpg','png','jpeg','JPG','JPEG','PNG');
if (in_array($cfile2['extension'], $cool_extensions))
{ ?>
<img src="complaintdocs/doc.png" style="height:40px;width:45px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature3']);?>" target="_blank"></a>
<?php
}
else if(in_array($cfile2['extension'], $cool_extensions1))
{ ?>
<img src="complaintdocs/pdf.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature3']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions2))
{ ?>
<img src="complaintdocs/xls.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature3']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions3))
{
?>  
<img style="width:50px;height:30px;"src="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature3']);?>" ?>&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature3']);?>" target="_blank"></a>
<?php 
}else{ ?>
<img src="complaintdocs/unknown.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature3']);?>" target="_blank"></a>
<?php } } ?>
<?php }
}
}
?>
<br>
<!-- </div>
</div> -->

<!--digital signature end -->

<label style="font-size:10px;">Authorized Signatory</label>
</td>
</tr>
</table> 
</div>

<?php }  //if closing of cess_applicability==Yes 
else
{ ?>

<div class=""> 
<label>else part start</label>
<table class="table table-bordered table-sm" id="cusdetails3">
<thead>
<tr style="background-color:#0080FF;">
<th style="width:10px;">Sl No.</th>
<th style="width:250px;">Part Name [Dwg No.]</th>
<th style="width:60px;">HSN Code</th>
<th style="width:35px;">Req Qty</th>
<th style="width:60px;">Shortage By</th>
<th style="width:35px;">PO Qty</th>
<th style="width:160px;">Delivery Date</th>
<!-- <th style="width:150px;" id="cessw">CESS</th> -->
<th style="width:80px;">Total Price in <span style="font-family:sans-serif;font-size:10px;">&#8377</span></th>
</tr>
</thead>
<?php
$cnt=1;
$query13=mysql_query("select *  from purchaseorder_reg where pono='".$_GET['cid']."'");
while($row3=mysql_fetch_array($query13))                     
{ 
$offstate=$row3['officeaddstate'];
$shipstate=$row3['shippingstate'];
$taxvalue=$row3['tax'];
$discount=$row3['discount'];

$cgstamtdb=$row3['cgstamt'];
$sgstamtdb=$row3['sgstamt'];
$igstamtdb=$row3['igstamt'];

$cgstperdb=$row3['cgstper'];
$sgstperdb=$row3['sgstper'];
$igstperdb=$row3['igstper'];

?>
<tr>
<td><?php echo $cnt;?></td>
<td><?php echo htmlspecialchars_decode($row3['partname']);?>
[<?php echo htmlspecialchars_decode($row3['drawingno']);?>]<br>
<?php
if($row3['remark']!="")
{ ?>
<?php echo htmlspecialchars_decode($row3['remark']);?> 
<?php } ?>
</td>
<td><?php echo htmlspecialchars_decode($row3['pono_forpart']);?>
<?php
if($row3['podate_forpart']!="")
{ 
$podate_forpart=$row3['podate_forpart'];
echo"[$podate_forpart]"; 
}
?>
</td>
<td><?php echo htmlspecialchars_decode($row3['hsncode']);?></td>
<td style="width:35px;"><?php echo htmlspecialchars_decode($row3['quantity']);?>&nbsp;<?php echo htmlspecialchars_decode($row3['unit']);?>
</td>
<td><span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo htmlspecialchars_decode($row3['unitprice']);?></td>
<td>
<?php 
if($discount!="")
{
echo "$discount %";
}
else
{
echo "0 %";
}
?>
</td>
<td>
<?php
if(($row3['cgstamt']!='0'))
{ ?>
CGST&nbsp;:&nbsp;<span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo "$cgstamtdb"." "."@"." "."$cgstperdb"."%".'<br>'; ?>
<?php }
if(($row3['sgstamt']!='0'))
{ ?>
CGST&nbsp;:&nbsp;<span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo "$sgstamtdb"." "."@"." "."$sgstperdb"."%".'<br>'; ?>
<?php }
if(($row3['igstamt']!='0'))
{ ?>
CGST&nbsp;:&nbsp;<span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo "$igstamtdb"." "."@"." "."$igstperdb"."%".'<br>'; ?>
<?php } ?>
</td>
<!-- <td>
<?php echo htmlspecialchars_decode($row3['cesstype']);?><br>
<?php echo htmlspecialchars_decode($row3['cessamt']);?>
</td> -->
<td style="text-align:right;"><span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo htmlspecialchars_decode($row3['totalprice']);?></td>
</tr><?php $cnt=$cnt+1; } ?>

<input id="number" type="text" value="<?php echo $totalrupee2; ?>" style="display:none;"/>
<tr>
<td colspan="3" style="text-align:right;"><label style="font-size:11px;">Packing & Forwarding</label></td>
<td><?php echo htmlspecialchars_decode($row['packing_hsncode']);?></td>
<td></td>
<td><span style="font-family:sans-serif;font-size:10px;">&#8377</span>&nbsp;<?php echo htmlspecialchars_decode($row['packing_unitpr']);?></td>
<td><?php echo htmlspecialchars_decode($row['packing_discnt']);?></td>
<td>
<?php
if(($row3['packing_cgstamt']!='0'))
{ ?>
CGST&nbsp;:&nbsp;<span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo "$packing_cgstamt"." "."@"." "."$packing_cgstper"."%".'<br>'; ?>
<?php }
if(($row3['packing_sgstamt']!='0'))
{ ?>
CGST&nbsp;:&nbsp;<span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo "$packing_sgstamt"." "."@"." "."$packing_sgstper"."%".'<br>'; ?>
<?php }
if(($row3['packing_igstamt']!='0'))
{ ?>
CGST&nbsp;:&nbsp;<span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo "$packing_igstamt"." "."@"." "."$packing_igstper"."%".'<br>'; ?>
<?php } ?>
</td>
<!-- <td>
<?php echo htmlspecialchars_decode($row['packing_cesstype']);?><br>
<?php echo htmlspecialchars_decode($row['packing_cessamt']);?>
</td> -->
<td style="text-align:right;">
<span style="font-family:sans-serif;font-size:10px;">&#8377</span>&nbsp;
<?php echo htmlspecialchars_decode($row['packing_totalpr']);?></td>
</tr>
<tr>
<td colspan="3" style="text-align:right;">
<?php
if($row['any_label']=="")
{ ?>
<?php echo "-"; ?>
<?php }
else
{ ?>
<?php echo htmlspecialchars_decode($row['any_label']);?>
<?php } ?>
</td>
<td><?php echo htmlspecialchars_decode($row['any_hsncode']);?></td>
<td></td>
<td><span style="font-family:sans-serif;font-size:10px;">&#8377</span>&nbsp;
<?php echo htmlspecialchars_decode($row['any_unitpr']);?></td>
<td><?php echo htmlspecialchars_decode($row['any_discnt']);?></td>
<td>
<?php
if(($row3['any_cgstamt']!='0'))
{ ?>
CGST&nbsp;:&nbsp;<span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo "$any_cgstamt"." "."@"." "."$any_cgstper"."%".'<br>'; ?>
<?php }
if(($row3['any_sgstamt']!='0'))
{ ?>
CGST&nbsp;:&nbsp;<span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo "$any_sgstamt"." "."@"." "."$any_sgstper"."%".'<br>'; ?>
<?php }
if(($row3['any_igstamt']!='0'))
{ ?>
CGST&nbsp;:&nbsp;<span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo "$any_igstamt"." "."@"." "."$any_igstper"."%".'<br>'; ?>
<?php } ?>
</td>
<!-- <td>
<?php echo htmlspecialchars_decode($row['any_cesstype']);?><br>
<?php echo htmlspecialchars_decode($row['any_cessamt']);?>
</td> -->
<td style="text-align:right;">
<span style="font-family:sans-serif;font-size:10px;">&#8377</span>&nbsp;
<?php echo htmlspecialchars_decode($row['any_totalpr']);?></td>
</tr>
<tr>
<td colspan="2" style="text-align:right;"><label>Total Quantity&nbsp;:&nbsp;</label></td>
<!-- <td></td> -->
<td colspan="2" style="text-align:right;"><?php echo htmlspecialchars_decode($row['totalquantity']);?></td>
<td  colspan="3"></td>
<td style="text-align:left;"><label>Amt Before Tax</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;"><span style="font-family:sans-serif; font-size: 12px;">&#8377</span>&nbsp;
<?php echo $sum6;?></td>
</tr>
<tr>
<td colspan="2"><label>Packing</label>&nbsp;&nbsp;&nbsp;<?php echo htmlspecialchars_decode($row['packing']);?></td>
<td colspan="5"><label>Total Weight</label>&nbsp;&nbsp;&nbsp;<?php echo htmlspecialchars_decode($row['totalweight']);?></td>
<td style="text-align:left;"><label>CGST</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;"><span style="font-family:sans-serif;font-size:12px;">&#8377</span>&nbsp;
<?php echo $cgstamt;?></td>
</tr>
<tr>
<td colspan="2"><label>Carrier</label>&nbsp;&nbsp;&nbsp;<?php echo htmlspecialchars_decode($row['carrier']);?></td>
<td colspan="5"><label>Vehicle No.</label>&nbsp;&nbsp;&nbsp;<?php echo htmlspecialchars_decode($row['vehicleno']);?></td>
<td style="text-align:left;"><label>SGST</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;"><span style="font-family:sans-serif;font-size:12px;">&#8377</span>&nbsp;
<?php echo $sgstamt;?></td>
</tr>
<tr>
<td colspan="7">
<label>Amount in Words&nbsp;:&nbsp;&nbsp;
<span style="font-weight:450;color:black;font-size:11px;">Rupees&nbsp;</span><span id="words" style="font-weight:450;color:black;font-size:11px;">
</span><span style="font-weight:450;color:black;font-size:11px;">only</span></label>
<br>
<label>GST Payable on Reverse Charge</label>&nbsp;&nbsp;
CGST&nbsp;&nbsp;:&nbsp;&nbsp;<span style="font-family:sans-serif;font-size:10px;">&#8377</span>&nbsp;<?php echo htmlspecialchars_decode($row['cgstrev']);?>&nbsp;&nbsp;&nbsp;&nbsp;
SGST&nbsp;&nbsp;:&nbsp;&nbsp;<span style="font-family:sans-serif;font-size:10px;">&#8377</span>&nbsp;<?php echo htmlspecialchars_decode($row['sgstrev']);?>&nbsp;&nbsp;&nbsp;&nbsp;
IGST&nbsp;&nbsp;:&nbsp;&nbsp;<span style="font-family:sans-serif; font-size: 10px;">&#8377</span>&nbsp;<?php echo htmlspecialchars_decode($row['igstrev']);?>
</td>
<td style="text-align:left;"><label>IGST</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;"><span style="font-family:sans-serif; font-size: 12px;">&#8377</span>&nbsp;
<?php echo $igstamt;?></td>
</tr> 
<!-- <tr>
<td style="text-align:left;"><label>CESS</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;"><span style="font-family:sans-serif; font-size: 12px;">&#8377</span>&nbsp;<?php echo htmlspecialchars_decode($row['totalcessamt']);?></td>
</tr> -->

<tr>
<td colspan="7" rowspan="3" style="vertical-align:middle;text-align:justify;">
<label>Notes&nbsp;:&nbsp;</label>&nbsp;&nbsp;<?php echo htmlspecialchars_decode($row['notes']);?> 
</td>
<td style="text-align:left;"><label>Round Off</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;"><span style="font-family:sans-serif;font-size:12px;">&#8377</span>&nbsp;
<?php 
if(($row['roundoff']=="")||($row['roundoff']=='0.00'))
{ 
echo "0.00";
}
else if($row['roundoff']>'0')
{ 
echo $roundoffvalue;
} ?>
</td>
</tr>
<tr>
<td style="text-align:left;"><label>Total Amount</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;"><span style="font-family:sans-serif; font-size: 12px;">&#8377</span>&nbsp;<?php echo htmlspecialchars_decode($totalrs_wocess);?></td>
</tr>

<tr>
<td style="text-align:left;"><label>Discounted Amount</label></td>
<td style="text-align:right;font-weight:550;color:black;font-size:12px;">
<span style="font-family:sans-serif;font-size:10px;">&#8377</span>
<?php echo $discountamt1;?>
</td>
</tr>
<tr>
<td colspan="3" style="vertical-align:middle;text-align:justify;">
<label>Terms & Condition&nbsp;:&nbsp;</label><br><?php echo htmlspecialchars_decode($row['termsandcond']);?>
</td>
<td colspan="5">
Bank Name&nbsp;:&nbsp;&nbsp;&nbsp;<?php echo $bankname;?><br>
Bank Branch&nbsp;:&nbsp;&nbsp;&nbsp;<?php echo $branch;?><br>
Account No.&nbsp;:&nbsp;&nbsp;&nbsp;<?php echo $accno;?><br>
IFSC Code&nbsp;:&nbsp;&nbsp;&nbsp;<?php echo $ifsc;?><br>
MICR Code&nbsp;:&nbsp;&nbsp;&nbsp;<?php echo $micr;?>
</td>
<td colspan="2" style="vertical-align:bottom;text-align:right;">

<!--displaying digital signature of the person who will approve the salesinvoice -->
<?php 
$retap=mysql_query("select * from salesinvoice_reg where id='".$_GET['cid']."' and hodstatus='Approved'");
while($rwap=mysql_fetch_array($retap))
{
$hodremarkby=$rwap['hodrmkby'];

//fetching digital signature of the person who has approved the salesinvoice from salesinvoice_setting table
$retap1=mysql_query("select * from salesinvoice_setting order by id desc limit 1");
while($rwap1=mysql_fetch_array($retap1))
{
if($rwap1['siapprovalby']== $rwap['hodrmkby'])
{
$cfile1=$rwap1['dig_signature'];
if($cfile1==""  )
{

}
else if($cfile1=="NULL"||$cfile1=="default.png")
{
echo "No Attachments";
}
else
{
$cfile2=pathinfo($rwap1['dig_signature']);
$cfile2['extension'];
$cool_extensions = Array('doc','docx','DOCX','DOC');
$cool_extensions1 = Array('pdf','PDF');
$cool_extensions2=Array('xls','xlsx','XLS','XLSX');
$cool_extensions3=Array('jpg','png','jpeg','JPG','JPEG','PNG');
if (in_array($cfile2['extension'], $cool_extensions))
{ ?>
<img src="complaintdocs/doc.png" style="height:40px;width:45px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" target="_blank"></a>
<?php
}
else if(in_array($cfile2['extension'], $cool_extensions1))
{ ?>
<img src="complaintdocs/pdf.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions2))
{ ?>
<img src="complaintdocs/xls.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions3))
{
?>  
<img style="width:50px;height:30px;"src="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" ?>&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" target="_blank"></a><br>
<?php 
}else{ ?>
<img src="complaintdocs/unknown.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature']);?>" target="_blank"></a>
<?php }
} ?>

<?php }
else if($rwap1['siapprovalby']== $rwap['hodrmkby'])
{
$cfile1=$rwap1['dig_signature2'];
if($cfile1==""  )
{

}
else if($cfile1=="NULL"||$cfile1=="default.png")
{
echo "No Attachments";
}
else
{
$cfile2=pathinfo($rwap1['dig_signature2']);
$cfile2['extension'];
$cool_extensions = Array('doc','docx','DOCX','DOC');
$cool_extensions1 = Array('pdf','PDF');
$cool_extensions2=Array('xls','xlsx','XLS','XLSX');
$cool_extensions3=Array('jpg','png','jpeg','JPG','JPEG','PNG');
if (in_array($cfile2['extension'], $cool_extensions))
{ ?>
<img src="complaintdocs/doc.png" style="height:40px;width:45px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" target="_blank"></a>
<?php
}
else if(in_array($cfile2['extension'], $cool_extensions1))
{ ?>
<img src="complaintdocs/pdf.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions2))
{ ?>
<img src="complaintdocs/xls.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" target="_blank"></a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions3))
{
?>  
<img style="width:50px;height:30px;"src="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" ?>&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" target="_blank"></a><br>
<?php 
}else{ ?>
<img src="complaintdocs/unknown.png" style="height:40px;width:40px;">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rwap1['dig_signature2']);?>" target="_blank"></a>
<?php } } ?>
<?php }
}
}
?>
<label style="font-size:10px;">Authorized Signatory</label>
</td>
</tr>
</table> 
</div>


<?php } ?> <!-- else closing of if cess_applicability==No -->


<?php } ?> <!--end of $rwap2 from select * from salesinvoice_setting for cess_applicability -->
<br>

<label style="font-family:'Poppins',sans-serif;">Supporting File&nbsp;:&nbsp;</label>
<?php 
$cfile1=$row['attachfile'];
if($cfile1=="")
{ ?>
<span style="font-size:10px;font-family:'Poppins',sans-serif;font-weight:500;color:black;">No Attachments</span>
<?php }
else if($cfile1=="NULL"||$cfile1=="default.png")
{ ?>
<span style="font-size:10px;font-family:'Poppins',sans-serif;font-weight:500;color:black">No Attachments</span>
<?php }
else
{ 
$cfile2=pathinfo($row['attachfile']);
$cfile2['extension'];
$cool_extensions = Array('doc','docx','DOCX','DOC');
$cool_extensions1 = Array('pdf','PDF');
$cool_extensions2=Array('xls','xlsx','XLS','XLSX');
$cool_extensions3=Array('jpg','png','jpeg','JPG','JPEG','PNG');
?>

<?php
if (in_array($cfile2['extension'], $cool_extensions))
{ ?>
<div class="imgfile">
<img src="complaintdocs/doc.png" style="height:35px;width:40px"><br>
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($row['attachfile']);?>" target="_blank">View File</a></div>
<?php
}
else if(in_array($cfile2['extension'], $cool_extensions1))
{ ?>
<div class="imgfile">
<img src="complaintdocs/pdf.png" style="height:35px;width:40px"><br>
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($row['attachfile']);?>" target="_blank">View File</a></div>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions2))
{ ?>
<div class="imgfile">
<img src="complaintdocs/xls.png" style="height:40px;width:40px"><br>
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($row['attachfile']);?>" target="_blank">View File</a></div>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions3))
{
?>  
<div class="imgfile">
<img style="width:50px;height:30px"src="purchaseorderfiles/<?php echo htmlentities($row['attachfile']);?>" ?>&nbsp;<br>
<a href="purchaseorderfiles/<?php echo htmlentities($row['attachfile']);?>" target="_blank">View File</a></div>
<?php 
}else{ ?>
<div class="imgfile">
<img src="complaintdocs/unknown.png" style="height:40px;width:40px"><br>
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($row['attachfile']);?>" target="_blank">View File</a></div>
<?php } } ?> 


<?php 
if($row['attachfile']!="")
{ ?>
<span id="hideclass" style="font-size:10px;font-family:'Poppins', sans-serif;display:none;">
Supporting File "<?php echo htmlentities($row['attachfile']);?>" is attached with this PO .Kindly print it seperately</span>
<?php } ?>

<br>
<table class="table table-sm" style="border:none;">
<tr>
<td style="text-align:center;border:none;padding:0px;width:800px;">
<label style="font-size:10px;">This is Computer Generated Invoice</label>
</td>
</tr>
<tr>
<?php 
$setting=mysql_query("select * from purchaseorder_setting order by id desc limit 1");
while($rowset=mysql_fetch_array($setting))
{ 
?>
<td style="border:none;padding:0px;">
<span style="color:black;font-weight:bold;font-family:Poppins,sans-serif;font-size:10px;"><?php echo htmlspecialchars_decode($rowset['isonoreg']);?></span>
<label style="color:black;font-family:Poppins,sans-serif;font-size:12px;">&nbsp;|&nbsp;Rev. No.</label>&nbsp;<span style="color:black;font-weight:bold;font-family:Poppins,sans-serif;font-size:10px;"><?php echo htmlspecialchars_decode($rowset['isorevnoreg']);?></span>
</td>
<?php  } ?>  
</tr>
</table>

<input type="text" id="formno" value="<?php echo htmlentities($_GET['cid']);?>" style="display:none;"> 

<br>
<button type="button" id="clickbut" class="view" onClick="displayhideactivity('activity')" style="width:100%;border:none;text-align:left;color:blue;font-size:17px;">Click to View Logs
</button>


<!-- view logs start-->
<div id="activity" style="display:none;">
<table class="table table-bordered table-sm" id="logtable">
<span id="loghead" style="color:black;font-weight:500;display:none;"><b>Activity Logs</b></span>   
<tr style="background-color: #0080FF;">
<th class="headcolor1" style="width:200px;">PO Created By</th>
<th class="headcolor1" style="width:200px">Created Date</th>
<th class="headcolor1" style="width:200px">Created Dept</th>
<th class="headcolor1" style="width:200px">PO Edited By</th>
<th class="headcolor1" style="width:200px">Edited Date</th>
<th class="headcolor1" style="width:200px">Edited Dept</th>
</tr>
<?php $ret=mysql_query("select * from purchaseorder_reg where pono='".$_GET['cid']."' limit 1");
while($rwadd=mysql_fetch_array($ret))
{

?>
<tr>
<td class="table1"><?php echo htmlentities($rwadd['reg_by']);?></td>
<td class="table1" style="text-align:left;"><?php echo htmlentities($rwadd['reg_date']);?></td>
<td class="table1" style="text-align: left;padding-left: 10px"><?php echo htmlentities($rwadd['reg_dept']);?></td>
<td class="table1" style="text-align: left;"><?php echo htmlentities($rwadd['edit_by']);?></td>
<td class="table1" style="text-align: left;"><?php echo htmlentities($rwadd['edit_date']);?></td>
<td class="table1" style="text-align: left;padding-left: 10px"><?php echo htmlentities($rwadd['edit_dept']);?></td>
</tr>
<?php } ?>
<tr style="background-color: #0080FF;">
<th>Approval Status</th>
<th>By</th>
<th>Of</th>
<th>On</th>
<th colspan="2">Remark</th>
</tr>
<?php 
$ret=mysql_query("select * from purchaseorder_hodapproval where pono='".$_GET['cid']."'");
while($rw=mysql_fetch_array($ret))
{
?>
<tr>     
<td class="table1"><?php echo htmlentities($rw['hodstatus']);?></td>
<td class="table1" style="text-align: left;"><?php echo htmlentities($rw['remarkby']);?></td>
<td class="table1" style="text-align: left;">
<?php echo htmlentities($rw['department']);?></td>
<td class="table1" style="text-align: left;">
<?php echo htmlentities($rw['remarkdate']);?></td>
<td class="table1" colspan="2" style="text-align: justify;">
<p><?php if($rw['hodremark']==""){ ?><a><?php echo "NO Comment"; ?> </a><?php } else{?><?php echo  htmlspecialchars_decode($rw['hodremark']); ?><?php } ?></p>  
</td> 
</tr>
<?php } ?>
<tr style="background-color: #0080FF;">
<th>Management Status</th>
<th>By</th>
<th>Of</th>
<th>On</th>
<th colspan="2">Remark</th>
</tr>
<?php 
$ret=mysql_query("select * from purchaseorder_mgmtapproval where pono='".$_GET['cid']."'");
while($rw=mysql_fetch_array($ret))
{
?>
<tr>     
<td class="table1"><?php echo htmlentities($rw['mgmtstatus']);?></td>
<td class="table1" style="text-align: left;"><?php echo htmlentities($rw['remarkby']);?></td>
<td class="table1" style="text-align: left;">
<?php echo htmlentities($rw['department']);?></td>
<td class="table1" style="text-align: left;">
<?php echo htmlentities($rw['remarkdate']);?></td>
<td class="table1" colspan="2" style="text-align: justify;">
<p><?php if($rw['mgmtremark']==""){ ?><a><?php echo "NO Comment"; ?> </a><?php } else{?><?php echo  htmlspecialchars_decode($rw['mgmtremark']); ?><?php } ?></p>  
</td> 
</tr>
<?php } ?>

</table>
</div>

<!-- footer to always add page break after each copy is printed-->
<footer></footer>

<?php
$sono2=$_GET['cid'];
?>
<input type="text" id="sono2" value="<?php echo $sono2 ?>" class="form-control" readonly="" style="display:none;" /> 

</div><!--div id="report" close -->

<br><br>

<hr style="color:black;">


<!-- <div class="col-md-3"> 
<a id="reportprint" target="_blank"><button type="submit" class="btn btn-info"><span><i class="fa fa-print"></i>&nbsp;Preview</span></button></a>
</div> -->




<!-- take action start-->
<?php 
$queryacc=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($rowacc=mysql_fetch_array($queryacc)) 
{
?> 
<ul class="nav nav-tabs" role="tablist">
<?php
$query21=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($row21=mysql_fetch_array($query21)) 
{  
$complaintarr1=$row21['purchaseorderaccess'];
$comarr1=explode(',',trim( $complaintarr1));
$secondaryarr1=$row21['multidept'];
$secarr2=explode(',',trim($secondaryarr1));
//to remove last comma from multidept array
$lastcomma = '';
foreach($secarr2 as $i=>$k) 
{
$lastcomma .= $k.',';
}
$lastcomma = rtrim($lastcomma,',');
$secarr1=explode(',',trim($lastcomma));
$querydays1=mysql_query("select * from purchaseorder_setting order by id desc limit 1");
while($rowdays1=mysql_fetch_array($querydays1)) 
{ 
$quadept1=$rowdays1['approvebyhod'];
$qua1=explode(',',trim($quadept1));
$result1 = array_intersect($secarr1,$qua1);
if((($result1!=array())||(in_array($row21['department'],$qua1))) && (in_array('takeactionpurchaseorder',$comarr1)))
{  
if($rowdays1['hod_approve']=='Yes')
{ ?>

<div class="row">
<div class="col-md-3">  
<a href="purchaseorder_hodapproval.php?cid=<?php echo $_GET['cid'];?>" class='li-modal'>
<button class="btn btn-primary">Take Action </button></a><br><br>
</div><div id="theModal" class="modal fade text-center">
<div class="modal-dialog">
<div class="modal-content">
</div>
</div>
</div>
</div>

<?php 
} }else
{

} } } } ?>
</ul>
<!--take action end -->


</div>
</div>

<?php 
}  // select * from purchaseorder_reg 
?>

</div>
</div>
</div></div></div>
<?php 
include("includes/footer.php");
?>
<script src="assets/plugins/jquery/jquery.min.js"></script>
<script src="main/js/jquery-ui.js"></script>
<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="main/js/jquery.slimscroll.js"></script>
<script src="main/js/waves.js"></script>
<script src="main/js/sidebarmenu.js"></script>
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<script src="main/js/custom.min.js"></script>
<script src="assets/plugins/chartist-js/dist/chartist.min.js"></script>
<script src="assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
<script src="assets/plugins/raphael/raphael-min.js"></script>
<script src="assets/plugins/morrisjs/morris.min.js"></script>
<script src="assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
<script src="assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="assets/plugins/wizard/jquery.steps.min.js"></script>
<script src="assets/plugins/wizard/jquery.validate.min.js"></script>
<script src="assets/plugins/sweetalert/sweetalert.min.js"></script>
<script src="assets/plugins/wizard/steps.js"></script>
<script src="main/js/dashboard2.js"></script>
<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
<script src="assets/datatables/jquery.dataTables.min.js"></script>

<script>
$('.li-modal').on('click', function(e){
e.preventDefault();
$('#theModal').modal('show').find('.modal-content').load($(this).attr('href'));
});
</script>



<!-- display total amount in words-->

<script type="text/javascript">
var a = ['','One ','Two ','Three ','Four ', 'Five ','Six ','Seven ','Eight ','Nine ','Ten ','Eleven ','Twelve ','Thirteen ','Fourteen ','Fifteen ','Sixteen ','Seventeen ','Eighteen ','Nineteen '];
var b = ['', '', 'Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];

function inWords (num) {
if ((num = num.toString()).length > 9) return 'overflow';
n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
if (!n) return; var str = '';
str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'Crore ' : '';
str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'Lakh ' : '';
str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'Thousand ' : '';
str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'Hundred ' : '';
str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + ' ' : '';
return str;
}
document.getElementById('words').innerHTML = inWords(document.getElementById('number').value);
</script>


<!-- on click display activity logs-->

<script type="text/javascript">
function displayhideactivity(ele6) {
var srcElement = document.getElementById(ele6);

if (srcElement != null) {
if (srcElement.style.display == "block") {
srcElement.style.display = 'none';
}
else {
srcElement.style.display = 'block';

}
return false;
}
}

</script>
<script type="text/javascript">
$('.view').click(function(){
var $this = $(this);
$this.toggleClass('view');
if($this.hasClass('view')){
$this.text('Click to View Logs');     
} else {
$this.text('Activity Logs');
}
});
</script>

<!-- only print -->
<script>
$('#reportprint3').click(function(){

var children = $('#report tr.child').length;
var visibleChildren = $('#report tr.child:visible').length;

var style = "<style>";
style = style + "footer {page-break-after: always;}";

// style = style + ".header{position:fixed;z-index:1;left:0;right:0;top:0;background-color:lightgray;}";
// style = style + "#cusdetails3{margin-top:300px;overflow:visible;}";

style = style + "table {font-family:'Poppins',sans-serif;}";
style = style + "label {color:black;font-weight:550;font-size:12px;display:inline;}";

style = style + "#cusdetails3 td{border-bottom:solid 1px #7f7f7f;font-size:9px; color:black;font-weight:410;margin-bottom:0.1rem;padding:1px;}";
style = style + "#cusdetails3 th{ border-bottom:solid 1px #7f7f7f;font-size:9px;color:white;font-weight:500;margin-bottom:0.1rem;padding: 0px;}";

style = style + "#logtable td{ border:solid 1px #7f7f7f;color:black;font-weight:500;text-align:center;font-size:10px;}";
style = style + "#logtable th{  border:solid 1px #7f7f7f;color:white;font-weight:500;text-align:center;font-size:10px;}";

style = style + "#cusdetails td{font-weight:400;color: black;font-size:12px;vertical-align:middle;border:none;padding:0px;}";

style = style + "#vendor td{font-weight:400;color: black;font-size:12px;vertical-align:middle;border:none;padding:0px;}";

style = style + "#headdet td{border:solid 1px #7f7f7f;font-weight:400;color: black;font-size:11px;padding:5px;}";

style = style + "div.imgfile{ display:none;}";
style = style + "div.tdfile{ display:none;}";

style = style + "table, th, td {border-collapse:collapse;padding:2px 3px;}";
style = style + "</style>";

var formno = document.getElementById("formno").value;
var a3 = document.getElementById("clickbut");
a3.style.display = "none";

var a7 = document.getElementById("hideclass");
a7.style.display = "block";

var companydetails = document.getElementById("companydetails");
companydetails.style.display = "block";

var divToPrint=document.getElementById("report");
var win = window.open('', '', 'height=900,width=1200');

win.document.write('<html><head>');
win.document.write('<title> Purchase_Order_No.'+'_'+formno+'</title>'); 
win.document.write(style); 
win.document.write('</head>');
win.document.write('<body>');
win.document.write(divToPrint.outerHTML);
win.document.write('</body></html>');

win.print();
//win.close();  // AUTO CLOSE THE CURRENT WINDOW.
location.reload();
$('#report tr.child').hide();  

});
</script>

<!-- -->
<script type="text/javascript">
$(document).ready(function(){
// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard').smartWizard({
selected: 0,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>
<script type="text/javascript">
$(document).ready(function(){

// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard1').smartWizard({
selected: 1,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>
<script type="text/javascript">
$(document).ready(function(){

// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard2').smartWizard({
selected: 2,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>

<script type="text/javascript">
$(document).ready(function(){

// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard3').smartWizard({
selected: 3,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>

<script>
$(document).on('click', '#refresh', function () {
var $link = $('li.active a[data-toggle="tab"]');
$link.parent().removeClass('active');
var tabLink = $link.attr('href');
$('#mainTabs a[href="' + tabLink + '"]').tab('show');
});

$('a[data-toggle="tab"]').on('shown.bs.tab', function () {
$('.show-time').html(new Date().toLocaleTimeString());
});</script>
<script>
function myFunction() {
location.reload();
}
</script>
<link rel="stylesheet" href="assets/plugins/html5-editor/bootstrap-wysihtml5.css" >
</body>
</html>


