-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2021 at 06:33 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `finalcms`
--

-- --------------------------------------------------------

--
-- Table structure for table `purchaseorder_reg`
--

CREATE TABLE `purchaseorder_reg` (
  `id` int(255) NOT NULL,
  `pono` varchar(500) NOT NULL,
  `podate` varchar(255) NOT NULL,
  `suppliername` varchar(255) NOT NULL,
  `supplierid` varchar(255) NOT NULL,
  `billingaddress` varchar(600) NOT NULL,
  `shippingaddress` varchar(600) NOT NULL,
  `sameasbill` varchar(50) NOT NULL,
  `ssid` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contactno` varchar(255) NOT NULL,
  `shippingtype` varchar(255) NOT NULL,
  `vendorcode` varchar(255) NOT NULL,
  `paymentterm` varchar(255) NOT NULL,
  `deliverymode` varchar(255) NOT NULL,
  `freight` varchar(200) NOT NULL,
  `termsandcond` varchar(500) NOT NULL,
  `notes` varchar(500) NOT NULL,
  `attachfile` varchar(255) NOT NULL,
  `subtotal` varchar(200) NOT NULL,
  `cgstvalue` varchar(200) NOT NULL,
  `sgstvalue` varchar(200) NOT NULL,
  `igstvalue` varchar(200) NOT NULL,
  `totalcess` varchar(200) NOT NULL,
  `roundoff` varchar(200) NOT NULL,
  `totalrs` varchar(200) NOT NULL,
  `partname` varchar(100) NOT NULL,
  `partnameid` varchar(100) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `hsncode` varchar(255) NOT NULL,
  `reqqty` varchar(255) NOT NULL,
  `shortageby` varchar(255) NOT NULL,
  `poqty` varchar(255) NOT NULL,
  `unit` varchar(255) NOT NULL,
  `deliverydate` varchar(255) NOT NULL,
  `unitprice` varchar(255) NOT NULL,
  `discount` varchar(255) NOT NULL,
  `tax` varchar(255) NOT NULL,
  `cgstper` varchar(255) NOT NULL,
  `sgstper` varchar(255) NOT NULL,
  `igstper` varchar(255) NOT NULL,
  `cesstype` varchar(255) NOT NULL,
  `cess_cgstper` varchar(255) NOT NULL,
  `cess_sgstper` varchar(255) NOT NULL,
  `cess_igstper` varchar(255) NOT NULL,
  `cessamt` varchar(255) NOT NULL,
  `totalprice` varchar(255) NOT NULL,
  `totalpr_wo_dis` varchar(255) NOT NULL,
  `cgstamt` varchar(255) NOT NULL,
  `sgstamt` varchar(255) NOT NULL,
  `igstamt` varchar(255) NOT NULL,
  `orderstatus` varchar(255) NOT NULL,
  `purchasedqty` varchar(255) NOT NULL,
  `pendingqty` varchar(255) NOT NULL,
  `purchase_percent` varchar(255) NOT NULL,
  `priority` varchar(255) NOT NULL,
  `statusdate` varchar(255) NOT NULL,
  `statusreason` varchar(255) NOT NULL,
  `statusremark` varchar(255) NOT NULL,
  `rejqty` varchar(255) NOT NULL,
  `rej_percent` varchar(255) NOT NULL,
  `reg_by` varchar(200) NOT NULL,
  `reg_dept` varchar(255) NOT NULL,
  `reg_id` varchar(200) NOT NULL,
  `reg_date` varchar(200) NOT NULL,
  `edit_by` varchar(200) NOT NULL,
  `edit_dept` varchar(255) NOT NULL,
  `edit_id` varchar(200) NOT NULL,
  `edit_date` varchar(200) NOT NULL,
  `hodstatus` varchar(255) NOT NULL,
  `hodremark` varchar(300) NOT NULL,
  `hoddept` varchar(255) NOT NULL,
  `hodrmkdate` varchar(255) NOT NULL,
  `hodrmkid` varchar(255) NOT NULL,
  `hodrmkby` varchar(255) NOT NULL,
  `mgmt_status` varchar(255) NOT NULL,
  `mgmt_remark` varchar(300) NOT NULL,
  `mgmt_dept` varchar(255) NOT NULL,
  `mgmt_rmkdate` varchar(255) NOT NULL,
  `mgmt_rmkid` varchar(255) NOT NULL,
  `mgmt_rmkby` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchaseorder_reg`
--

INSERT INTO `purchaseorder_reg` (`id`, `pono`, `podate`, `suppliername`, `supplierid`, `billingaddress`, `shippingaddress`, `sameasbill`, `ssid`, `gstno`, `email`, `contactno`, `shippingtype`, `vendorcode`, `paymentterm`, `deliverymode`, `freight`, `termsandcond`, `notes`, `attachfile`, `subtotal`, `cgstvalue`, `sgstvalue`, `igstvalue`, `totalcess`, `roundoff`, `totalrs`, `partname`, `partnameid`, `drawingno`, `remark`, `hsncode`, `reqqty`, `shortageby`, `poqty`, `unit`, `deliverydate`, `unitprice`, `discount`, `tax`, `cgstper`, `sgstper`, `igstper`, `cesstype`, `cess_cgstper`, `cess_sgstper`, `cess_igstper`, `cessamt`, `totalprice`, `totalpr_wo_dis`, `cgstamt`, `sgstamt`, `igstamt`, `orderstatus`, `purchasedqty`, `pendingqty`, `purchase_percent`, `priority`, `statusdate`, `statusreason`, `statusremark`, `rejqty`, `rej_percent`, `reg_by`, `reg_dept`, `reg_id`, `reg_date`, `edit_by`, `edit_dept`, `edit_id`, `edit_date`, `hodstatus`, `hodremark`, `hoddept`, `hodrmkdate`, `hodrmkid`, `hodrmkby`, `mgmt_status`, `mgmt_remark`, `mgmt_dept`, `mgmt_rmkdate`, `mgmt_rmkid`, `mgmt_rmkby`) VALUES
(1, '1', '22-12-2020 03:54:40', 'Grayline Castings', '8', '', '', '', '13', '', '', '', '', '', '30 Days', 'Air', 'Paid', 'jhj', 'kjhkj', 'Supporting_Document1_20201222155440.pdf', '2817.36', '169.04', '169.04', '0.00', '30.43', '0.00', '3185.87', 'Gear Box 200', '13', 'GB200', '', '8431', '6', '89', '52', 'Kg', '18-12-2020', '63', '14', '6+6', '6', '6', '0', '18% on CGST', '18', '', '', '30.43', '2817.36', '3276.00', '169.04', '169.04', '0.00', 'Open', '', '', '', '', '', '', '', '', '', 'Admin Snehal', 'Development', '1', '22-12-2020 03:54:40', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(2, '2', '25-12-2020 05:42:25', 'Indus Engineering', '4', '', '', '', '13', '', '', '', '', '', '30 Days', 'Air', 'Paid', 'nvb', 'ghj', 'default.png', '24080.00', '1444.80', '1444.80', '0.00', '0.00', '0.00', '26969.60', 'Copper Tube 10mm', '2', '10mm', 'hfgh', '7407', '12', '6', '80', 'Kg', '25-12-2020', '350.00', '14', '6+6', '6', '6', '0', '0', '', '', '', '', '24080.00', '28000.00', '1444.80', '1444.80', '0.00', 'Open', '', '', '', '', '', '', '', '', '', 'Admin Snehal', 'Development', '1', '25-12-2020 05:38:45', 'Admin Snehal', 'Development', '1', '25-12-2020 05:42:25', '', '', '', '', '', '', '', '', '', '', '', ''),
(3, '3', '29-12-2020 12:59:35', 'Nexgen Plastics', '3', '', '', '', '14', '', '', '', '', '1245', '30 Days', 'Air', 'To Pay', 'gdfg', 'gfdfg', 'Supporting_Document3_20201229125935.PDF', '3614.63', '207.51', '207.51', '65.45', '43.88', '0.00', '4138.98', 'Knob Sleek -1', '1', 'KS1000', '', '3920', '', '', '12', 'No&#039;s', '', '67', '2', '9+9', '9', '9', '0', '18% on CGST', '18', '', '', '12.76', '787.92', '804.00', '70.91', '70.91', '0.00', 'Open', '', '', '', '', '', '', '', '', '', 'Admin Snehal', 'Development', '1', '29-12-2020 12:59:35', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(4, '3', '29-12-2020 12:59:35', 'Nexgen Plastics', '3', '', '', '', '14', '', '', '', '', '1245', '30 Days', 'Air', 'To Pay', 'gdfg', 'gfdfg', 'Supporting_Document3_20201229125935.PDF', '3614.63', '207.51', '207.51', '65.45', '43.88', '0.00', '4138.98', 'Knob Sleek -1', '1', 'KS1000', '', '3920', '', '', '15', 'No&#039;s', '', '45.5', '6.9', '9+9', '9', '9', '0', '18% on CGST', '18', '', '', '10.29', '635.41', '682.50', '57.19', '57.19', '0.00', 'Open', '', '', '', '', '', '', '', '', '', 'Admin Snehal', 'Development', '1', '29-12-2020 12:59:35', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(5, '3', '29-12-2020 12:59:35', 'Nexgen Plastics', '3', '', '', '', '14', '', '', '', '', '1245', '30 Days', 'Air', 'To Pay', 'gdfg', 'gfdfg', 'Supporting_Document3_20201229125935.PDF', '3614.63', '207.51', '207.51', '65.45', '43.88', '0.00', '4138.98', 'Knob Sleek -1', '1', 'KS1000', '', '3920', '', '', '12', 'No&#039;s', '', '80.8', '9', '9+9', '9', '9', '0', '18% on CGST', '18', '', '', '14.29', '882.34', '969.60', '79.41', '79.41', '0.00', 'Open', '', '', '', '', '', '', '', '', '', 'Admin Snehal', 'Development', '1', '29-12-2020 12:59:35', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(6, '3', '29-12-2020 12:59:35', 'Nexgen Plastics', '3', '', '', '', '14', '', '', '', '', '1245', '30 Days', 'Air', 'To Pay', 'gdfg', 'gfdfg', 'Supporting_Document3_20201229125935.PDF', '3614.63', '207.51', '207.51', '65.45', '43.88', '0.00', '4138.98', 'Knob Sleek -1', '1', 'KS1000', '', '3920', '', '', '18', 'No&#039;s', '', '90.9', '20', '5', '0', '0', '5', '10% on IGST', '', '', '10', '6.54', '1308.96', '1636.20', '0.00', '0.00', '65.45', 'Open', '', '', '', '', '', '', '', '', '', 'Admin Snehal', 'Development', '1', '29-12-2020 12:59:35', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `purchaseorder_reg`
--
ALTER TABLE `purchaseorder_reg`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `purchaseorder_reg`
--
ALTER TABLE `purchaseorder_reg`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
