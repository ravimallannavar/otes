-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2021 at 06:33 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `finalcms`
--

-- --------------------------------------------------------

--
-- Table structure for table `purchaseorder_setting`
--

CREATE TABLE `purchaseorder_setting` (
  `id` int(20) NOT NULL,
  `poapprovalby` varchar(255) NOT NULL,
  `poapprovalby2` varchar(255) NOT NULL,
  `poapprovalby3` varchar(255) NOT NULL,
  `creationby` varchar(255) NOT NULL,
  `creationid` varchar(255) NOT NULL,
  `creationdate` varchar(255) NOT NULL,
  `updatedby` varchar(255) NOT NULL,
  `updatedid` varchar(255) NOT NULL,
  `updateddate` varchar(255) NOT NULL,
  `hod_approve` varchar(255) NOT NULL,
  `mgmt_approve` varchar(255) NOT NULL,
  `po_regdept` varchar(255) NOT NULL,
  `costviewdept` varchar(255) NOT NULL,
  `approvebyhod` varchar(255) NOT NULL,
  `approvebymgmt` varchar(255) NOT NULL,
  `filesize` varchar(255) NOT NULL,
  `totalsize` varchar(255) NOT NULL,
  `filetype` varchar(255) NOT NULL,
  `filesize2` varchar(255) NOT NULL,
  `tax` varchar(255) NOT NULL,
  `purchase_cap` varchar(255) NOT NULL,
  `purchase_year` varchar(255) NOT NULL,
  `isoformatno` varchar(255) NOT NULL,
  `isoformatrevno` varchar(255) NOT NULL,
  `isonoreg` varchar(255) NOT NULL,
  `isorevnoreg` varchar(255) NOT NULL,
  `dig_signature` varchar(255) NOT NULL,
  `dig_signature2` varchar(255) NOT NULL,
  `dig_signature3` varchar(255) NOT NULL,
  `digsig_yesno` varchar(100) NOT NULL,
  `cess_applicability` varchar(100) NOT NULL,
  `mandatorynote1` varchar(500) NOT NULL,
  `mandatorynote2` varchar(500) NOT NULL,
  `mandatorynote3` varchar(500) NOT NULL,
  `mandatorynote4` varchar(500) NOT NULL,
  `mandatorynote5` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchaseorder_setting`
--

INSERT INTO `purchaseorder_setting` (`id`, `poapprovalby`, `poapprovalby2`, `poapprovalby3`, `creationby`, `creationid`, `creationdate`, `updatedby`, `updatedid`, `updateddate`, `hod_approve`, `mgmt_approve`, `po_regdept`, `costviewdept`, `approvebyhod`, `approvebymgmt`, `filesize`, `totalsize`, `filetype`, `filesize2`, `tax`, `purchase_cap`, `purchase_year`, `isoformatno`, `isoformatrevno`, `isonoreg`, `isorevnoreg`, `dig_signature`, `dig_signature2`, `dig_signature3`, `digsig_yesno`, `cess_applicability`, `mandatorynote1`, `mandatorynote2`, `mandatorynote3`, `mandatorynote4`, `mandatorynote5`) VALUES
(1, '', '', '', 'Admin Snehal', '1', '2020-12-21 10:14:48', '', '', '', 'Yes', 'No', 'Account,Development,Dispatch,Human Resource and Administration,', 'Development,Dispatch,IT Admin,', 'Development,Dispatch,Human Resource and Administration,IT Admin,', '', '5', '5000000', '\".pdf,.jpg,.png\"', 'MBytes', '', '8541236', '2020', 'MKT-FM-14', '8 view', 'MKT-FM-05', '7 reg', 'default.png', 'default.png', 'default.png', 'No', '', 'PHP 8 represents a big milestone for developers, frameworks, and content management systems like WordPress. It introduces several new language constructs, that a', 'PHP 8 represents a big milestone for developers, frameworks, and content management systems like WordPress. It introduces several new language constructs, that a', 'PHP 8 represents a big milestone for developers, frameworks, and content management systems like WordPress. It introduces several new language constructs, that a', 'PHP 8 represents a big milestone for developers, frameworks, and content management systems like WordPress. It introduces several new language constructs, that a', 'PHP 8 represents a big milestone for developers, frameworks, and content management systems like WordPress. It introduces several new language constructs, that a');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `purchaseorder_setting`
--
ALTER TABLE `purchaseorder_setting`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `purchaseorder_setting`
--
ALTER TABLE `purchaseorder_setting`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
