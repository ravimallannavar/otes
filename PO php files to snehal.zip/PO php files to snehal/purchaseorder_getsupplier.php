
<?php
$conn = new mysqli('localhost', 'root', '', 'finalcms');
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}


//fetching address1 of supplier billing address
$country_id = ($_POST['country_id']);
if($country_id!='')
{
	$drawing_result = $conn->query('select * from supplier where id='.$_POST['country_id'].'');
	
	while($row = $drawing_result->fetch_assoc())
	{
		$options1 .= "<option value='".$row['address']."'>".$row['address']."</option>";
	}
	echo $options1;
}


//fetching address2,address3 of supplier billing address
$country_id1 = ($_POST['country_id1']);
if($country_id1!='')
{
	$drawing_result = $conn->query('select * from supplier where id='.$_POST['country_id1'].' ');
	while($row = $drawing_result->fetch_assoc())
    {
		$options1 .= "<option value='".$row['address2'].",".$row['address3']."'>".$row['address2'].",".$row['address3']."</option>";
	}
	echo $options1;
}

//fetching city,district,pincode of supplier billing address
$office4 = ($_POST['office4']);
if($office4!='')
{
	$drawing_result = $conn->query('select * from supplier where id='.$_POST['office4'].' ');
	while($row = $drawing_result->fetch_assoc())
    {
		$options1 .= "<option value='".$row['city'].",".$row['district'].",".$row['pincode']."'>".$row['city'].",".$row['district'].",".$row['pincode']."</option>";
	}
	echo $options1;
}


//fetching state and country of supplier billing address
$office5 = ($_POST['office5']);
if($office5!='')
{
	$drawing_result = $conn->query('select * from supplier where id='.$_POST['office5'].'');
	
	while($row = $drawing_result->fetch_assoc())
	{
		$options1 .= "<option value='".$row['state'].",".$row['country']."'>".$row['state'].",".$row['country']."</option>";
	}
	echo $options1;
}

//for shipping address
$country_id2 = ($_POST['country_id2']);
if($country_id2!='')
{
	$drawing_result = $conn->query('select * from supplier where id='.$_POST['country_id2'].' ');
	while($row = $drawing_result->fetch_assoc())
    {
		$options1 .= "<option value='".$row['address']."'>".$row['address']."</option>";
	}
	echo $options1;
}

$country_id3 = ($_POST['country_id3']);
if($country_id3!='')
{
	$drawing_result = $conn->query('select * from supplier where id='.$_POST['country_id3'].' ');
	while($row = $drawing_result->fetch_assoc())
    {
		$options1 .= "<option value='".$row['address2'].",".$row['address3']."'>".$row['address2'].",".$row['address3']."</option>";
	}
	echo $options1;
}

$shipadd3 = ($_POST['shipadd3']);
if($shipadd3!='')
{
	$drawing_result = $conn->query('select * from supplier where id='.$_POST['shipadd3'].' ');
	while($row = $drawing_result->fetch_assoc())
    {
		$options1 .= "<option value='".$row['city'].",".$row['district'].",".$row['pincode']."'>".$row['city'].",".$row['district'].",".$row['pincode']."</option>";
	}
	echo $options1;
}

$shipadd4 = ($_POST['shipadd4']);
if($shipadd4!='')
{
	$drawing_result = $conn->query('select * from supplier where id='.$_POST['shipadd4'].' ');
	while($row = $drawing_result->fetch_assoc())
    {
		$options1 .= "<option value='".$row['state'].",".$row['country']."'>".$row['state'].",".$row['country']."</option>";
	}
	echo $options1;
}

$officeaddstate = ($_POST['officeaddstate']);
if($officeaddstate!='')
{
	$drawing_result = $conn->query('select * from supplier where id='.$_POST['officeaddstate'].' ');
	while($row = $drawing_result->fetch_assoc())
    {
		$options1 .= "<option value='".$row['state']."'>".$row['state']."</option>";
	}
	echo $options1;
}

$completeadd = ($_POST['completeadd']);
if($completeadd!='')
{
	$drawing_result = $conn->query('select * from supplier where id='.$_POST['completeadd'].' ');
	while($row = $drawing_result->fetch_assoc())
    {
		$options1 .= "<option value='".$row['address1'].",".$row['address2'].",".$row['address3'].",".$row['city'].",".$row['district'].",".$row['state'].",".$row['pincode'].",".$row['country']."'>".$row['address1'].",".$row['address2'].",".$row['address3'].",".$row['city'].",".$row['district'].",".$row['state'].",".$row['pincode'].",".$row['country']."</option>";
	}
	echo $options1;
}

$gstin = ($_POST['gstin']);
if($gstin!='')
{
	$drawing_result = $conn->query('select * from supplier where id='.$_POST['gstin'].' ');
	while($row = $drawing_result->fetch_assoc())
    {
		$options1 .= "<option value='".$row['gstno']."'>".$row['gstno']."</option>";
	}
	echo $options1;
}

$email = ($_POST['email']);
if($email!='')
{
	$drawing_result = $conn->query('select * from supplier where id='.$_POST['email'].' ');
	while($row = $drawing_result->fetch_assoc())
    {
		$options1 .= "<option value='".$row['email']."'>".$row['email']."</option>";
	}
	echo $options1;
}

$contactno = ($_POST['contactno']);
if($contactno!='')
{
	$drawing_result = $conn->query('select * from supplier where id='.$_POST['contactno'].' ');
	while($row = $drawing_result->fetch_assoc())
    {
		$options1 .= "<option value='".$row['contactno']."'>".$row['contactno']."</option>";
	}
	echo $options1;
}

//fetching payment term on select of supplier name
$paymentterm = ($_POST['paymentterm']);
if($paymentterm!='')
{
	$drawing_result = $conn->query('select * from supplier where id='.$_POST['paymentterm'].' ');
	while($row = $drawing_result->fetch_assoc())
    {
		$options1 .= "<option value='".$row['payment_term']."'>".$row['payment_term']."</option>";
	}
	echo $options1;
}

//fetching vendorcode on select of supplier name
$vendorcode = ($_POST['vendorcode']);
if($vendorcode!='')
{
	$drawing_result = $conn->query('select * from supplier where id='.$_POST['vendorcode'].' ');
	while($row = $drawing_result->fetch_assoc())
    {
		$options1 .= "<option value='".$row['vendorcode']."'>".$row['vendorcode']."</option>";
	}
	echo $options1;
}


$productname = ($_POST['productname']);
if($productname!='')
{
	  	$query1 = $conn->query('select * from supplierproduct where supplierid='.$_POST['productname'].' ');
	  	$options = "<option value=''>Select</option>";
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['partnameid']."'>".$row1['partname']."</option>";
		}
		echo $options;
	
}


$partnameid = ($_POST['partnameid']);
if($partnameid!='')
{
	  	$query1 = $conn->query('select * from supplierproduct where partnameid='.$_POST['partnameid'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['partnameid']."'>".$row1['partnameid']."</option>";
		}
		echo $options;
	
}

$drawingno = ($_POST['drawingno']);
if($drawingno!='')
{
	  	$query1 = $conn->query('select * from supplierproduct where partnameid='.$_POST['drawingno'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['drawingno']."'>".$row1['drawingno']."</option>";
		}
		echo $options;
	
}

$hsncode = ($_POST['hsncode']);
if($hsncode!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['hsncode'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['hsncode']."'>".$row1['hsncode']."</option>";
		}
		echo $options;
	
}

$unit = ($_POST['unit']);
if($unit!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['unit'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['unit']."'>".$row1['unit']."</option>";
		}
		echo $options;
	
}


//filter shipping type on change of supplier name
$shippingtypeid = ($_POST['shippingtypeid']);
if($shippingtypeid!='')
{
	  	$query1 = $conn->query('select * from supplier_address where supplierid='.$_POST['shippingtypeid'].' ');
	  	$options = "<option value=''>Select Shipping Address</option>";
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['id']."'>".$row1['shipping_type']."</option>";
		}
		echo $options;
	
}

$shipadd8 = ($_POST['shipadd8']);
if($shipadd8!='')
{
	  	$query1 = $conn->query('select * from supplier_address where id='.$_POST['shipadd8'].' ');

	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['shipping_address']."'>".$row1['shipping_address']."</option>";
		}
		echo $options;
	
}

//trim only state for shipping address form supplier_address table
$shipadd9 = ($_POST['shipadd9']);
if($shipadd9!='')
{
	  	$query1 = $conn->query('select * from supplier_address where id='.$_POST['shipadd9'].' ');

	  	while($row1 = $query1->fetch_assoc())
	    { 
	      $pos = $row1['shipping_address'];
	      list($number1, $number2, $number3, $number4, $number5, $number6, $number7, $number8) = explode('<br>', $pos);
		   $options .= "<option value='".$number5."'>".$number5."</option>";
		}
		echo $options;
	
}


//fetching company name from supplier shipping address
$ship15 = ($_POST['ship15']);
if($ship15!='')
{
	  	$query1 = $conn->query('select * from company_address where id='.$_POST['ship15'].' ');

	  	while($row1 = $query1->fetch_assoc())
	    { 
	      $pos = $row1['shipping_address'];
	      list($number1, $number2, $number3, $number4, $number5, $number6, $number7, $number8) = explode('<br>', $pos);
		   $options .= "<option value='".$number1."'>".$number1."</option>";
		}
		echo $options;
	
}

//fetching address1 from supplier shipping address
$ship11 = ($_POST['ship11']);
if($ship11!='')
{
	  	$query1 = $conn->query('select * from company_address where id='.$_POST['ship11'].' ');

	  	while($row1 = $query1->fetch_assoc())
	    { 
	      $pos = $row1['shipping_address'];
	      list($number1, $number2, $number3, $number4, $number5, $number6, $number7, $number8) = explode('<br>', $pos);
		   $options .= "<option value='".$number2."'>".$number2."</option>";
		}
		echo $options;
	
}
//fetching address2 from supplier shipping address
$ship12 = ($_POST['ship12']);
if($ship12!='')
{
	  	$query1 = $conn->query('select * from company_address where id='.$_POST['ship12'].' ');

	  	while($row1 = $query1->fetch_assoc())
	    { 
	      $pos = $row1['shipping_address'];
	      list($number1, $number2, $number3, $number4, $number5, $number6, $number7, $number8) = explode('<br>', $pos);
		   $options .= "<option value='".$number3."'>".$number3."</option>";
		}
		echo $options;
	
}
//fetching city and pincode from supplier shipping address
$ship13 = ($_POST['ship13']);
if($ship13!='')
{
	  	$query1 = $conn->query('select * from company_address where id='.$_POST['ship13'].' ');

	  	while($row1 = $query1->fetch_assoc())
	    { 
	      $pos = $row1['shipping_address'];
	      list($number1, $number2, $number3, $number4, $number5, $number6, $number7, $number8) = explode('<br>', $pos);
		   $options .= "<option value='".$number4.",".$number7."'>".$number4.",".$number7."</option>";
		}
		echo $options;
	
}
//fetching state and country from supplier shipping address
$ship14 = ($_POST['ship14']);
if($ship14!='')
{
	  	$query1 = $conn->query('select * from company_address where id='.$_POST['ship14'].' ');

	  	while($row1 = $query1->fetch_assoc())
	    { 
	      $pos = $row1['shipping_address'];
	      list($number1, $number2, $number3, $number4, $number5, $number6, $number7, $number8) = explode('<br>', $pos);
		   $options .= "<option value='".$number5.",".$number6."'>".$number5.",".$number6."</option>";
		}
		echo $options;
	
}
//fetching gst no. from supplier shipping address
$ship16 = ($_POST['ship16']);
if($ship16!='')
{
	  	$query1 = $conn->query('select * from company_address where id='.$_POST['ship16'].' ');

	  	while($row1 = $query1->fetch_assoc())
	    { 
	      $pos = $row1['shipping_address'];
	      list($number1, $number2, $number3, $number4, $number5, $number6, $number7, $number8) = explode('<br>', $pos);
		   $options .= "<option value='".$number8."'>".$number8."</option>";
		}
		echo $options;
	
}

//fetching auto inc id from supplier shipping address
$ssid = ($_POST['ssid']);
if($ssid!='')
{
	  	$query1 = $conn->query('select * from company_address where id='.$_POST['ssid'].' ');

	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['id']."'>".$row1['id']."</option>";
		}
		echo $options;
	
}

//hsncode and unit for 2nd row
$hsncode1 = ($_POST['hsncode1']);
if($hsncode1!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['hsncode1'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['hsncode']."'>".$row1['hsncode']."</option>";
		}
		echo $options;
	
}

$unit1 = ($_POST['unit1']);
if($unit1!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['unit1'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['unit']."'>".$row1['unit']."</option>";
		}
		echo $options;
	
}

//hsncode and unit for 3rd row
$hsncode2 = ($_POST['hsncode2']);
if($hsncode2!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['hsncode2'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['hsncode']."'>".$row1['hsncode']."</option>";
		}
		echo $options;
	
}

$unit2 = ($_POST['unit2']);
if($unit2!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['unit2'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['unit']."'>".$row1['unit']."</option>";
		}
		echo $options;
	
}
//hsncode and unit for 4th row
$hsncode3 = ($_POST['hsncode3']);
if($hsncode3!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['hsncode3'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['hsncode']."'>".$row1['hsncode']."</option>";
		}
		echo $options;
	
}

$unit3 = ($_POST['unit3']);
if($unit3!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['unit3'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['unit']."'>".$row1['unit']."</option>";
		}
		echo $options;
	
}
//hsncode and unit for 5th row
$hsncode4 = ($_POST['hsncode4']);
if($hsncode4!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['hsncode4'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['hsncode']."'>".$row1['hsncode']."</option>";
		}
		echo $options;
	
}

$unit4 = ($_POST['unit4']);
if($unit4!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['unit4'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['unit']."'>".$row1['unit']."</option>";
		}
		echo $options;
	
}
//hsncode and unit for 6th row
$hsncode5 = ($_POST['hsncode5']);
if($hsncode5!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['hsncode5'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['hsncode']."'>".$row1['hsncode']."</option>";
		}
		echo $options;
	
}

$unit5 = ($_POST['unit5']);
if($unit5!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['unit5'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['unit']."'>".$row1['unit']."</option>";
		}
		echo $options;
	
}
//hsncode and unit for 7th row
$hsncode6 = ($_POST['hsncode6']);
if($hsncode6!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['hsncode6'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['hsncode']."'>".$row1['hsncode']."</option>";
		}
		echo $options;
	
}

$unit6 = ($_POST['unit6']);
if($unit6!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['unit6'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['unit']."'>".$row1['unit']."</option>";
		}
		echo $options;
	
}

//hsncode and unit for 8th row
$hsncode7 = ($_POST['hsncode7']);
if($hsncode7!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['hsncode7'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['hsncode']."'>".$row1['hsncode']."</option>";
		}
		echo $options;
	
}

$unit7 = ($_POST['unit7']);
if($unit7!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['unit7'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['unit']."'>".$row1['unit']."</option>";
		}
		echo $options;
	
}

//hsncode and unit for 9th row
$hsncode8 = ($_POST['hsncode8']);
if($hsncode8!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['hsncode8'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['hsncode']."'>".$row1['hsncode']."</option>";
		}
		echo $options;
	
}

$unit8 = ($_POST['unit8']);
if($unit8!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['unit8'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['unit']."'>".$row1['unit']."</option>";
		}
		echo $options;
	
}

//hsncode and unit for 10th row
$hsncode9 = ($_POST['hsncode9']);
if($hsncode9!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['hsncode9'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['hsncode']."'>".$row1['hsncode']."</option>";
		}
		echo $options;
	
}

$unit9 = ($_POST['unit9']);
if($unit9!='')
{
	  	$query1 = $conn->query('select * from drawing where id='.$_POST['unit9'].' ');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options .= "<option value='".$row1['unit']."'>".$row1['unit']."</option>";
		}
		echo $options;
	
}

?>