
<?php
$conn = new mysqli('localhost', 'root', '', 'finalcms');
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

$unitprice = ($_POST['unitprice']);
if($unitprice!='')
{
	  	$query1 = $conn->query('select * from supplierrc where part_id='.$_POST['unitprice'].' and rc_status="Valid"');
	  	while($row1 = $query1->fetch_assoc())
	    { 
		   $options=$row1["totalrerate"];
		   echo $options;
		}
		
	
}

?>