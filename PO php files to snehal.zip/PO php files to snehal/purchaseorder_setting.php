<?php 
error_reporting(E_ERROR | E_PARSE);
session_start();
if(!isset($_SESSION['id'],$_SESSION['department']))
{
header('location:index.php?lmsg=true');
exit;
}
require_once('includes/dbconfig.php');
include("includes/config.php");

?>
<?php
$timezone = 'Asia/Kolkata';
date_default_timezone_set($timezone);
$today = date('Y-m-d');
$year = date('Y');
if(isset($_GET['year'])){
$year = $_GET['year'];
}
?>
<!-- new dept insertion start-->
<?php
if(isset($_POST['newdept']))
{
$uid=$_SESSION['id'];
$name=$_SESSION['fullName'];

$purchase_year=$_POST['purchase_year'];
$purchase_year=htmlspecialchars($purchase_year,ENT_QUOTES);

$purchase_cap2=$_POST['purchase_cap'];
$purchase_cap2=htmlspecialchars($purchase_cap2,ENT_QUOTES);

$purchase_cap2= str_replace(array(',', 'US$', ' '), '', $purchase_cap2);
if($purchase_cap2=='0')
{
$purchase_cap = '0';
}
else
{
  $purchase_cap = ltrim($purchase_cap2, "0");
}

$hod_approve=$_POST['hod_approve'];
$hod_approve=htmlspecialchars($hod_approve,ENT_QUOTES);

$mgmt_approve=$_POST['mgmt_approve'];
$mgmt_approve=htmlspecialchars($mgmt_approve,ENT_QUOTES);

$po_regdept=$_POST['po_regdept'];
if($po_regdept=="")
{
$po_regdept1="";
}
else
{
$po_regdept1="";
foreach($po_regdept as $view)
{
$po_regdept1.=$view.",";
}
}

$costviewdept=$_POST['costviewdept'];
if($costviewdept=="")
{
$costviewdept1="";
}
else
{
$costviewdept1="";
foreach($costviewdept as $view)
{
$costviewdept1.=$view.",";
}
}

$approvebyhod=$_POST['approvebyhod'];
if($approvebyhod=="")
{
$approvebyhod1="";
}
else
{
$approvebyhod1="";
foreach($approvebyhod as $view)
{
$approvebyhod1.=$view.",";
}
}

$approvebymgmt=$_POST['approvebymgmt'];
if($approvebymgmt=="")
{
$approvebymgmt1="";
}
else
{
$approvebymgmt1="";
foreach($approvebymgmt as $view)
{
$approvebymgmt1.=$view.",";
}
}
$digsig_yesno=$_POST['digsig_yesno'];
$digsig_yesno=htmlspecialchars($digsig_yesno,ENT_QUOTES);

$poapprovalby=$_POST['poapprovalby'];
$poapprovalby=htmlspecialchars($poapprovalby,ENT_QUOTES);

$poapprovalby2=$_POST['poapprovalby2'];
$poapprovalby2=htmlspecialchars($poapprovalby2,ENT_QUOTES);

$poapprovalby3=$_POST['poapprovalby3'];
$poapprovalby3=htmlspecialchars($poapprovalby3,ENT_QUOTES);

//file setting
$filesize=$_POST['filesize'];
$filesize=htmlspecialchars($filesize,ENT_QUOTES);

$totalsize=$_POST['totalsize'];
$totalsize=htmlspecialchars($totalsize,ENT_QUOTES);

if($totalsize=="Bytes")
{
$totalsize=$filesize;
$ftype="Bytes";
}
else if($totalsize=="KBytes")
{
$totalsize=$filesize*1000;
$ftype="KBytes";
}
else if($totalsize=="MBytes")
{
$totalsize=$filesize*1000000;
$ftype="MBytes";
}
$filetype=$_POST['filetype'];
$filetype= htmlspecialchars($filetype, ENT_NOQUOTES);
$filetype2='"' . $filetype . '"';

$isoformatno=$_POST['isoformatno'];
$isoformatno=htmlspecialchars($isoformatno,ENT_QUOTES);
$newstr =str_replace('\\', '\\\\', $isoformatno);

$isoformatrevno=$_POST['isoformatrevno'];
$isoformatrevno=htmlspecialchars($isoformatrevno,ENT_QUOTES);
$newstr2 =str_replace('\\', '\\\\', $isoformatrevno);

//digital signature 1 start
$pathd=$_FILES['dig_signature']['name'];
$extd = pathinfo($pathd, PATHINFO_EXTENSION);
$based = pathinfo($pathd, PATHINFO_FILENAME);
if($based=="")
{
$dig_signature='default.png';
}
else
{
$sqlfile=mysql_query("select id from purchaseorder_setting order by id desc limit 1");
while($rowfile=mysql_fetch_array($sqlfile))
{
$cmpnfile=$rowfile['id'];
}
$complainnofile1=$cmpnfile+1;

$complainnofile2="Digital_Signature1".$complainnofile1;
$complainnofile3="_";
$complainnofileimg1=$complainnofile2.$complainnofile3;
$dig_signature= $complainnofileimg1.date("YmdHis.").$extd;

}
move_uploaded_file($_FILES["dig_signature"]["tmp_name"],"purchaseorderfiles/".$dig_signature);
//digital signature 1 end


//digital signature 2 start
$pathd8=$_FILES['dig_signature2']['name'];
$extd8 = pathinfo($pathd8, PATHINFO_EXTENSION);
$based8 = pathinfo($pathd8, PATHINFO_FILENAME);
if($based8=="")
{
$dig_signature2='default.png';
}
else
{
$sqlfile49=mysql_query("select id from purchaseorder_setting order by id desc limit 1");
while($rowfile50=mysql_fetch_array($sqlfile49))
{
$cmpnfile4=$rowfile50['id'];
}
$complainnofile14=$cmpnfile4+1;

$complainnofile29="Digital_Signature2".$complainnofile14;
$complainnofile39="_";
$complainnofileimg19=$complainnofile29.$complainnofile39;
$dig_signature2= $complainnofileimg19.date("dmYHis.").$extd8;

}
move_uploaded_file($_FILES["dig_signature2"]["tmp_name"],"purchaseorderfiles/".$dig_signature2); 
//digital signature 2 end


//digital signature 3 start
$pathd10=$_FILES['dig_signature3']['name'];
$extd10 = pathinfo($pathd10, PATHINFO_EXTENSION);
$based10 = pathinfo($pathd10, PATHINFO_FILENAME);
if($based10=="")
{
 $dig_signature3='default.png';
}
else
{
$sqlfile91=mysql_query("select id from purchaseorder_setting order by id desc limit 1");
while($rowfile91=mysql_fetch_array($sqlfile91))
{
 $cmpnfile91=$rowfile91['id'];
}
$complainnofile91=$cmpnfile91+1;

$complainnofile921="Digital_Signature3".$complainnofile91;
$complainnofile93="_";
$complainnofileimg91=$complainnofile921.$complainnofile93;
$dig_signature3= $complainnofileimg91.date("YmdHis.").$extd10;

}
move_uploaded_file($_FILES["dig_signature3"]["tmp_name"],"purchaseorderfiles/".$dig_signature3);

//digital signature 3 end

$isonoreg=$_POST['isonoreg'];
$isonoreg=htmlspecialchars($isonoreg,ENT_QUOTES);
$newstreg =str_replace('\\', '\\\\', $isonoreg);

$isorevnoreg=$_POST['isorevnoreg'];
$isorevnoreg=htmlspecialchars($isorevnoreg,ENT_QUOTES);
$newstreg2 =str_replace('\\', '\\\\', $isorevnoreg);

$mandatorynote1=$_POST['mandatorynote1'];
$mandatorynote1=htmlspecialchars($mandatorynote1,ENT_QUOTES);

$mandatorynote2=$_POST['mandatorynote2'];
$mandatorynote2=htmlspecialchars($mandatorynote2,ENT_QUOTES);

$mandatorynote3=$_POST['mandatorynote3'];
$mandatorynote3=htmlspecialchars($mandatorynote3,ENT_QUOTES);

$mandatorynote4=$_POST['mandatorynote4'];
$mandatorynote4=htmlspecialchars($mandatorynote4,ENT_QUOTES);

$mandatorynote5=$_POST['mandatorynote5'];
$mandatorynote5=htmlspecialchars($mandatorynote5,ENT_QUOTES);

date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt2=date("Y-m-d h:i:s");
$sql=mysql_query("insert into purchaseorder_setting(creationdate,creationid,creationby,filesize,totalsize,filetype,filesize2,poapprovalby,poapprovalby2,poapprovalby3,isoformatno,isoformatrevno,dig_signature,isonoreg,isorevnoreg,dig_signature2,dig_signature3,digsig_yesno,purchase_cap,purchase_year,hod_approve,mgmt_approve,po_regdept,costviewdept,approvebyhod,approvebymgmt,mandatorynote1,mandatorynote2,mandatorynote3,mandatorynote4,mandatorynote5) values('$dt2','$uid','$name','$filesize','$totalsize','$filetype2','$ftype','$poapprovalby','$poapprovalby2','$poapprovalby3','$newstr','$newstr2','$dig_signature','$newstreg','$newstreg2','$dig_signature2','$dig_signature3','$digsig_yesno','$purchase_cap','$purchase_year','$hod_approve','$mgmt_approve','$po_regdept1','$costviewdept1','$approvebyhod1','$approvebymgmt1','$mandatorynote1','$mandatorynote2','$mandatorynote3','$mandatorynote4','$mandatorynote5')");
if($sql=="")
{
echo '<script>				
setTimeout(function() {
swal({	
title: "Oops...!!!",
text: "Department Settings Insertion Unsuccessful.",
type: "warning"		
}, 
function() 
{
window.location = "purchaseorder_setting.php";
});
}, 1000);
</script>'; 	
}
else
{
echo '<script>				
setTimeout(function() {
swal({	
title: "Success!",
text: "Department Settings Inserted Successfully.",
type: "success"		
}, 
function() 
{
window.location = "purchaseorder_setting.php";
});
}, 1000);
</script>';    
}  
}
?>
<!-- new dept insertion end-->


<!-- dept updation start-->
<?php
if(isset($_POST['updatedept']))
{
$uid=$_SESSION['id'];
$name=$_SESSION['fullName'];
$masterid=$_POST['masterid'];

$purchase_year=$_POST['purchase_year'];
$purchase_year=htmlspecialchars($purchase_year,ENT_QUOTES);

$purchase_cap2=$_POST['purchase_cap'];
$purchase_cap2=htmlspecialchars($purchase_cap2,ENT_QUOTES);

$purchase_cap2= str_replace(array(',', 'US$', ' '), '', $purchase_cap2);
if($purchase_cap2=='0')
{
$purchase_cap = '0';
}
else
{
  $purchase_cap = ltrim($purchase_cap2, "0");
}

$hod_approve=$_POST['hod_approve'];
$hod_approve=htmlspecialchars($hod_approve,ENT_QUOTES);

$mgmt_approve=$_POST['mgmt_approve'];
$mgmt_approve=htmlspecialchars($mgmt_approve,ENT_QUOTES);

$po_regdept=$_POST['po_regdept'];
if($po_regdept=="")
{
$po_regdept1="";
}
else
{
$po_regdept1="";
foreach($po_regdept as $view)
{
$po_regdept1.=$view.",";
}
}

$costviewdept=$_POST['costviewdept'];
if($costviewdept=="")
{
$costviewdept1="";
}
else
{
$costviewdept1="";
foreach($costviewdept as $view)
{
$costviewdept1.=$view.",";
}
}

$approvebyhod=$_POST['approvebyhod'];
if($approvebyhod=="")
{
$approvebyhod1="";
}
else
{
$approvebyhod1="";
foreach($approvebyhod as $view)
{
$approvebyhod1.=$view.",";
}
}

$approvebymgmt=$_POST['approvebymgmt'];
if($approvebymgmt=="")
{
$approvebymgmt1="";
}
else
{
$approvebymgmt1="";
foreach($approvebymgmt as $view)
{
$approvebymgmt1.=$view.",";
}
}
$digsig_yesno=$_POST['digsig_yesno'];
$digsig_yesno=htmlspecialchars($digsig_yesno,ENT_QUOTES);

$poapprovalby=$_POST['poapprovalby'];
$poapprovalby=htmlspecialchars($poapprovalby,ENT_QUOTES);

$poapprovalby2=$_POST['poapprovalby2'];
$poapprovalby2=htmlspecialchars($poapprovalby2,ENT_QUOTES);

$poapprovalby3=$_POST['poapprovalby3'];
$poapprovalby3=htmlspecialchars($poapprovalby3,ENT_QUOTES);

//file setting
$filesize=$_POST['filesize'];
$filesize=htmlspecialchars($filesize,ENT_QUOTES);

$totalsize=$_POST['totalsize'];
$totalsize=htmlspecialchars($totalsize,ENT_QUOTES);

if($totalsize=="Bytes")
{
$totalsize=$filesize;
$ftype="Bytes";
}
else if($totalsize=="KBytes")
{
$totalsize=$filesize*1000;
$ftype="KBytes";
}
else if($totalsize=="MBytes")
{
$totalsize=$filesize*1000000;
$ftype="MBytes";
}
$filetype=$_POST['filetype'];
$filetype= htmlspecialchars($filetype, ENT_NOQUOTES);
$filetype2='"' . $filetype . '"';

$isoformatno=$_POST['isoformatno'];
$isoformatno=htmlspecialchars($isoformatno,ENT_QUOTES);
$newstr =str_replace('\\', '\\\\', $isoformatno);

$isoformatrevno=$_POST['isoformatrevno'];
$isoformatrevno=htmlspecialchars($isoformatrevno,ENT_QUOTES);
$newstr2 =str_replace('\\', '\\\\', $isoformatrevno);

$isonoreg=$_POST['isonoreg'];
$isonoreg=htmlspecialchars($isonoreg,ENT_QUOTES);
$newstreg =str_replace('\\', '\\\\', $isonoreg);

$isorevnoreg=$_POST['isorevnoreg'];
$isorevnoreg=htmlspecialchars($isorevnoreg,ENT_QUOTES);
$newstreg2 =str_replace('\\', '\\\\', $isorevnoreg);

$mandatorynote1=$_POST['mandatorynote1'];
$mandatorynote1=htmlspecialchars($mandatorynote1,ENT_QUOTES);

$mandatorynote2=$_POST['mandatorynote2'];
$mandatorynote2=htmlspecialchars($mandatorynote2,ENT_QUOTES);

$mandatorynote3=$_POST['mandatorynote3'];
$mandatorynote3=htmlspecialchars($mandatorynote3,ENT_QUOTES);

$mandatorynote4=$_POST['mandatorynote4'];
$mandatorynote4=htmlspecialchars($mandatorynote4,ENT_QUOTES);

$mandatorynote5=$_POST['mandatorynote5'];
$mandatorynote5=htmlspecialchars($mandatorynote5,ENT_QUOTES);

//digital signature 1 start
$pathd=$_FILES['dig_signature']['name'];
$extd = pathinfo($pathd, PATHINFO_EXTENSION);
$based = pathinfo($pathd, PATHINFO_FILENAME);
$sqlfile57=mysql_query("select * from purchaseorder_setting where id='$masterid'");
while($rowfile47=mysql_fetch_array($sqlfile57))
{
if($based=="")
{
$dig_signature=$rowfile47['dig_signature'];
}
else
{
$sqlfile=mysql_query("select id from purchaseorder_setting where id='$masterid'");
while($rowfile=mysql_fetch_array($sqlfile))
{
$cmpnfile=$rowfile['id'];
}
$complainnofile1=$cmpnfile;

$complainnofile2="Digital_Signature1".$complainnofile1;
$complainnofile3="_";
$complainnofileimg1=$complainnofile2.$complainnofile3;
$dig_signature= $complainnofileimg1.date("YmdHis.").$extd;

}
//digital signature 1 end


//digital signature 2 start
$pathd8=$_FILES['dig_signature2']['name'];
$extd8 = pathinfo($pathd8, PATHINFO_EXTENSION);
$based8 = pathinfo($pathd8, PATHINFO_FILENAME);
if($based8=="")
{
$dig_signature2=$rowfile47['dig_signature2'];
}
else
{
$sqlfile49=mysql_query("select id from purchaseorder_setting where id='$masterid'");
while($rowfile50=mysql_fetch_array($sqlfile49))
{
$cmpnfile4=$rowfile50['id'];
}
$complainnofile14=$cmpnfile4;

$complainnofile29="Digital_Signature2".$complainnofile14;
$complainnofile39="_";
$complainnofileimg19=$complainnofile29.$complainnofile39;
$dig_signature2= $complainnofileimg19.date("dmYHis.").$extd8;

}

//digital signature 2 end


//digital signature 3 start
$pathd10=$_FILES['dig_signature3']['name'];
$extd10 = pathinfo($pathd10, PATHINFO_EXTENSION);
$based10 = pathinfo($pathd10, PATHINFO_FILENAME);
if($based10=="")
{
 $dig_signature3=$rowfile47['dig_signature3'];
}
else
{
$sqlfile91=mysql_query("select id from purchaseorder_setting where id='$masterid'");
while($rowfile91=mysql_fetch_array($sqlfile91))
{
 $cmpnfile91=$rowfile91['id'];
}
$complainnofile91=$cmpnfile91;

$complainnofile921="Digital_Signature3".$complainnofile91;
$complainnofile93="_";
$complainnofileimg91=$complainnofile921.$complainnofile93;
$dig_signature3= $complainnofileimg91.date("YmdHis.").$extd10;

}
} //end of while loop rowfile47

move_uploaded_file($_FILES["dig_signature"]["tmp_name"],"purchaseorderfiles/".$dig_signature);
move_uploaded_file($_FILES["dig_signature2"]["tmp_name"],"purchaseorderfiles/".$dig_signature2); 
move_uploaded_file($_FILES["dig_signature3"]["tmp_name"],"purchaseorderfiles/".$dig_signature3);

//digital signature 3 end


date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt2=date("Y-m-d h:i:s");

$sql=mysql_query("update purchaseorder_setting set updatedid='$uid',updatedby='$name',updateddate='$dt2',filesize='$filesize',totalsize='$totalsize',filetype='$filetype2',filesize2='$ftype',poapprovalby='$poapprovalby',poapprovalby2='$poapprovalby2',poapprovalby3='$poapprovalby3',isoformatno='$newstr',isoformatrevno='$newstr2',isonoreg='$newstreg',isorevnoreg='$newstreg2',digsig_yesno='$digsig_yesno',purchase_cap='$purchase_cap',purchase_year='$purchase_year',hod_approve='$hod_approve',mgmt_approve='$mgmt_approve',po_regdept='$po_regdept1',costviewdept='$costviewdept1',approvebyhod='$approvebyhod1',approvebymgmt='$approvebymgmt1',mandatorynote1='$mandatorynote1',mandatorynote2='$mandatorynote2',mandatorynote3='$mandatorynote3',mandatorynote4='$mandatorynote4',mandatorynote5='$mandatorynote5',dig_signature='$dig_signature',dig_signature2='$dig_signature2',dig_signature3='$dig_signature3' where id='$masterid'");
if($sql=="")
{
echo '<script>				
setTimeout(function() {
swal({	
title: "Oops...!!!",
text: "Department Settings Updation Unsuccessful.",
type: "warning"		
}, 
function() 
{
window.location = "purchaseorder_setting.php";
});
}, 1000);
</script>'; 	
}
else
{
echo '<script>				
setTimeout(function() {
swal({	
title: "Success!",
text: "Department Settings Updated Successfully.",
type: "success"		
}, 
function() 
{
window.location = "purchaseorder_setting.php";
});
}, 1000);
</script>';    
}  
}
?>
<!-- dept updation end-->


<!-- Adding Transaction Type-->
<?php

if(isset($_POST['submit']))
{
$uid=$_SESSION['id'];
$name=$_SESSION['fullName'];

$transaction_type=$_POST['transaction_type'];
$transaction_type=htmlspecialchars($transaction_type,ENT_QUOTES);

date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt2=date("Y-m-d h:i:s");

$sql=mysql_query("insert into salesinvoice_transac_type (transaction_type,creationDate,createdby,createdid) values('$transaction_type','$dt2','$name','$uid')");
if($sql=="")
{
echo '<script>				
setTimeout(function() {
swal({	
title: "Oops...!!!",
text: "Something went wrong",
type: "warning"		
}, 
function() 
{
window.location = "purchaseorder_setting.php";
});
}, 1000);
</script>';  
}
else
{
echo '<script>				
setTimeout(function() {
swal({	
title: "Success!",
text: "Transaction Type Added successfully",
type: "success"		
}, 
function() 
{
window.location = "purchaseorder_setting.php";
});
}, 1000);
</script>';    
}  

}

?>

<!--updating status as active or deactive -->

<?php 
if(isset($_GET['status']))
{
$status1=$_GET['status'];
$select=mysql_query("select * from salesinvoice_transac_type where id='$status1'");
while($row=mysql_fetch_object($select))
{
$status_var=$row->status;
if($status_var=='0')
{
$status_state=1;
}
else
{
$status_state=0;
}
$update=mysql_query("update salesinvoice_transac_type set status='$status_state' where id='$status1'");
if($update)
{
header("Location:purchaseorder_setting.php");
}
else
{
echo mysql_error();
}
}

?>			
<?php }
?>

<!--editing transaction type -->
<?php  
if(isset($_POST['update1']))
{
$fullName=$_SESSION['fullName'];
$uid=$_SESSION['id'];

$id=$_POST['id'];

$transaction_type=$_POST['transaction_type'];
$transaction_type=htmlspecialchars($transaction_type,ENT_QUOTES);

date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt2=date("d-m-Y h:i:s");

$sql5=mysql_query("update salesinvoice_transac_type set transaction_type='$transaction_type',updationDate='$dt2',updatedby='$fullName',updatedid='$uid' where id='$id'");

if($sql5=="")
{
echo '<script>        
setTimeout(function() {
swal({  
title: "Oops...!!!",
text: "Something went wrong",
type: "warning"   
}, 
function() 
{
window.location = "purchaseorder_setting.php";
});
}, 1000);
</script>';       
}
else 
{
echo '<script>        
setTimeout(function() {
swal({  
title: "Success!",
text: "Transaction Type Updated Successfully",
type: "success"   
}, 
function() 
{
window.location = "purchaseorder_setting.php";
});
}, 1000);
</script>';     
}
}
else
{

} ?>



<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" type="image/png" sizes="16x16" href="OTlogo.png">
<title>ESM | Purchase Order</title>
<link rel="stylesheet" href="main/js/jquery-ui.css">
<script src="main/js/jquery-1.12.4.js"></script>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/plugins/html5-editor/bootstrap-wysihtml5.css" >
<!-- This page css -->
<link href="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="assets/plugins/switchery/dist/switchery.min.css"rel="stylesheet" />
<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" />
<link href="assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" />
<link href="assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css" />
<!-- <link href="assets/datatables/jquery.dataTables.yadcf.css" rel="stylesheet" type="text/css" />
<script src="assets/datatables/jquery.dataTables.yadcf.js"></script> -->
<link href="main/css/style.css" rel="stylesheet">
<link href="main/css/colors/blue.css" id="theme" rel="stylesheet">
<link href="assets/plugins/sweetalert/sweetalert.css">
<link href="assets/plugins/wizard/steps.css">
<!--[if lt IE 9]>
<script src="html5shiv.js"></script>
<script src="respond.min.js"></script>
<![endif]-->
<script src="main/js/jquery-ui.js"></script>
<script src="jquery.min.js"></script>
<link href="sweetalert.css" rel="stylesheet"/>
<script src="sweetalert.min.js"></script>

<script src="main/js/jquery-inputmask.js"></script>

<!-- datatable css-->
<link href="assets/datatables/css/dataTables.bootstrap4.min.css" rel="stylesheet">
<link href="assets/datatables/css/buttons.bootstrap4.min.css" rel="stylesheet">
<link href="assets/datatables/css/jquery.dataTables.css" rel="stylesheet" type="text/css" />
<link href="assets/datatables/css/fixedHeader.dataTables.min.css" rel="stylesheet" />
<link href="assets/datatables/css/select.dataTables.min.css" rel="stylesheet">


<style>
div.scrollmenu 
{
overflow: auto;
}
.form-control 
{
font-size:small;
}
@import url('font-awesome.min.css');
.panel-title > a:before {
float: right !important;
font-family: FontAwesome;
content:"\f068";
padding-right: 5%;
}
.panel-title > a.collapsed:before {
float: right !important;
content:"\f067";
}
.panel-title > a:hover, 
.panel-title > a:active, 
.panel-title > a:focus  {
text-decoration:none;
}td{

color:#2C3E50;
}
</style>
<style>
.act { color:#007F00; }
.deact { color:#F00;}

/* Custom Swal buttons for operator data entry deletion: Are You Sure, You want to delete entry */
.sweet-alert[data-custom-class="mycustomclass"] button.confirm {
color: white;
background-color: green;
}
.sweet-alert.mycustomclass button.cancel {
color: white;
background-color: red;
}
</style>

<!--datatable style -->
<style type="text/css">

/*printing text wordwrap*/
table {
table-layout:fixed;
}
table td {
word-wrap: break-word;
max-width: 400px;
}


/* word wrapping content of td*/
#example td {
white-space:inherit;
}

/*locating tools button*/
#tools {
margin-left: 80%;
margin-top: 10px;
}

/*table resizing according to page view and tableheader background color*/
table {border-collapse:collapse; table-layout:fixed; width:100%;}
table td {border:solid 1px #fab; width:100px; word-wrap:none;}
table.dataTable thead .sorting, table.dataTable thead .sorting_asc, table.dataTable thead .sorting_desc, table.dataTable thead .sorting_asc_disabled, table.dataTable thead .sorting_desc_disabled {
background: #1976d2;
color: white;
margin-top: 20px;
vertical-align: inherit;

}
table.dataTable thead th, table.dataTable tfoot th {
font-weight: 500;
}

/*To maintain space between its content and border*/
table.dataTable thead>tr>th.sorting_asc, table.dataTable thead>tr>th.sorting_desc, table.dataTable thead>tr>th.sorting, table.dataTable thead>tr>td.sorting_asc, table.dataTable thead>tr>td.sorting_desc, table.dataTable thead>tr>td.sorting {
padding-right: inherit;
} 

/* background and textcolor for datable tools button*/
a.dt-button.dropdown-item{
background-color: #1976d2;
color:white;
}
a.dt-button.buttons-columnVisibility.active{
background-color: #1976d2;
color:white;
}
a.dt-button.buttons-columnVisibility{
background-color: white ;
color: #333;
}
/* coloumn visibility title background : 'Select Columns to Display'*/
div.dt-button-collection div.dt-button-collection-title {
background-color: orangered;
border: 1px solid rgba(0,0,0,0.15);
border-radius: 0.25rem;
color: white;
width: 560px;
font-size: small;
font-family:Poppins, sans-serif;
font-size:16px;
font-weight:400;
height:auto;
}

/* Table Header break line(<br>) in print */
table.dataTable thead th, table.dataTable tfoot th {
font-weight: 500;
white-space: inherit;
}
/* Table Header margin-left 3px in print */
table.dataTable thead th, table.dataTable thead th {
padding: 10px 3px;
border-bottom: 1px solid #111111; 
}

table.dataTable tbody td {
word-break: break-word;
vertical-align: top;
}

</style>

<style type="text/css">
footer div.spanclass{
font-size: small;
}
</style>

<!--counter for textarea -->
<style type="text/css">
.wrap {
    position: relative;
    display: inline-block;
   
}
.wrap span {
    position: absolute;
  
    right: 0px;
    } 
.counter{
    background-color: #5dc991;
    color: #fff;
    font-size: 10px;
    padding: 2px 5px;
    line-height: 12px;
    height: 14px;
    text-align: center;
    border-top-right-radius: 4px;
    border-bottom-left-radius: 4px;
    font-weight: 400;
}
</style>

</head>
<body class="fix-header fix-sidebar card-no-border">
<div id="main-wrapper" class="scrollmenu" style="font-size:small">
<?php include("includes/config.php");?>
<?php include("includes/header.php");?> 
<?php include("includes/sidebar.php");?>
<div class="page-wrapper" >
<div class="row page-titles m-b-0 " style="height:45px">
<div class="col-md-5 align-self-center">
<h4 class="text-themecolor">Purchase Order</h4>
</div>
<div class="col-md-7 align-self-center">
<ol class="breadcrumb">
<li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
<li class="breadcrumb-item"><a href="purchaseorder_viewup.php">Purchase Order</a></li>
<li class="breadcrumb-item"><a href="purchaseorder_setting.php">Settings</a></li>
</ol>
</div> 
</div> 

<br>
<div class="container-fluid">   	
<div class="row">
<div class="col-12">
<div class="card">
<div class="card-body">


<!-- settings start-->
<?php 
$queryacc=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($rowacc=mysql_fetch_array($queryacc)) 
{
?> 
<ul class="nav nav-tabs" role="tablist">
<?php
$query21=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($row21=mysql_fetch_array($query21)) 
{  
$complaintarr1=$row21['purchaseorderaccess'];
$comarr1=explode(',',trim( $complaintarr1));
$secondaryarr1=$row21['multidept'];
$secarr2=explode(',',trim($secondaryarr1));
//to remove last comma from multidept array
$lastcomma = '';
foreach($secarr2 as $i=>$k) 
{
$lastcomma .= $k.',';
}
$lastcomma = rtrim($lastcomma,',');
$secarr1=explode(',',trim($lastcomma));
$querydays1=mysql_query("select * from purchaseorder_setting order by id desc limit 1");
while($rowdays1=mysql_fetch_array($querydays1)) 
{ 
$quadept1=$rowdays1['po_regdept'];
$qua1=explode(',',trim($quadept1));
$result1 = array_intersect($secarr1,$qua1);
if((($result1!=array())||(in_array($row21['department'],$qua1))) && (in_array('regpurchaseorder',$comarr1)))
{  ?>

<?php $query1=mysql_query("select * from master order by id desc limit 1");
while($row1=mysql_fetch_array($query1))
{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt3=date("Y-m-d h:i");
if($row1['licend']<= $dt3) 
{ ?>
<li class="nav-item"><a class="nav-link"  onclick="myFunctionstatus()" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span><span class="hidden-xs-down">Register</span></a></li> 
<?php } 
else
{ ?>
<li class="nav-item"><a class="nav-link" href="purchaseorder_register.php" role="tab"><span class="hidden-sm-up"><i class="ti-email"></i></span> <span class="hidden-xs-down"> Register &nbsp;<b>
</b></span></a> 
</li>
<?php } 
} 

}else{

} } } ?>

<?php   
$inhousecomarr=$rowacc['purchaseorderaccess'];
$inhousearr=explode(',',trim( $inhousecomarr));
if(in_array('viewpurchaseorder',$inhousearr))
{ ?>
<?php $query1=mysql_query("select * from master order by id desc limit 1");
while($row1=mysql_fetch_array($query1))
{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt3=date("Y-m-d h:i:s");
if($row1['licend']<= $dt3) 
{
?>
<li class="nav-item"><a class="nav-link" onclick="myFunctionstatus()" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span><span class="hidden-xs-down">View/Update</span></a></li> 
<?php } 
else
{ ?>
<li class="nav-item"><a class="nav-link" href="purchaseorder_viewup.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">View/Update</span></a> </li>
<?php } 
} ?>

<?php
} else{

} 
?>

<?php $companymaster=$rowacc['addmanageaccess'];
$compaarr=explode(',',trim($companymaster));
if(in_array('generalmanage',$compaarr))
{?>
<li class="nav-item"> <a class="nav-link active"  href="purchaseorder_setting.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Settings</span></a> </li>
<?php } } ?>  
</ul>
<!--settings end --> 



<!-- Tab panes -->
<div class="tab-content tabcontent-border">
<div class="tab-pane active" id="home" role="tabpanel">
<br>



<?php   
$queryde = mysql_query("SELECT * FROM purchaseorder_setting");
$numberde=mysql_num_rows($queryde);
if ( $numberde== '0' ) 
{ ?>                                        
<div class="p-20">
<form class="form-horizontal"  method="post"  enctype="multipart/form-data">

<div class="row">
<ul class="nav nav-tabs" role="tablist">
<li class="nav-item"> <a class="nav-link active"  href="purchaseorder_setting.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Approving Departments</span></a> </li>
<li class="nav-item"> <a class="nav-link"  href="purchaseorder_statusreason.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Add Status Reason</span></a> </li>
</ul>
</div>
<br><br>


<?php $qadmin1=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($radmin1=mysql_fetch_array($qadmin1)) 
{
if($radmin1['admin_role']=='Superadmin')
{  
?> 
<!-- Target Department -->

<!--for sales target start -->
<div class="row">
<div class="col-md-3" >
<div class="form-group">
<label >Purchase Cap&nbsp;<span style="color:red" ></span> </label>
<div class="input-group">
<div class="input-group-prepend">
<span class="input-group-text"><i class="fa fa-rupee" ></i></span>
<input type="text"  class="form-control" id="inputmasking3" name="purchase_cap" autocomplete=off>
</div>
</div>
</div>
</div> 

<div class="col-md-3">
<div class="form-group">
<span><label>For Year</label><br>
<select class="form-control" id="select_year" name="purchase_year">
<option></option>
<?php
date_default_timezone_set($timezone);
$today1= date('Y-m-d');
// $year1 = date('Y');
$iyear=date('Y');
$iyear1=date('Y');

for($i=2018; $i<=$iyear1; $i++){
$selected = ($i==$year1)?'selected':'';
echo "

<option value='".$i."' ".$selected.">".$i."</option>
";
}
?>
</select></span> 
</div>
</div>
</div>
<!--for sales target end -->


<div class="row">	
<div class="col-md-2">
<div class="form-group">
<h5 style="margin-top:18px"><b>Department:</b> </h5>
</div>
</div>
</div>

<div class="row">
<label style="margin-left:15px">Is Purchase HOD Approval Required ?&nbsp;&nbsp; </label>
<label class="custom-control custom-radio">
<input name="hod_approve" value="Yes" type="radio" onclick="javascript:yesnoCheck1();" id="yesid1" class="custom-control-input">
<span class="custom-control-label">Yes</span>
</label>&nbsp;&nbsp;
<label class="custom-control custom-radio">
<input name="hod_approve" value="No" type="radio" onclick="javascript:yesnoCheck1();" id="noid1" class="custom-control-input">
<span class="custom-control-label">No</span>
</label>
</div>
<div class="row">
<label style="margin-left:15px">Is Management Approval Required ?&nbsp;&nbsp;&nbsp;</label>
<label class="custom-control custom-radio">
<input name="mgmt_approve" value="Yes" type="radio" onclick="javascript:yesnoCheck1();" id="yesid2" class="custom-control-input">
<span class="custom-control-label">Yes </span>
</label>&nbsp;&nbsp;
<label class="custom-control custom-radio">
<input name="mgmt_approve" value="No" type="radio" onclick="javascript:yesnoCheck1();" id="noid2" class="custom-control-input">
<span class="custom-control-label">No</span>
</label>
</div><br>


<div class="row">
<div class="col-md-2">
<div class="form-group">
<label>PO prepared by&nbsp;<span style="font-size:small;color:red">*</span></label>
<select class="selectpicker" name="po_regdept[]" multiple data-style="form-control btn-secondary">
<?php
$multi_dept = explode(",",$rowdays["po_regdept"]);
$multidept_result = mysql_query("SELECT * FROM department  where status='1' ");
$i=0;
while($multidept_stack = mysql_fetch_array($multidept_result)) {
if(in_array($multidept_stack["department"],$multi_dept)) $str_flag = "selected";
else $str_flag="";
?>
<option value="<?=$multidept_stack["department"];?>"<?php echo $str_flag; ?>><?=$multidept_stack["authority"];?></option>
<?php
$i++;
}
?> 
</select>	
</div>
</div>

<div class="col-md-5">
<div class="form-group">
<label>Choose Which Department can View PO with Cost/Price&nbsp;<span style="font-size:small;color:red">*</span></label><br>
<select class="selectpicker" name="costviewdept[]" multiple data-style="form-control btn-secondary">
<?php
$multi_dept = explode(",",$rowdays["costviewdept"]);
$multidept_result = mysql_query("SELECT * FROM department  where status='1' ");
$i=0;
while($multidept_stack = mysql_fetch_array($multidept_result)) {
if(in_array($multidept_stack["authority"],$multi_dept)) $str_flag = "selected";
else $str_flag="";
?>
<option value="<?=$multidept_stack["department"];?>" <?php echo $str_flag; ?>><?=$multidept_stack["authority"];?></option>
<?php
$i++;
}
?> 
</select>										
</div>
</div>

<div class="col-md-2">
<div class="form-group">
<div id="appid" style="display:none;">
	<label>HOD approval&nbsp;<span style="font-size:small;color:red">*</span></label><br>
	  <select class="selectpicker" name="approvebyhod[]" multiple data-style="form-control btn-secondary">
	    <?php
	    $multi_dept = explode(",",$rowdays["approvebyhod"]);
	    $multidept_result = mysql_query("SELECT * FROM department  where status='1' ");
	    $i=0;
	    while($multidept_stack = mysql_fetch_array($multidept_result)) {
	     if(in_array($multidept_stack["authority"],$multi_dept)) $str_flag = "selected";
	     else $str_flag="";
	     ?>
	     <option value="<?=$multidept_stack["department"];?>" <?php echo $str_flag; ?>><?=$multidept_stack["authority"];?></option>
	     <?php
	     $i++;
	   }
	   ?> 
    </select>										
</div>
</div>
</div> 

<div class="col-md-3">
<div class="form-group">
<div id="appid2" style="display:none;">
	<label>Management Approval&nbsp;<span style="font-size:small;color:red">*</span></label><br>
	  <select class="selectpicker" name="approvebymgmt[]" multiple data-style="form-control btn-secondary">
	    <?php
	    $multi_dept = explode(",",$rowdays["approvebymgmt"]);
	    $multidept_result = mysql_query("SELECT * FROM department  where status='1' ");
	    $i=0;
	    while($multidept_stack = mysql_fetch_array($multidept_result)) {
	     if(in_array($multidept_stack["authority"],$multi_dept)) $str_flag = "selected";
	     else $str_flag="";
	     ?>
	     <option value="<?=$multidept_stack["department"];?>" <?php echo $str_flag; ?>><?=$multidept_stack["authority"];?></option>
	     <?php
	     $i++;
	   }
	   ?> 
    </select>										
</div>
</div>
</div>

</div><!-- row end -->

<div class="row">
<label style="margin-left:15px">Do you want Digital Signature on Purchase Order ?</label>&nbsp;&nbsp;
<label class="custom-control custom-radio">
<input name="digsig_yesno" value="Yes" type="radio" onclick="javascript:digsigyesno();" id="check1" class="custom-control-input">
<span class="custom-control-label">Yes</span>
</label>&nbsp;&nbsp;
<label class="custom-control custom-radio">
<input name="digsig_yesno" value="No" type="radio" onclick="javascript:digsigyesno();" id="check2" class="custom-control-input">
<span class="custom-control-label">No</span>
</label>
</div>
<br>

<div id="yesno" style="display:none;">
<div class="row">
<div class="col-md-3">
<div class="form-group">
<label>PO Approval By</label>
<select name="poapprovalby" id="siapprovalby" class="form-control">
<option value="">Please Select</option>
<?php
require_once("dbcontrollernew.php");
$db_handledept = new DBController();
$querydept ="SELECT * FROM users";
$depts = $db_handledept->runQuery($querydept);
foreach($depts as $dept)
{
?>

<option value="<?php echo htmlentities($dept['fullName']);?>"><?php echo htmlentities($dept['fullName']);?></option>
<?php
}
?>
</select>	
</div>
</div> 

<div class="col-md-3" style="">
<div class="form-group">
<label>Upload Digital Signature<span style="color:red"></span> </label>
<input type="file" name="dig_signature" class="form-control" id="dig_signature">
<label><i style="font-size: smaller;">use only .jpg,.jpeg,.png,.bmp</i></label>
</div>
</div>
</div>

<div class="row">
<div class="col-md-3">
<div class="form-group">
<label>PO Approval By 2</label>
<select name="poapprovalby2" id="siapprovalby2" class="form-control">
<option value="">Please Select</option>
<?php
require_once("dbcontrollernew.php");
$db_handledept = new DBController();
$querydept ="SELECT * FROM users";
$depts = $db_handledept->runQuery($querydept);
foreach($depts as $dept)
{
?>

<option value="<?php echo htmlentities($dept['fullName']);?>"><?php echo htmlentities($dept['fullName']);?></option>
<?php
}
?>
</select>	
</div>
</div> 

<div class="col-md-3">
<div class="form-group">
<label>Upload Digital Signature2<span style="color:red"></span> </label>
<input type="file" name="dig_signature2" class="form-control" id="dig_signature2">
<label><i style="font-size: smaller;">use only .jpg,.jpeg,.png,.bmp</i></label>
</div>
</div>
</div>

<div class="row">
<div class="col-md-3">
<div class="form-group">
<label>PO Approval By3</label>
<select name="poapprovalby3" id="siapprovalby3" class="form-control">
<option value="">Please Select</option>
<?php
require_once("dbcontrollernew.php");
$db_handledept = new DBController();
$querydept ="SELECT * FROM users";
$depts = $db_handledept->runQuery($querydept);
foreach($depts as $dept)
{
?>

<option value="<?php echo htmlentities($dept['fullName']);?>"><?php echo htmlentities($dept['fullName']);?></option>
<?php
}
?>
</select>	
</div>
</div> 

<div class="col-md-3">
<div class="form-group">
<label>Upload Digital Signature3<span style="color:red"></span> </label>
<input type="file" name="dig_signature3" class="form-control" id="dig_signature3">
<label><i style="font-size: smaller;">use only .jpg,.jpeg,.png,.bmp</i></label>
</div>
</div>
</div>
</div>
<br>

<!--File settings start -->
<div class="row"> 
<div class="col-md-2">
<div class="form-group">
<h5><b>File Settings : </b></h5>
</div>
</div>
<div class="col-md-3">
<div class="form-group">
<label>File Size&nbsp;<span style="color:red" >*</span></label>
<input type="text" class="form-control" style="color:black" required="" name="filesize" >
</div>
</div>

<div class="col-md-3">
<div class="form-group">
<label>Size&nbsp;<span style="color:red">*</span></label>
<select class="form-control" name="totalsize" required="" >
<option>Please Select</option>
<option value="Bytes">Bytes</option>
<option value="KBytes">KBytes</option>
<option value="MBytes">MBytes</option>
</select>
</div>
</div>

<div class="col-md-3">
<div class="form-group">
<label>File Type&nbsp;<span style="color:red" >*</span></label>
<input type="text" class="form-control" style="color:black" required="" name="filetype">
<label><i style="font-size: smaller;">Ex: .pdf,.jpg,.png</i></label>
</div>
</div>
</div> 



<div class="row">
<div class="col-md-2">
<div class="form-group">
<h5><b>ISO Settings :</b></h5>
</div>
</div>
</div>

<div class="row">
<div class="col-md-2">
<div class="form-group">
<span style="font-size: 11px;font-weight: 600;"><i>For Registration<br></i>
<span style="font-size: 11px;font-weight: 600;"><i>( Form Filling / Format )</span></i></span>
</div>
</div>
<div class="col-md-3">
<div class="form-group">
<label>ISO Format No.</label>
<input type="text" class="form-control" style="color:black" name="isonoreg" >
</div>
</div>

<div class="col-md-3">
<div class="form-group">
<label>ISO Format Revision No.</label>
<input type="text" class="form-control" style="color:black" name="isorevnoreg" >
</div>
</div>
</div>

<div class="row">
<div class="col-md-2">
<div class="form-group">
<span style="font-size: 11px;font-weight: 600;"><i>For View / Update<br></i>
<span style="font-size: 11px;font-weight: 600;"><i>( Records Register )</span></i></span>
</div>
</div>
<div class="col-md-3">
<div class="form-group">
<label>ISO Register No.</label>
<input type="text" class="form-control" style="color:black" name="isoformatno" >
</div>
</div>

<div class="col-md-3">
<div class="form-group">
<label>ISO Register Revision No.</label>
<input type="text" class="form-control" style="color:black" name="isoformatrevno">
</div>
</div>
</div>

<div class="row">
<div class="col-md-5">
<div class="form-group">
<h5><b>Mandatory Notes to Print in PO:</b></h5>
</div>
</div>
</div>

<div class="row">
<div class="col-md-3">
<div class="form-group">
<div class="wrap">
<textarea class=" form-control" style="background-color:white;line-height:1.6;text-align: justify;resize:vertical;width:300px;max-height:150px;" name="mandatorynote1" id="notes1" maxlength="200"></textarea>
 <span id="notescnt1" class="counter"></span></div>
</div>
</div>
<div class="col-md-3" style="margin-left:60px;">
<div class="form-group">
<div class="wrap">
<textarea class=" form-control" style="background-color:white;line-height:1.6;text-align: justify;resize:vertical;width:300px;max-height:150px;" name="mandatorynote2" id="notes2" maxlength="200"></textarea>
 <span id="notescnt2" class="counter"></span></div>
</div>
</div>
<div class="col-md-3" style="margin-left:60px;">
<div class="form-group">
<div class="wrap">
<textarea class=" form-control" style="background-color:white;line-height:1.6;text-align: justify;resize:vertical;width:300px;max-height:150px;" name="mandatorynote3" id="notes3" maxlength="200"></textarea>
 <span id="notescnt3" class="counter"></span></div>
</div>
</div>
</div>

<div class="row">
<div class="col-md-3">
<div class="form-group">
<div class="wrap">
<textarea class=" form-control" style="background-color:white;line-height:1.6;text-align: justify;resize:vertical;width:300px;max-height:150px;" name="mandatorynote4" id="notes4" maxlength="200"></textarea>
 <span id="notescnt4" class="counter"></span></div>
</div>
</div>
<div class="col-md-3" style="margin-left:60px;">
<div class="form-group">
<div class="wrap">
<textarea class=" form-control" style="background-color:white;line-height:1.6;text-align: justify;resize:vertical;width:300px;max-height:150px;" name="mandatorynote5" id="notes5" maxlength="200"></textarea>
 <span id="notescnt5" class="counter"></span></div>
</div>
</div>
</div>


<!-- Target Department end -->
<div class="row">
<div class="col-md-2">
<div class="form-group">
<button type="submit" name="newdept" class="btn waves-effect waves-light btn-info" id='subm1' style="margin-top:18px">Submit</button>
</div>
</div>
</div>	
<?php } 
else
{ ?>
<br><br>
<h6 style="color:red;text-align:left;">Note  :  This Settings can be changed only by admin</h6>

<?php } } ?>

</form>
<?php  
}
else
{
$querydays=mysql_query("select * from purchaseorder_setting order by id desc limit 1");
while($rowdays=mysql_fetch_array($querydays)) 
{ ?>
<div class="p-20">
<form class="form-horizontal" method="post" enctype="multipart/form-data">
<input style="display:none" name="masterid" value="<?php echo htmlentities($rowdays['id']);?>">

<div class="row">
<ul class="nav nav-tabs" role="tablist">
<li class="nav-item"> <a class="nav-link active"  href="purchaseorder_setting.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Approving Departments</span></a> </li>
<li class="nav-item"> <a class="nav-link"  href="purchaseorder_statusreason.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Add Status Reason</span></a> </li>
</ul>
</div>
<br><br>


<!-- Target Department -->

<?php 
$qadmin=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($rowad=mysql_fetch_array($qadmin)) 
{
if($rowad['admin_role']=='Superadmin')
{
?> 

<!--for sales target start -->
<div class="row">
<div class="col-md-3" >
<div class="form-group">
<label >Purchase Cap&nbsp;<span style="color:red" ></span> </label>
<div class="input-group">
<div class="input-group-prepend">
<span class="input-group-text"><i class="fa fa-rupee" ></i></span>
<input type="text" class="form-control" id="inputmasking3" value="<?php echo htmlspecialchars_decode($rowdays['purchase_cap']);?>" name="purchase_cap" autocomplete=off>
</div>
</div>
</div>
</div> 

<div class="col-md-3">
<div class="form-group">
<span><label>For Year</label><br>
<select class="form-control" id="select_year" name="purchase_year">
<option value="<?php echo htmlspecialchars_decode($rowdays['purchase_year']);?>"><?php echo htmlspecialchars_decode($rowdays['purchase_year']);?></option>
<?php
date_default_timezone_set($timezone);
$today1= date('Y-m-d');
// $year1 = date('Y');
$iyear=date('Y');
$iyear1=date('Y');

for($i=2018; $i<=$iyear1; $i++){
$selected = ($i==$year1)?'selected':'';
echo "

<option value='".$i."' ".$selected.">".$i."</option>
";
}
?>
</select></span> 
</div>
</div>
</div>
<!--for sales target end -->



<div class="row">
<div class="col-md-2" style="margin-top:18px">
<div class="form-group">
<h5><b>Department : </b></h5>
</div>
</div>
</div>	


<div class="row">
<label style="margin-left:15px">Is Purchase HOD Approval Required ?&nbsp;&nbsp; </label>
<label class="custom-control custom-radio">
<input name="hod_approve" value="Yes" <?php if($rowdays['hod_approve']=="Yes"){echo "checked";} ?> type="radio" onclick="javascript:yesnoCheck1();" id="yesid1" class="custom-control-input">
<span class="custom-control-label">Yes</span>
</label>&nbsp;&nbsp;
<label class="custom-control custom-radio">
<input name="hod_approve" value="No" <?php if($rowdays['hod_approve']=="No"){echo "checked";} ?> type="radio" onclick="javascript:yesnoCheck1();" id="noid1" class="custom-control-input">
<span class="custom-control-label">No</span>
</label>
</div>
<div class="row">
<label style="margin-left:15px">Is Management Approval Required ?&nbsp;&nbsp;&nbsp;</label>
<label class="custom-control custom-radio">
<input name="mgmt_approve" value="Yes" <?php if($rowdays['mgmt_approve']=="Yes"){echo "checked";} ?> type="radio" onclick="javascript:yesnoCheck1();" id="yesid2" class="custom-control-input">
<span class="custom-control-label">Yes </span>
</label>&nbsp;&nbsp;
<label class="custom-control custom-radio">
<input name="mgmt_approve" value="No" <?php if($rowdays['mgmt_approve']=="No"){echo "checked";} ?> type="radio" onclick="javascript:yesnoCheck1();" id="noid2" class="custom-control-input">
<span class="custom-control-label">No</span>
</label>
</div><br>



<div class="row">
<div class="col-md-2">
<div class="form-group">
<label>PO prepared by&nbsp;<span style="font-size:small;color:red">*</span></label>
<select class="selectpicker" name="po_regdept[]" multiple data-style="form-control btn-secondary">
<?php
$multi_dept = explode(",",$rowdays["po_regdept"]);
$multidept_result = mysql_query("SELECT * FROM department  where status='1' ");
$i=0;
while($multidept_stack = mysql_fetch_array($multidept_result)) {
if(in_array($multidept_stack["department"],$multi_dept)) $str_flag = "selected";
else $str_flag="";
?>
<option value="<?=$multidept_stack["department"];?>"<?php echo $str_flag; ?>><?=$multidept_stack["authority"];?></option>
<?php
$i++;
}
?> 
</select>	
</div>
</div>

<div class="col-md-5">
<div class="form-group">
<label>Choose Which Department can View PO with Cost/Price&nbsp;<span style="font-size:small;color:red">*</span></label><br>
<select class="selectpicker" name="costviewdept[]" multiple data-style="form-control btn-secondary">
<?php
$multi_dept = explode(",",$rowdays["costviewdept"]);
$multidept_result = mysql_query("SELECT * FROM department  where status='1' ");
$i=0;
while($multidept_stack = mysql_fetch_array($multidept_result)) {
if(in_array($multidept_stack["department"],$multi_dept)) $str_flag = "selected";
else $str_flag="";
?>
<option value="<?=$multidept_stack["department"];?>"<?php echo $str_flag; ?>><?=$multidept_stack["authority"];?></option>
<?php
$i++;
}
?> 
</select>										
</div>
</div>

<div class="col-md-2">
<div class="form-group">
<div id="appid" style="display:none;">
	<label>HOD approval&nbsp;<span style="font-size:small;color:red">*</span></label><br>
<select class="selectpicker" name="approvebyhod[]" id="hodapprove" multiple data-style="form-control btn-secondary">
<?php
$multi_dept = explode(",",$rowdays["approvebyhod"]);
$multidept_result = mysql_query("SELECT * FROM department  where status='1' ");
$i=0;
while($multidept_stack = mysql_fetch_array($multidept_result)) {
if(in_array($multidept_stack["department"],$multi_dept)) $str_flag = "selected";
else $str_flag="";
?>
<option value="<?=$multidept_stack["department"];?>"<?php echo $str_flag; ?>><?=$multidept_stack["authority"];?></option>
<?php
$i++;
}
?> 
</select>										
</div>
</div>
</div> 

<div class="col-md-3">
<div class="form-group">
<div id="appid2" style="display:none;">
	<label>Management Approval&nbsp;<span style="font-size:small;color:red">*</span></label><br>
<select class="selectpicker" name="approvebymgmt[]" id="mgmtapprove" multiple data-style="form-control btn-secondary">
<?php
$multi_dept = explode(",",$rowdays["approvebymgmt"]);
$multidept_result = mysql_query("SELECT * FROM department  where status='1' ");
$i=0;
while($multidept_stack = mysql_fetch_array($multidept_result)) {
if(in_array($multidept_stack["department"],$multi_dept)) $str_flag = "selected";
else $str_flag="";
?>
<option value="<?=$multidept_stack["department"];?>"<?php echo $str_flag; ?>><?=$multidept_stack["authority"];?></option>
<?php
$i++;
}
?> 
</select>										
</div>
</div>
</div>

</div><!-- row end -->



<div class="row">
<label style="margin-left:15px">Do you want Digital Signature on Purchase Order ?</label>&nbsp;&nbsp;
<label class="custom-control custom-radio">
<input name="digsig_yesno" value="Yes" <?php if($rowdays['digsig_yesno']=="Yes"){echo "checked";} ?> type="radio" onclick="javascript:digsigyesno();" id="check1" class="custom-control-input">
<span class="custom-control-label">Yes</span>
</label>&nbsp;&nbsp;
<label class="custom-control custom-radio">
<input name="digsig_yesno" value="No" <?php if($rowdays['digsig_yesno']=="No"){echo "checked";} ?> type="radio" onclick="javascript:digsigyesno();" id="check2" class="custom-control-input">
<span class="custom-control-label">No</span>
</label>
</div>
<br>

<div id="yesno">
<div class="row">
<div class="col-md-3">
<div class="form-group">
<label>PO Approval By</label>
<select name="poapprovalby" id="poapprovalby" class="form-control">
<option value="<?php echo htmlentities($rowdays['poapprovalby']);?>"><?php echo htmlentities($rowdays['poapprovalby']);?></option>
<?php
require_once("dbcontrollernew.php");
$db_handledept = new DBController();
$querydept ="SELECT * FROM users";
$depts = $db_handledept->runQuery($querydept);
foreach($depts as $dept)
{
?>

<option value="<?php echo htmlentities($dept['fullName']);?>"><?php echo htmlentities($dept['fullName']);?></option>
<?php
}
?>
</select>	
</div>
</div> 

<div class="col-md-3" style="">
<div class="form-group">
<label>Upload Digital Signature<span style="color:red"></span> </label>
<input type="file" name="dig_signature" class="form-control" id="dig_signature">
<label><i style="font-size: smaller;">use only .jpg,.jpeg,.png,.bmp</i></label>
</div>
</div>

<div class="col-md-2">
<label></label><br>
<?php $cfile1=$rowdays['dig_signature'];
if($cfile1==""  )
{

}
else if($cfile1=="NULL"||$cfile1=="default.png")
{
echo "File Not Attached";
}
else
{
$cfile2=pathinfo($rowdays['dig_signature']);
$cfile2['extension'];
$cool_extensions = Array('doc','docx','DOCX','DOC');
$cool_extensions1 = Array('pdf','PDF');
$cool_extensions2=Array('xls','xlsx','XLS','XLSX');
$cool_extensions3=Array('jpg','png','jpeg','JPG','JPEG','PNG');
if (in_array($cfile2['extension'], $cool_extensions))
{ ?>
<img src="complaintdocs/doc.png" style="height:40px;width:45px">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature']);?>" target="_blank">View File</a>
<?php
}
else if(in_array($cfile2['extension'], $cool_extensions1))
{ ?>
<img src="complaintdocs/pdf.png" style="height:40px;width:40px">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature']);?>" target="_blank">View File</a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions2))
{ ?>
<img src="complaintdocs/xls.png" style="height:40px;width:40px">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature']);?>" target="_blank">View File</a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions3))
{
?>  
<img style="width:50px;height:30px"src="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature']);?>" ?>&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature']);?>" target="_blank">View File</a>
<?php 
}else{ ?>
<img src="complaintdocs/unknown.png" style="height:40px;width:40px">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature']);?>" target="_blank">View File</a>
<?php }
} ?>
</div>

</div>

<div class="row">
<div class="col-md-3">
<div class="form-group">
<label>PO Approval By 2</label>
<select name="poapprovalby2" id="poapprovalby2" class="form-control">
<option value="<?php echo htmlentities($rowdays['poapprovalby2']);?>"><?php echo htmlentities($rowdays['poapprovalby2']);?></option>
<?php
require_once("dbcontrollernew.php");
$db_handledept = new DBController();
$querydept ="SELECT * FROM users";
$depts = $db_handledept->runQuery($querydept);
foreach($depts as $dept)
{
?>

<option value="<?php echo htmlentities($dept['fullName']);?>"><?php echo htmlentities($dept['fullName']);?></option>
<?php
}
?>
</select>	
</div>
</div> 

<div class="col-md-3">
<div class="form-group">
<label>Upload Digital Signature2<span style="color:red"></span> </label>
<input type="file" name="dig_signature2" class="form-control" id="dig_signature2">
<label><i style="font-size: smaller;">use only .jpg,.jpeg,.png,.bmp</i></label>
</div>
</div>

<div class="col-md-2">
<label></label><br>
<?php $cfile1=$rowdays['dig_signature2'];
if($cfile1==""  )
{

}
else if($cfile1=="NULL"||$cfile1=="default.png")
{
echo "File Not Attached";
}
else
{
$cfile2=pathinfo($rowdays['dig_signature2']);
$cfile2['extension'];
$cool_extensions = Array('doc','docx','DOCX','DOC');
$cool_extensions1 = Array('pdf','PDF');
$cool_extensions2=Array('xls','xlsx','XLS','XLSX');
$cool_extensions3=Array('jpg','png','jpeg','JPG','JPEG','PNG');
if (in_array($cfile2['extension'], $cool_extensions))
{ ?>
<img src="complaintdocs/doc.png" style="height:40px;width:45px">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature2']);?>" target="_blank">View File</a>
<?php
}
else if(in_array($cfile2['extension'], $cool_extensions1))
{ ?>
<img src="complaintdocs/pdf.png" style="height:40px;width:40px">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature2']);?>" target="_blank">View File</a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions2))
{ ?>
<img src="complaintdocs/xls.png" style="height:40px;width:40px">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature2']);?>" target="_blank">View File</a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions3))
{
?>  
<img style="width:50px;height:30px"src="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature2']);?>" ?>&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature2']);?>" target="_blank">View File</a>
<?php 
}else{ ?>
<img src="complaintdocs/unknown.png" style="height:40px;width:40px">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature2']);?>" target="_blank">View File</a>
<?php }
} ?>
</div>
</div>

<div class="row">
<div class="col-md-3">
<div class="form-group">
<label>PO Approval By3</label>
<select name="poapprovalby3" id="poapprovalby3" class="form-control">
<option value="<?php echo htmlentities($rowdays['poapprovalby3']);?>"><?php echo htmlentities($rowdays['poapprovalby3']);?></option>
<?php
require_once("dbcontrollernew.php");
$db_handledept = new DBController();
$querydept ="SELECT * FROM users";
$depts = $db_handledept->runQuery($querydept);
foreach($depts as $dept)
{
?>

<option value="<?php echo htmlentities($dept['fullName']);?>"><?php echo htmlentities($dept['fullName']);?></option>
<?php
}
?>
</select>	
</div>
</div> 

<div class="col-md-3">
<div class="form-group">
<label>Upload Digital Signature3<span style="color:red"></span> </label>
<input type="file" name="dig_signature3" class="form-control" id="dig_signature3">
<label><i style="font-size: smaller;">use only .jpg,.jpeg,.png,.bmp</i></label>
</div>
</div>

<div class="col-md-2">
<label></label><br>
<?php $cfile1=$rowdays['dig_signature3'];
if($cfile1==""  )
{

}
else if($cfile1=="NULL"||$cfile1=="default.png")
{
echo "File Not Attached";
}
else
{
$cfile2=pathinfo($rowdays['dig_signature3']);
$cfile2['extension'];
$cool_extensions = Array('doc','docx','DOCX','DOC');
$cool_extensions1 = Array('pdf','PDF');
$cool_extensions2=Array('xls','xlsx','XLS','XLSX');
$cool_extensions3=Array('jpg','png','jpeg','JPG','JPEG','PNG');
if (in_array($cfile2['extension'], $cool_extensions))
{ ?>
<img src="complaintdocs/doc.png" style="height:40px;width:45px">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature3']);?>" target="_blank">View File</a>
<?php
}
else if(in_array($cfile2['extension'], $cool_extensions1))
{ ?>
<img src="complaintdocs/pdf.png" style="height:40px;width:40px">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature3']);?>" target="_blank">View File</a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions2))
{ ?>
<img src="complaintdocs/xls.png" style="height:40px;width:40px">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature3']);?>" target="_blank">View File</a>
<?php }
else if(in_array($cfile2['extension'], $cool_extensions3))
{
?>  
<img style="width:50px;height:30px"src="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature3']);?>" ?>&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature3']);?>" target="_blank">View File</a>
<?php 
}else{ ?>
<img src="complaintdocs/unknown.png" style="height:40px;width:40px">
&nbsp;<a href="purchaseorderfiles/<?php echo htmlentities($rowdays['dig_signature3']);?>" target="_blank">View File</a>
<?php }
} ?>
</div>
</div> <!--row end-->
</div><!-- yesno id-->


<!-- file setting-->
<div class="row"> 
<div class="col-md-2">
<div class="form-group">
<h5><b>File Settings : </b></h5>
</div>
</div>
<div class="col-md-3">
<div class="form-group">
<label>File Size&nbsp;<span style="color:red" >*</span></label>
<input type="text" value="<?php echo htmlentities($rowdays['filesize']);?>" class="form-control" style="color:black" required="" name="filesize" >
</div>
</div>

<div class="col-md-3">
<div class="form-group">
<label>Size&nbsp;<span style="color:red">*</span></label>
<select class="form-control" name="totalsize" required="" >
<option value="<?php echo htmlentities($rowdays['filesize2']);?>"><?php echo htmlentities($rowdays['filesize2']);?><!-- Please Select --></option>
<option value="Bytes">Bytes</option>
<option value="KBytes">KBytes</option>
<option value="MBytes">MBytes</option>

</select>
</div>
</div>

<?php  
$type=$rowdays['filetype'];
$type1= trim($type,'"');
?>

<div class="col-md-3">
<div class="form-group">
<label>File Type&nbsp;<span style="color:red" >*</span></label>
<input type="text" class="form-control" value="<?php echo $type1?>" style="color:black" required="" name="filetype">
<label><i style="font-size: smaller;">Ex: .pdf,.jpg,.png</i></label>
</div>
</div>
</div>


<div class="row">
<div class="col-md-2">
<div class="form-group">
<h5><b>ISO Settings :</b></h5>
</div>
</div>
</div> 

<div class="row">
<div class="col-md-2">
<div class="form-group">
<span style="font-size: 11px;font-weight: 600;"><i>For Registration<br></i>
<span style="font-size: 11px;font-weight: 600;"><i>( Form Filling / Format )</span></i></span>
</div>
</div>
<div class="col-md-3">
<div class="form-group">
<label>ISO Format No.</label>
<input type="text" class="form-control" value="<?php echo htmlentities($rowdays['isonoreg']);?>" style="color:black" name="isonoreg" >
</div>
</div>

<div class="col-md-3">
<div class="form-group">
<label>ISO Format Revision No.</label>
<input type="text" class="form-control" value="<?php echo htmlentities($rowdays['isorevnoreg']);?>" style="color:black" name="isorevnoreg" >
</div>
</div>
</div>

<div class="row">
<div class="col-md-2">
<div class="form-group">
<span style="font-size: 11px;font-weight: 600;"><i>For View / Update<br></i>
<span style="font-size: 11px;font-weight: 600;"><i>( Records Register )</span></i></span>
</div>
</div>
<div class="col-md-3">
<div class="form-group">
<label>ISO Format No.</label>
<input type="text" class="form-control" value="<?php echo htmlentities($rowdays['isoformatno']);?>" style="color:black" name="isoformatno" >
</div>
</div>

<div class="col-md-3">
<div class="form-group">
<label>ISO Format Revision No.</label>
<input type="text" class="form-control" value="<?php echo htmlentities($rowdays['isoformatrevno']);?>" style="color:black" name="isoformatrevno">
</div>
</div>
</div>

<div class="row">
<div class="col-md-5">
<div class="form-group">
<h5><b>Mandatory Notes to Print in PO:</b></h5>
</div>
</div>
</div>

<div class="row">
<div class="col-md-3">
<div class="form-group">
<div class="wrap">
<textarea class=" form-control" style="background-color:white;line-height:1.6;text-align: justify;resize:vertical;width:300px;max-height:150px;" name="mandatorynote1" id="notes1" maxlength="200"><?php echo htmlspecialchars_decode($rowdays['mandatorynote1']);?></textarea>
 <span id="notescnt1" class="counter"></span></div>
</div>
</div>
<div class="col-md-3" style="margin-left:60px;">
<div class="form-group">
<div class="wrap">
<textarea class=" form-control" style="background-color:white;line-height:1.6;text-align: justify;resize:vertical;width:300px;max-height:150px;" name="mandatorynote2" id="notes2" maxlength="200"><?php echo htmlspecialchars_decode($rowdays['mandatorynote2']);?></textarea>
 <span id="notescnt2" class="counter"></span></div>
</div>
</div>
<div class="col-md-3" style="margin-left:60px;">
<div class="form-group">
<div class="wrap">
<textarea class=" form-control" style="background-color:white;line-height:1.6;text-align: justify;resize:vertical;width:300px;max-height:150px;" name="mandatorynote3" id="notes3" maxlength="200"><?php echo htmlspecialchars_decode($rowdays['mandatorynote3']);?></textarea>
 <span id="notescnt3" class="counter"></span></div>
</div>
</div>
</div>

<div class="row">
<div class="col-md-3">
<div class="form-group">
<div class="wrap">
<textarea class=" form-control" style="background-color:white;line-height:1.6;text-align: justify;resize:vertical;width:300px;max-height:150px;" name="mandatorynote4" id="notes4" maxlength="200"><?php echo htmlspecialchars_decode($rowdays['mandatorynote4']);?></textarea>
 <span id="notescnt4" class="counter"></span></div>
</div>
</div>
<div class="col-md-3" style="margin-left:60px;">
<div class="form-group">
<div class="wrap">
<textarea class=" form-control" style="background-color:white;line-height:1.6;text-align: justify;resize:vertical;width:300px;max-height:150px;" name="mandatorynote5" id="notes5" maxlength="200"><?php echo htmlspecialchars_decode($rowdays['mandatorynote5']);?></textarea>
 <span id="notescnt5" class="counter"></span></div>
</div>
</div>
</div>


<div class="row">
<div class="col-md-2">
<div class="form-group">
<br>
<button type="submit" name="updatedept" class="btn waves-effect waves-light btn-info" id='subm1'>Submit</button>
</div>
</div>
</div>

<?php } 
else
{ ?>

<br><br>
<h6 style="color:red;text-align:left;">Note  :  This Settings can be changed only by admin</h6>
<?php } } ?>

</form>
</div><!--2p-20-->
<?php }	
}?>
</div><!--1p-20--> 
</div><!--tab pane-->
</div><!--tab content-->

<!-- row -->
</div><!--container-->

</div><!-- cardbody -->
</div><!--card-->
</div><!-- col-12-->
</div>
</div><!-- tab-content -->
</div><!-- content-panel -->
<script src="assets/plugins/jquery/jquery.min.js"></script>
<script src="main/js/jquery-ui.js"></script>
<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="main/js/jquery.slimscroll.js"></script>
<script src="main/js/waves.js"></script>
<script src="main/js/sidebarmenu.js"></script>
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<script src="main/js/custom.min.js"></script>
<script src="assets/plugins/raphael/raphael-min.js"></script>
<script src="assets/plugins/morrisjs/morris.min.js"></script>
<script src="assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
<script src="assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="assets/plugins/wizard/jquery.steps.min.js"></script>
<script src="assets/plugins/wizard/jquery.validate.min.js"></script>
<script src="assets/plugins/sweetalert/sweetalert.min.js"></script>
<script src="assets/plugins/wizard/steps.js"></script>
<script src="main/js/dashboard2.js"></script>
<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
<!-- <script src="assets/datatables/jquery.dataTables.min.js"></script> -->
<!--script for multiple selection of department -->
<script src="assets/plugins/switchery/dist/switchery.min.js"></script>
<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script src="assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
<script src="assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js" type="text/javascript"></script>
<script src="assets/plugins/dff/dff.js" type="text/javascript"></script>
<script type="text/javascript" src="assets/plugins/multiselect/js/jquery.multi-select.js"></script>



<!-- datatable scripts start-->
<script src="assets/datatables/js/jquery.dataTables.js"></script>
<script src="assets/datatables/js/dataTables.buttons.min.js"></script> 
<script src="assets/datatables/js/jszip.min.js"></script>
<script src="assets/datatables/js/pdfmake.min.js"></script>
<script src="assets/datatables/js/vfs_fonts.js"></script>
<script src="assets/datatables/js/buttons.html5.min.js"></script>
<script src="assets/datatables/js/buttons.colVis.min.js"></script>
<script src="assets/datatables/js/buttons.print.min.js"></script>
<script src="assets/datatables/js/dataTables.bootstrap4.min.js"></script> 
<script src="assets/datatables/js/buttons.bootstrap4.min.js"></script>
<!--fixed Header-->
<script src="assets/datatables/js/dataTables.fixedHeader.min.js"></script>
<!-- datatable scripts end-->

<script>
$('.li-modal').on('click', function(e){
e.preventDefault();
$('#theModal').modal('show').find('.modal-content').load($(this).attr('href'));
});
</script>

<script type="text/javascript">
function digsigyesno()
{
if (document.getElementById('check1').checked) 
{
document.getElementById('yesno').style.display='block';
}
else
{
document.getElementById('yesno').style.display='none';
}
}
</script>
<script type="text/javascript">
$(document).ready(function(){
if(document.getElementById('check1').checked) 
{
document.getElementById('yesno').style.display='block';
}
else if(document.getElementById('check2').checked) 
{
document.getElementById('yesno').style.display='none';
}
});
</script>

<script type="text/javascript">
function yesnoCheck1() {
if(document.getElementById('yesid1').checked) 
{
document.getElementById('appid').style.display='block';
}
if(document.getElementById('noid1').checked)
{
document.getElementById('appid').style.display='none';
}
if(document.getElementById('yesid2').checked)
{
document.getElementById('appid2').style.display='block';
}
if(document.getElementById('noid2').checked)
{
document.getElementById('appid2').style.display='none';
}
}
</script>
<script type="text/javascript">
$(document).ready(function(){
if(document.getElementById('yesid1').checked) 
{
document.getElementById('appid').style.display='block';
}
if(document.getElementById('noid1').checked)
{
document.getElementById('appid').style.display='none';
}
if(document.getElementById('yesid2').checked)
{
document.getElementById('appid2').style.display='block';
}
if(document.getElementById('noid2').checked)
{
document.getElementById('appid2').style.display='none';
}
});
</script>


<script type="text/javascript">
var el_t = document.getElementById('notes1');
var length = el_t.getAttribute("maxlength");
var el_c = document.getElementById('notescnt1');
var totallength=el_t.value;
 document.getElementById('notescnt1').innerHTML=(length-totallength.length);
//el_c.innerHTML = length;
el_t.onkeyup = function () 
{
  document.getElementById('notescnt1').innerHTML = (length - this.value.length);
};
</script>
<script type="text/javascript">
var el_t = document.getElementById('notes2');
var length = el_t.getAttribute("maxlength");
var el_c = document.getElementById('notescnt2');
var totallength=el_t.value;
 document.getElementById('notescnt2').innerHTML=(length-totallength.length);
//el_c.innerHTML = length;
el_t.onkeyup = function () 
{
  document.getElementById('notescnt2').innerHTML = (length - this.value.length);
};
</script>
<script type="text/javascript">
var el_t = document.getElementById('notes3');
var length = el_t.getAttribute("maxlength");
var el_c = document.getElementById('notescnt3');
var totallength=el_t.value;
 document.getElementById('notescnt3').innerHTML=(length-totallength.length);
//el_c.innerHTML = length;
el_t.onkeyup = function () 
{
  document.getElementById('notescnt3').innerHTML = (length - this.value.length);
};
</script>
<script type="text/javascript">
var el_t = document.getElementById('notes4');
var length = el_t.getAttribute("maxlength");
var el_c = document.getElementById('notescnt4');
var totallength=el_t.value;
 document.getElementById('notescnt4').innerHTML=(length-totallength.length);
//el_c.innerHTML = length;
el_t.onkeyup = function () 
{
  document.getElementById('notescnt4').innerHTML = (length - this.value.length);
};
</script>
<script type="text/javascript">
var el_t = document.getElementById('notes5');
var length = el_t.getAttribute("maxlength");
var el_c = document.getElementById('notescnt5');
var totallength=el_t.value;
 document.getElementById('notescnt5').innerHTML=(length-totallength.length);
//el_c.innerHTML = length;
el_t.onkeyup = function () 
{
  document.getElementById('notescnt5').innerHTML = (length - this.value.length);
};
</script>

<script type="text/javascript">
var validate = function(e) {
var t = e.value;
e.value = (t.indexOf(".") >= 0) ? (t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 3)) : t;
}
</script>

<script>
Inputmask("(99,99,99,999){1|1}(){1|9}",
{
positionCaretOnClick: "radixFocus",
_radixDance: true,
radixPoint: ".",
numericInput: true,
placeholder: "",
}
).mask("inputmasking3");
</script>


<script>
$(document).ready(function() {
var table = $("#example").DataTable({
order: [[0, "desc"]],
// dom: "lBfrtip",

});
var buttons = new $.fn.dataTable.Buttons(table, {
buttons: [
{
extend: "collection",
text: '<i class="fa fa-share-square"></i>&nbsp; Tools',
buttons: [
{

extend: "print",
text: '<i class="fa fa-print"></i>&nbsp; Print',
filename: 'Machine_Detail_Entry',
exportOptions: {
columns: [0, 1, 2, 3, 4,5,6,7,8,9,10]
}
},
{
extend: "copyHtml5",
text: '<i class="fa fa-copy"></i>&nbsp; Copy',
exportOptions: {
columns: [0, 1, 2, 3, 4,5,6,7,8,9,10]
}
},
{
extend: "excelHtml5",
text: '<i class="fa fa-file-excel-o"></i>&nbsp; Excel',
title: 'Machine Detail Entry',
filename:  'Machine_Detail_Entry',
exportOptions: {
columns: [0, 1, 2, 3, 4,5,6,7,8,9,10]
}
},

{
extend: "csvHtml5",
text: '<i class="fa fa-table"></i>&nbsp; CSV',
// title: 'Customized CSV Title',
filename: 'Machine_Detail_Entry',
exportOptions: {
columns: [0, 1, 2, 3, 4,5,6,7,8,9,10]
}
},
{
extend: "pdfHtml5",
orientation: 'landscape',
pageSize: 'A4',
text:'<i class="fa fa-file-pdf-o"></i>&nbsp; PDF',
title: 'Machine Detail Entry',
filename:  'Machine_Detail_Entry',
exportOptions: {
columns: [0, 1, 2, 3, 4,5,6,7,8,9,10]

}
},


{
extend: "colvis",
text:'<i class="fa fa-barcode"></i><i class="fa fa-grip-lines-vertical"></i>&nbsp; Display Columns',
//text: 'Column Selection',

collectionLayout: "fixed two-column",
collectionTitle: "Select Columns to Display",
postfixButtons: ["colvisRestore"],
columnText: function(dt, idx, title) {
return idx + 1 + ": " + title;
}
},
{
text:'<i class="fa fa-database"></i>&nbsp; Export Database',
action: function ( e, dt, button, config ) {
window.location = 'machinebreak.php';
}        
}
]
}
]
}).container().appendTo($('#tools'));

new $.fn.dataTable.FixedHeader( table, {
header: true,
headerOffset: $('.topbar').height() //offset added to show tableheader just below theme header
} );

//fixed header when side bar is toggled
$(".sidebartoggler").on('click', function () {
$(".page-wrapper").removeClass("toggled");
table.columns.adjust().draw();
table.draw();
});
$(".sidebartoggler").on('click', function () {
$(".page-wrapper").addClass("toggled");
table.columns.adjust().draw();
});
});
</script>

<script type="text/javascript">
jQuery(document).ready(function() {
// Switchery
var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
$('.js-switch').each(function() {
new Switchery($(this)[0], $(this).data());
});
// For select 2
$(".select2").select2();
$('.selectpicker').selectpicker();
//Bootstrap-TouchSpin
$(".vertical-spin").TouchSpin({
verticalbuttons: true,
verticalupclass: 'ti-plus',
verticaldownclass: 'ti-minus'
});
var vspinTrue = $(".vertical-spin").TouchSpin({
verticalbuttons: true
});
if (vspinTrue) {
$('.vertical-spin').prev('.bootstrap-touchspin-prefix').remove();
}
$("input[name='tch1']").TouchSpin({
min: 0,
max: 100,
step: 0.1,
decimals: 2,
boostat: 5,
maxboostedstep: 10,
postfix: '%'
});
$("input[name='tch2']").TouchSpin({
min: -1000000000,
max: 1000000000,
stepinterval: 50,
maxboostedstep: 10000000,
prefix: '$'
});
$("input[name='tch3']").TouchSpin();
$("input[name='tch3_22']").TouchSpin({
initval: 40
});
$("input[name='tch5']").TouchSpin({
prefix: "pre",
postfix: "post"
});
// For multiselect
$('#pre-selected-options').multiSelect();
$('#optgroup').multiSelect({
selectableOptgroup: true
});
$('#public-methods').multiSelect();
$('#select-all').click(function() {
$('#public-methods').multiSelect('select_all');
return false;
});
$('#deselect-all').click(function() {
$('#public-methods').multiSelect('deselect_all');
return false;
});
$('#refresh').on('click', function() {
$('#public-methods').multiSelect('refresh');
return false;
});
$('#add-option').on('click', function() {
$('#public-methods').multiSelect('addOption', {
value: 42,
text: 'test 42',
index: 0
});
return false;
});
$(".ajax").select2({
ajax: {
url: "https://api.github.com/search/repositories",
dataType: 'json',
delay: 250,
data: function(params) {
return {
q: params.term, // search term
page: params.page
};
},
processResults: function(data, params) {
// parse the results into the format expected by Select2
// since we are using custom formatting functions we do not need to
// alter the remote JSON data, except to indicate that infinite
// scrolling can be used
params.page = params.page || 1;
return {
results: data.items,
pagination: {
more: (params.page * 30) < data.total_count
}
};
},
cache: true
},
escapeMarkup: function(markup) {
return markup;
}, // let our custom formatter work
minimumInputLength: 1,
//templateResult: formatRepo, // omitted for brevity, see the source of this page
//templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
});
});
</script>

<script>
function myFunctionstatus() {
swal("We are Sorry !", "Your license has expired.\n Please contact your administrator","warning")
}
</script>
<?php 
include("includes/footer.php");
?>
</body>
</html>
