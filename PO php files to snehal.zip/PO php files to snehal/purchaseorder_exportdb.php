 <?php
$mysql_hostname = "localhost";
$mysql_user = "root";
$mysql_password = "";
$mysql_database = "finalcms";
$bd = mysql_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Could not connect database");
mysql_select_db($mysql_database, $bd) or die("Could not select database");

?>
<?php 
session_start();
error_reporting(0);
include('includes/config.php');

 //if(isset($_POST["Export"])){
		 
      header('Content-Type: text/csv; charset=utf-8');  
      header('Content-Disposition: attachment; filename=purchaseorder_exportdb.csv');  
      $output = fopen("php://output", "w");  
      
      // heading for each column in csv
      fputcsv($output, array('id','PO No.','PO Date','Supplier Name','Vendor Code','Payment Term','Delivery Mode','Freight','Part Name','Drawing No','Item Remark','HSN Code','Req Qty','Shortage By','PO Qty','Unit','Delivery Date','Unit Price','Discount','Tax','CGST Amt','SGST Amt','IGST Amt','CESS','CESS Amt','Total Price','Notes','Terms and Condition','Amount Before Tax','Total CGST','Total SGST','Total IGST','Total CESS','Round Off','Total Amount','Purchased Qty','Rej Qty','Purchase %','Rej [ppm]','Order Status','Order Status Remark','Priority','Commitment Date','HOD Status','Management Status','PO Created By','PO Created Date','PO Created Dept','PO Edited By','PO Edited Date','PO Edited Dept'));  
	 // data from database 
	$query="SELECT id,pono,podate,suppliername,vendorcode,paymentterm,deliverymode,freight,partname,drawingno,remark,hsncode,reqqty,shortageby,poqty,unit,deliverydate,unitprice,discount,tax,cgstamt,sgstamt,igstamt,cesstype,cessamt,totalprice,notes, termsandcond,subtotal,cgstvalue,sgstvalue,igstvalue,totalcess,roundoff,totalrs,purchasedqty,rejqty,purchase_percent,rej_percent,orderstatus,statusremark,priority,statusdate,hodstatus,mgmt_status,reg_by,reg_date,reg_dept,edit_by,edit_date,edit_dept from purchaseorder_reg";
      $result = mysql_query($query);  
      while($row = mysql_fetch_assoc($result))  
      {  
           fputcsv($output, $row);  
      }  
      fclose($output);  
  //}

?>