<?php 
session_start();
if(!isset($_SESSION['id'],$_SESSION['department']))
{
header('location:index.php?lmsg=true');
exit;
}
require_once('includes/dbconfig.php');
include("includes/config.php");

?>
<?php
$timezone = 'Asia/Kolkata';
date_default_timezone_set($timezone);
$today = date('Y-m-d');
$year = date('Y');
if(isset($_GET['year'])){
$year = $_GET['year'];
}
?>

<!-- Adding status reason-->
<?php

 if(isset($_POST['submit']))
 {
 	$uid=$_SESSION['id'];
 	$name=$_SESSION['fullName'];

 	$statusreason=$_POST['statusreason'];
    $statusreason=htmlspecialchars($statusreason,ENT_QUOTES);
    
 	date_default_timezone_set('Asia/Kolkata');// change according timezone
	$dt2=date("Y-m-d h:i:s");

 $sql=mysql_query("insert into purchaseorder_statusreason (statusreason,creationDate,createdby,createdid) values('$statusreason','$dt2','$name','$uid')");
 	 if($sql=="")
 	{
 		echo '<script>				
				setTimeout(function() {
				swal({	
				            title: "Oops...!!!",
				            text: "Something went wrong",
				            type: "warning"		
					}, 
					 function() 
					{
				            window.location = "purchaseorder_statusreason.php";
				    });
				 }, 1000);
			 </script>';  
 	}
 	else
 	{
		echo '<script>				
				setTimeout(function() {
				swal({	
				            title: "Success!",
				            text: "Reason Added successfully",
				            type: "success"		
					}, 
					 function() 
					{
				            window.location = "purchaseorder_statusreason.php";
				    });
				 }, 1000);
			 </script>';    
	}  

 }

?>

<!--updating status as active or deactive -->

<?php 
if(isset($_GET['status']))
{
$status1=$_GET['status'];
$select=mysql_query("select * from purchaseorder_statusreason where id='$status1'");
while($row=mysql_fetch_object($select))
{
	$status_var=$row->status;
	if($status_var=='0')
	{
		$status_state=1;
	}
	else
	{
		$status_state=0;
	}
	$update=mysql_query("update purchaseorder_statusreason set status='$status_state' where id='$status1'");
	if($update)
	{
		header("Location:purchaseorder_statusreason.php");
	}
	else
	{
		echo mysql_error();
	}
}
						
?>			
<?php }
?>

<!--editing transport_mode -->
<?php  
if(isset($_POST['update1']))
{
$fullName=$_SESSION['fullName'];
$uid=$_SESSION['id'];

$id=$_POST['id'];

$statusreason=$_POST['statusreason'];
$statusreason=htmlspecialchars($statusreason,ENT_QUOTES);

date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt2=date("d-m-Y h:i:s");

$sql5=mysql_query("update purchaseorder_statusreason set statusreason='$statusreason',updationDate='$dt2',updatedby='$fullName',updatedid='$uid' where id='$id'");

if($sql5=="")
  {
        echo '<script>        
        setTimeout(function() {
        swal({  
                    title: "Oops...!!!",
                    text: "Something went wrong",
                    type: "warning"   
          }, 
           function() 
          {
                    window.location = "purchaseorder_statusreason.php";
            });
         }, 1000);
       </script>';       
 }
else 
{
    echo '<script>        
        setTimeout(function() {
        swal({  
                    title: "Success!",
                    text: "Reason Updated Successfully",
                    type: "success"   
          }, 
           function() 
          {
                    window.location = "purchaseorder_statusreason.php";
            });
         }, 1000);
       </script>';     
}
}
else
{

} ?>



<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" type="image/png" sizes="16x16" href="OTlogo.png">
<title>ESM | Sales Invoice</title>
<link rel="stylesheet" href="main/js/jquery-ui.css">
<script src="main/js/jquery-1.12.4.js"></script>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/plugins/html5-editor/bootstrap-wysihtml5.css" >
<!-- This page css -->
<link href="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="assets/plugins/switchery/dist/switchery.min.css"rel="stylesheet" />
<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" />
<link href="assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" />
<link href="assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css" />
<!-- <link href="assets/datatables/jquery.dataTables.yadcf.css" rel="stylesheet" type="text/css" />
<script src="assets/datatables/jquery.dataTables.yadcf.js"></script> -->
<link href="main/css/style.css" rel="stylesheet">
<link href="main/css/colors/blue.css" id="theme" rel="stylesheet">
<link href="assets/plugins/sweetalert/sweetalert.css">
<link href="assets/plugins/wizard/steps.css">
<!--[if lt IE 9]>
<script src="html5shiv.js"></script>
<script src="respond.min.js"></script>
<![endif]-->
<script src="main/js/jquery-ui.js"></script>
<script src="jquery.min.js"></script>
<link href="sweetalert.css" rel="stylesheet"/>
<script src="sweetalert.min.js"></script>

<script src="main/js/jquery-inputmask.js"></script>

  <!-- datatable css-->
<link href="assets/datatables/css/dataTables.bootstrap4.min.css" rel="stylesheet">
<link href="assets/datatables/css/buttons.bootstrap4.min.css" rel="stylesheet">
<link href="assets/datatables/css/jquery.dataTables.css" rel="stylesheet" type="text/css" />
<link href="assets/datatables/css/fixedHeader.dataTables.min.css" rel="stylesheet" />
<link href="assets/datatables/css/select.dataTables.min.css" rel="stylesheet">


<style>
div.scrollmenu 
{
overflow: auto;
}
.form-control 
{
font-size:small;
}
@import url('font-awesome.min.css');
.panel-title > a:before {
float: right !important;
font-family: FontAwesome;
content:"\f068";
padding-right: 5%;
}
.panel-title > a.collapsed:before {
float: right !important;
content:"\f067";
}
.panel-title > a:hover, 
.panel-title > a:active, 
.panel-title > a:focus  {
text-decoration:none;
}td{

color:#2C3E50;
}
</style>
<style>
.act { color:#007F00; }
.deact { color:#F00;}

 /* Custom Swal buttons for operator data entry deletion: Are You Sure, You want to delete entry */
    .sweet-alert[data-custom-class="mycustomclass"] button.confirm {
      color: white;
      background-color: green;
    }
    .sweet-alert.mycustomclass button.cancel {
      color: white;
      background-color: red;
    }
</style>

<!--datatable style -->
<style type="text/css">

/*printing text wordwrap*/
table {
  table-layout:fixed;
}
table td {
  word-wrap: break-word;
  max-width: 400px;
}


/* word wrapping content of td*/
#example td {
  white-space:inherit;
}

/*locating tools button*/
#tools {
  margin-left: 80%;
  margin-top: 10px;
}

/*table resizing according to page view and tableheader background color*/
table {border-collapse:collapse; table-layout:fixed; width:100%;}
table td {border:solid 1px #fab; width:100px; word-wrap:none;}
table.dataTable thead .sorting, table.dataTable thead .sorting_asc, table.dataTable thead .sorting_desc, table.dataTable thead .sorting_asc_disabled, table.dataTable thead .sorting_desc_disabled {
  background: #1976d2;
  color: white;
  margin-top: 20px;
  vertical-align: inherit;

}
table.dataTable thead th, table.dataTable tfoot th {
  font-weight: 500;
}

/*To maintain space between its content and border*/
table.dataTable thead>tr>th.sorting_asc, table.dataTable thead>tr>th.sorting_desc, table.dataTable thead>tr>th.sorting, table.dataTable thead>tr>td.sorting_asc, table.dataTable thead>tr>td.sorting_desc, table.dataTable thead>tr>td.sorting {
  padding-right: inherit;
} 

/* background and textcolor for datable tools button*/
a.dt-button.dropdown-item{
  background-color: #1976d2;
  color:white;
}
a.dt-button.buttons-columnVisibility.active{
  background-color: #1976d2;
  color:white;
}
a.dt-button.buttons-columnVisibility{
  background-color: white ;
  color: #333;
}
/* coloumn visibility title background : 'Select Columns to Display'*/
div.dt-button-collection div.dt-button-collection-title {
  background-color: orangered;
  border: 1px solid rgba(0,0,0,0.15);
  border-radius: 0.25rem;
  color: white;
  width: 560px;
  font-size: small;
  font-family:Poppins, sans-serif;
  font-size:16px;
  font-weight:400;
  height:auto;
}

/* Table Header break line(<br>) in print */
table.dataTable thead th, table.dataTable tfoot th {
   font-weight: 500;
   white-space: inherit;
}
/* Table Header margin-left 3px in print */
table.dataTable thead th, table.dataTable thead th {
 padding: 10px 3px;
 border-bottom: 1px solid #111111; 
}

table.dataTable tbody td {
    word-break: break-word;
    vertical-align: top;
}

</style>


</head>
<body class="fix-header fix-sidebar card-no-border">
<div id="main-wrapper" class="scrollmenu" style="font-size:small">
<?php include("includes/config.php");?>
<?php include("includes/header.php");?> 
<?php include("includes/sidebar.php");?>
<div class="page-wrapper" >
<div class="row page-titles m-b-0 " style="height:45px">
<div class="col-md-5 align-self-center">
<h4 class="text-themecolor">Sales Invoice</h4>
</div>
<div class="col-md-7 align-self-center">
<ol class="breadcrumb">
<li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
<li class="breadcrumb-item"><a href="dp_dailyproduction.php">Sales Invoice</a></li>
<li class="breadcrumb-item"><a href="salesorder_setting.php">Settings</a></li>
</ol>
</div> 
</div> 

<br>
<div class="container-fluid">   	
<div class="row">
<div class="col-12">
<div class="card">
<div class="card-body">

  <!-- Nav tabs -->
<!-- settings start-->
<?php 
$queryacc=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($rowacc=mysql_fetch_array($queryacc)) 
{
?> 
<ul class="nav nav-tabs" role="tablist">
<?php
$query21=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($row21=mysql_fetch_array($query21)) 
{  
$complaintarr1=$row21['purchaseorderaccess'];
$comarr1=explode(',',trim( $complaintarr1));
$secondaryarr1=$row21['multidept'];
$secarr2=explode(',',trim($secondaryarr1));
//to remove last comma from multidept array
$lastcomma = '';
foreach($secarr2 as $i=>$k) 
{
$lastcomma .= $k.',';
}
$lastcomma = rtrim($lastcomma,',');
$secarr1=explode(',',trim($lastcomma));
$querydays1=mysql_query("select * from purchaseorder_setting order by id desc limit 1");
while($rowdays1=mysql_fetch_array($querydays1)) 
{ 
$quadept1=$rowdays1['po_regdept'];
$qua1=explode(',',trim($quadept1));
$result1 = array_intersect($secarr1,$qua1);
if((($result1!=array())||(in_array($row21['department'],$qua1))) && (in_array('regpurchaseorder',$comarr1)))
{  ?>

<?php $query1=mysql_query("select * from master order by id desc limit 1");
while($row1=mysql_fetch_array($query1))
{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt3=date("Y-m-d h:i");
if($row1['licend']<= $dt3) 
{ ?>
<li class="nav-item"><a class="nav-link"  onclick="myFunctionstatus()" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span><span class="hidden-xs-down">Register</span></a></li> 
<?php } 
else
{ ?>
<li class="nav-item"><a class="nav-link" href="purchaseorder_register.php" role="tab"><span class="hidden-sm-up"><i class="ti-email"></i></span> <span class="hidden-xs-down"> Register &nbsp;<b>
</b></span></a> 
</li>
<?php } 
} 

}else{

} } } ?>

<?php   
$inhousecomarr=$rowacc['purchaseorderaccess'];
$inhousearr=explode(',',trim( $inhousecomarr));
if(in_array('viewpurchaseorder',$inhousearr))
{ ?>
<?php $query1=mysql_query("select * from master order by id desc limit 1");
while($row1=mysql_fetch_array($query1))
{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt3=date("Y-m-d h:i:s");
if($row1['licend']<= $dt3) 
{
?>
<li class="nav-item"><a class="nav-link active" onclick="myFunctionstatus()" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span><span class="hidden-xs-down">View/Update</span></a></li> 
<?php } 
else
{ ?>
<li class="nav-item"><a class="nav-link" href="purchaseorder_viewup.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">View/Update</span></a> </li>
<?php } 
} ?>

<?php
} else{

} 
?>

<?php $companymaster=$rowacc['addmanageaccess'];
$compaarr=explode(',',trim($companymaster));
if(in_array('generalmanage',$compaarr))
{?>
<li class="nav-item"> <a class="nav-link active"  href="purchaseorder_setting.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Settings</span></a> </li>
<?php } } ?>  
</ul>
<!--settings end -->
<!-- Tab panes -->


<div class="tab-content tabcontent-border">
<div class="tab-pane active" id="home" role="tabpanel">
<?php 
$queryacc=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($rowaccess=mysql_fetch_array($queryacc)) 
{
?> 

<br>
<div class="row" style="margin-left:20px;">
<ul class="nav nav-tabs" role="tablist">
<li class="nav-item"> <a class="nav-link"  href="purchaseorder_setting.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Approving Departments</span></a> </li>
<li class="nav-item"> <a class="nav-link active"  href="purchaseorder_statusreason.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Add Status Reason</span></a> </li>
</ul>
</div>


<br>
<div class="row" style="margin-right:30%">
<?php 
$addmanagearr=$rowaccess['addmanageaccess'];
$addarr=explode(',',trim( $addmanagearr));
if(in_array('generalmanage',$addarr))
{ ?>

<div class="col-sm-2"style="padding-left:20px">
<button type="button"  class="btn btn-warning" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Add New +</button>                                       
</div> 
<?php } ?>
<div class="col-sm-1"style="padding-left:15px">
<form class="form-horizontal" action="" method="post" name="upload_excel" enctype="multipart/form-data">
<!-- <div> <input type="submit" name="Export1" class="btn btn-warning" value="Export"/>	</div> -->						                   	
</form> 
</div>
</div>


<!-- <div id="tools"></div> -->
<table id="example" cellpadding="0" cellspacing="0" border="0" class=" table table-bordered table-striped display" style="width:100%">
<thead>
<tr>
<th style="font-size:small">#</th>
<th style="font-size:small">Reason</th>
<th style="font-size:small">Creation Date</th>
<th style="font-size:small">Last Updated</th>										
<th style="font-size:small">Edit</th>
<th style="font-size:small">Action</th>
</tr>
</thead>
<tbody>
<?php 
$query=mysql_query("select * from purchaseorder_statusreason");
$cnt=1;
while($row=mysql_fetch_array($query))
{
$id=$row['id'];
$statusreason=$row['statusreason'];
$status=$row['status'];
?>							
<tr>
<td style="font-size:small"><?php echo htmlentities($row['id']);?></td>
<td><?php echo htmlspecialchars_decode($row['statusreason']);?></td>
<td><?php echo htmlspecialchars_decode($row['creationDate']);?></td>
<td><?php echo htmlspecialchars_decode($row['updationDate']);?></td>
<td>
<?php 
if(in_array('generalmanage',$addarr))
{
?>
<a href="purchaseorder_statusreasonedit.php?cid=<?php echo htmlentities($row['id']);?>" class='li-modal'>
<button class="btn btn-primary"><i class="fa fa-edit"></i></button>
</a>
<div id="theModal" class="modal fade text-center">
<div class="modal-dialog">
<div class="modal-content">
</div>
</div>
</div>
<?php } 
else if($row['status']=="0")
{ 
?>
<button class="btn btn-disabled"><a onclick="myFunction1()"><i class="fa fa-edit"></i></a></button>
<?php 
} 
else 	
{ ?>
<button class="btn btn-disabled"><a onclick="myFunction2()"><i class="fa fa-edit"></i></a></button>
<?php }	?>													
</td>		
<td>
<?php 
if(($status)=='0')
{
?>
	<a href="purchaseorder_statusreason.php?status=<?php echo $row['id'];?>"
		class="act">Deactive</a>														
<?php
} 
?>
<?php 
if(($status)=='1')
{
?>
   <a href="purchaseorder_statusreason.php?status=<?php echo $row['id'];?>"
	class="deact">Active</a>
<?php 
}
?>																						</td>											
</tr>
<?php  } } ?>
</tbody>
</table>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title" id="exampleModalLabel1">Add Reason For Status Update</h4>
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
</div>
<div class="modal-body">
<form name="department" class="form-horizontal style-form"method="post">
<div class="row">
<div class="col-md-12">
<div class="form-group">
<label>Reason For Status Update</label>
<textarea class=" form-control" style="background-color:white;line-height:1.6;text-align:justify;margin-top:8px;max-height:200px;resize:vertical;" name="statusreason" maxlength="200"><?php echo htmlspecialchars_decode($row['statusreason'])?></textarea>
</div>
</div>
</div>
<button type="submit" name="submit" class="btn btn-success">Create</button> 
</form> 

<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">                   
</form>                                        
</div>
</div>	  
</div>
</div>


</div><!--tab content-->

</div>
</div><!--container-->

</div><!-- cardbody -->
</div><!--card-->
</div><!-- col-12-->
</div>
</div><!-- tab-content -->
</div><!-- content-panel -->
<script src="assets/plugins/jquery/jquery.min.js"></script>
<script src="main/js/jquery-ui.js"></script>
<script src="assets/plugins/bootstrap/js/popper.min.js"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="main/js/jquery.slimscroll.js"></script>
<script src="main/js/waves.js"></script>
<script src="main/js/sidebarmenu.js"></script>
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<script src="main/js/custom.min.js"></script>
<script src="assets/plugins/raphael/raphael-min.js"></script>
<script src="assets/plugins/morrisjs/morris.min.js"></script>
<script src="assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
<script src="assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="assets/plugins/wizard/jquery.steps.min.js"></script>
<script src="assets/plugins/wizard/jquery.validate.min.js"></script>
<script src="assets/plugins/sweetalert/sweetalert.min.js"></script>
<script src="assets/plugins/wizard/steps.js"></script>
<script src="main/js/dashboard2.js"></script>
<script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
<!-- <script src="assets/datatables/jquery.dataTables.min.js"></script> -->
<!--script for multiple selection of department -->
<script src="assets/plugins/switchery/dist/switchery.min.js"></script>
<script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
<script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
<script src="assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
<script src="assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js" type="text/javascript"></script>
<script src="assets/plugins/dff/dff.js" type="text/javascript"></script>
<script type="text/javascript" src="assets/plugins/multiselect/js/jquery.multi-select.js"></script>



<!-- datatable scripts start-->
  <script src="assets/datatables/js/jquery.dataTables.js"></script>
  <script src="assets/datatables/js/dataTables.buttons.min.js"></script> 
  <script src="assets/datatables/js/jszip.min.js"></script>
  <script src="assets/datatables/js/pdfmake.min.js"></script>
  <script src="assets/datatables/js/vfs_fonts.js"></script>
  <script src="assets/datatables/js/buttons.html5.min.js"></script>
  <script src="assets/datatables/js/buttons.colVis.min.js"></script>
  <script src="assets/datatables/js/buttons.print.min.js"></script>
  <script src="assets/datatables/js/dataTables.bootstrap4.min.js"></script> 
  <script src="assets/datatables/js/buttons.bootstrap4.min.js"></script>
  <!--fixed Header-->
  <script src="assets/datatables/js/dataTables.fixedHeader.min.js"></script>
<!-- datatable scripts end-->

<script>
$('.li-modal').on('click', function(e){
e.preventDefault();
$('#theModal').modal('show').find('.modal-content').load($(this).attr('href'));
});
</script>

<script type="text/javascript">
  function yesnoCheck1() {
    if (document.getElementById('check1').checked) {
        document.getElementById('appid').style.display='block';
    }

    if (document.getElementById('check3').checked) {     
        document.getElementById('appid2').style.display='block';
  
    }
}
</script>
<script type="text/javascript">
$(document).ready(function(){
   if (document.getElementById('check1').checked) {
        document.getElementById('appid').style.display='block';
    }

    if (document.getElementById('check3').checked) {     
        document.getElementById('appid2').style.display='block';
  
    }
});
</script>

<script type="text/javascript">
var validate = function(e) {
  var t = e.value;
  e.value = (t.indexOf(".") >= 0) ? (t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 3)) : t;
}
</script>




<script>
Inputmask("(99,99,99,999){1|1}(){1|9}",
     {
        
         positionCaretOnClick: "radixFocus",
         _radixDance: true,
         radixPoint: ".",
         numericInput: true,
         placeholder: "",
         
       
     }
 ).mask("inputmasking3");
</script>


<!-- <script>
	var table = $('#example').DataTable({
	order:[[0,"desc"]],
	//lBfrtip -- "l" moves buttons to left side  	
	dom:'lBfrtip',
        buttons: [
             'csv', 'excel', 'pdf', 'print'
        ]
        });
</script> -->
<script type="text/javascript">
jQuery(document).ready(function() {
// Switchery
var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
$('.js-switch').each(function() {
  new Switchery($(this)[0], $(this).data());
});
// For select 2
$(".select2").select2();
$('.selectpicker').selectpicker();
//Bootstrap-TouchSpin
$(".vertical-spin").TouchSpin({
  verticalbuttons: true,
  verticalupclass: 'ti-plus',
  verticaldownclass: 'ti-minus'
});
var vspinTrue = $(".vertical-spin").TouchSpin({
  verticalbuttons: true
});
if (vspinTrue) {
  $('.vertical-spin').prev('.bootstrap-touchspin-prefix').remove();
}
$("input[name='tch1']").TouchSpin({
  min: 0,
  max: 100,
  step: 0.1,
  decimals: 2,
  boostat: 5,
  maxboostedstep: 10,
  postfix: '%'
});
$("input[name='tch2']").TouchSpin({
  min: -1000000000,
  max: 1000000000,
  stepinterval: 50,
  maxboostedstep: 10000000,
  prefix: '$'
});
$("input[name='tch3']").TouchSpin();
$("input[name='tch3_22']").TouchSpin({
  initval: 40
});
$("input[name='tch5']").TouchSpin({
  prefix: "pre",
  postfix: "post"
});
// For multiselect
$('#pre-selected-options').multiSelect();
$('#optgroup').multiSelect({
  selectableOptgroup: true
});
$('#public-methods').multiSelect();
$('#select-all').click(function() {
  $('#public-methods').multiSelect('select_all');
  return false;
});
$('#deselect-all').click(function() {
  $('#public-methods').multiSelect('deselect_all');
  return false;
});
$('#refresh').on('click', function() {
  $('#public-methods').multiSelect('refresh');
  return false;
});
$('#add-option').on('click', function() {
  $('#public-methods').multiSelect('addOption', {
    value: 42,
    text: 'test 42',
    index: 0
  });
  return false;
});
$(".ajax").select2({
  ajax: {
    url: "https://api.github.com/search/repositories",
    dataType: 'json',
    delay: 250,
    data: function(params) {
      return {
                q: params.term, // search term
                page: params.page
              };
            },
            processResults: function(data, params) {
            // parse the results into the format expected by Select2
            // since we are using custom formatting functions we do not need to
            // alter the remote JSON data, except to indicate that infinite
            // scrolling can be used
            params.page = params.page || 1;
            return {
              results: data.items,
              pagination: {
                more: (params.page * 30) < data.total_count
              }
            };
          },
          cache: true
        },
        escapeMarkup: function(markup) {
          return markup;
    }, // let our custom formatter work
    minimumInputLength: 1,
    //templateResult: formatRepo, // omitted for brevity, see the source of this page
    //templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
  });
});
</script>

<script>
$(document).ready(function() {
  var table = $("#example").DataTable({
    order: [[0, "desc"]],
  // dom: "lBfrtip",

});
  var buttons = new $.fn.dataTable.Buttons(table, {
   buttons: [
   {
    extend: "collection",
    text: '<i class="fa fa-share-square"></i>&nbsp; Tools',
    buttons: [
    {

      extend: "print",
      text: '<i class="fa fa-print"></i>&nbsp; Print',
      filename: 'Machine_Detail_Entry',
      exportOptions: {
        columns: [0, 1, 2, 3, 4,5,6,7,8,9,10]
      }
    },
    {
      extend: "copyHtml5",
      text: '<i class="fa fa-copy"></i>&nbsp; Copy',
      exportOptions: {
        columns: [0, 1, 2, 3, 4,5,6,7,8,9,10]
      }
    },
    {
      extend: "excelHtml5",
      text: '<i class="fa fa-file-excel-o"></i>&nbsp; Excel',
      title: 'Machine Detail Entry',
      filename:  'Machine_Detail_Entry',
      exportOptions: {
        columns: [0, 1, 2, 3, 4,5,6,7,8,9,10]
      }
    },

    {
      extend: "csvHtml5",
      text: '<i class="fa fa-table"></i>&nbsp; CSV',
           // title: 'Customized CSV Title',
           filename: 'Machine_Detail_Entry',
           exportOptions: {
            columns: [0, 1, 2, 3, 4,5,6,7,8,9,10]
          }
        },
        {
          extend: "pdfHtml5",
           orientation: 'landscape',
           pageSize: 'A4',
          text:'<i class="fa fa-file-pdf-o"></i>&nbsp; PDF',
          title: 'Machine Detail Entry',
          filename:  'Machine_Detail_Entry',
          exportOptions: {
            columns: [0, 1, 2, 3, 4,5,6,7,8,9,10]

          }
        },


        {
          extend: "colvis",
          text:'<i class="fa fa-barcode"></i><i class="fa fa-grip-lines-vertical"></i>&nbsp; Display Columns',
          //text: 'Column Selection',

          collectionLayout: "fixed two-column",
          collectionTitle: "Select Columns to Display",
          postfixButtons: ["colvisRestore"],
          columnText: function(dt, idx, title) {
            return idx + 1 + ": " + title;
          }
        },
        {
          text:'<i class="fa fa-database"></i>&nbsp; Export Database',
          action: function ( e, dt, button, config ) {
            window.location = 'machinebreak.php';
          }        
        }
        ]
      }
      ]
    }).container().appendTo($('#tools'));

  new $.fn.dataTable.FixedHeader( table, {
    header: true,
      headerOffset: $('.topbar').height() //offset added to show tableheader just below theme header
    } );

    //fixed header when side bar is toggled
    $(".sidebartoggler").on('click', function () {
      $(".page-wrapper").removeClass("toggled");
      table.columns.adjust().draw();
      table.draw();
    });
    $(".sidebartoggler").on('click', function () {
      $(".page-wrapper").addClass("toggled");
      table.columns.adjust().draw();
    });
  });
</script>

<script>
		$(document).ready(function() {
			$('.datatable-1').dataTable();
			$('.dataTables_paginate').addClass("btn-group datatable-pagination");
			$('.dataTables_paginate > a').wrapInner('<span />');
		} );
</script>

<script>
function myFunctionstatus() {
swal("We are Sorry !", "Your license has expired.\n Please contact your administrator","warning")
}
</script>

<footer class="footer">
 <a style="font-size:small;height:10px"> Enterprise Solution Management | Version - 1 . 1 0
     <br>
     © 2019 | All Rights Reserved
     <a href="http://otes.in/" target="_blank" title="Ocean Technologies" style="text-align:center;font-size:small;color:#3366ff;font-weight:bold">      
       <span href="http://otes.in/" target="_blank" title="Ocean Technologies" style="color: #1976D2;">&nbsp;&nbsp;OC<span style="color: #ff9900;">EAN</span></span> Technologies
     </a>
   </a>
 </footer>
</body>
</html>
