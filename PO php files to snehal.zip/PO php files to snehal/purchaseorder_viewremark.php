
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>     <script src="main/js/jquery-1.12.4.js"></script>
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/plugins/html5-editor/bootstrap-wysihtml5.css" >
<link href="assets/plugins/footable/css/footable.core.css" rel="stylesheet">
<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet">
<link href="main/css/style.css" rel="stylesheet">
<link href="main/css/colors/blue.css" id="theme" rel="stylesheet">
<link href="assets/plugins/sweetalert/sweetalert.css">
<link href="assets/plugins/wizard/steps.css">
<script src="assets/Chart.min.js"></script>
<!--[if lt IE 9]>
<script src="html5shiv.js"></script>
<script src="respond.min.js"></script>
<![endif]-->
<script src="main/js/jquery-ui.js"></script>
<script src="jquery.min.js"></script>
<link rel="stylesheet" href="bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<!-- Include SmartWizard CSS -->
<link href="assets/dist/css/smart_wizard.css" rel="stylesheet" type="text/css" >
<!-- Optional SmartWizard theme -->
<link href="assets/dist/css/smart_wizard_theme_arrows.css" rel="stylesheet" type="text/css" >
<!-- This page css -->
<!-- <link href="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css"> -->
<link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" >
<link href="assets/plugins/switchery/dist/switchery.min.css"rel="stylesheet" >
<link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" >
<link href="assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" >
<link href="assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css" rel="stylesheet" >
<link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css" >
<link href="sweetalert.css" rel="stylesheet">
<script src="sweetalert.min.js"></script>

<body>
  <?php 
  require_once('includes/dbconfig.php');
  include("includes/config.php");
  $id12=$_GET['cid'];
  $query=mysql_query("select * from purchaseorder_reg where id='$id12'");
  while($row=mysql_fetch_array($query))
  { 
     //$sono=$row['sono'];
     //$customerid=$row['customerid'];    
      ?>  
      <div class="modal-header">
        <h5>Item and Order Status Remark</h5>
        <button type="button" class="close" data-dismiss="modal" onclick="window.location.href='purchaseorder_viewup.php';">x</button>
      </div>


<div class="modal-body">
<form method="post" enctype="multipart/form-data" style="margin-top:1%" name="updateform">
<div class="row">
<table>
<tr>
<td style="font-weight:500;font-size:14px;">Item Remark</td>
</tr>
<tr>
<td style="text-align:justify;font-size:14px;"><?php echo htmlspecialchars_decode($row['remark']);?></td>
</tr>
<tr>
<td style="font-weight:500;font-size:14px;">Status Remark</td>
</tr>
<tr>
<td style="text-align: justify;font-size:14px;"><?php echo htmlspecialchars_decode($row['statusremark']);?></td>
</tr>
</table>
</div>   
</div><!-- class="modal-body"-->

<?php } ?>


<!-- new datepicker script with year selection -->
<script src="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<link href="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css"/>

<script type="text/javascript">
jQuery(document).ready(function() {
// Switchery
var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
$('.js-switch').each(function() {
new Switchery($(this)[0], $(this).data());
});
// For select 2
$(".select2").select2();
$('.selectpicker').selectpicker();
//Bootstrap-TouchSpin
$(".vertical-spin").TouchSpin({
verticalbuttons: true,
verticalupclass: 'ti-plus',
verticaldownclass: 'ti-minus'
});
var vspinTrue = $(".vertical-spin").TouchSpin({
verticalbuttons: true
});
if (vspinTrue) {
$('.vertical-spin').prev('.bootstrap-touchspin-prefix').remove();
}
$("input[name='tch1']").TouchSpin({
min: 0,
max: 100,
step: 0.1,
decimals: 2,
boostat: 5,
maxboostedstep: 10,
postfix: '%'
});
$("input[name='tch2']").TouchSpin({
min: -1000000000,
max: 1000000000,
stepinterval: 50,
maxboostedstep: 10000000,
prefix: '$'
});
$("input[name='tch3']").TouchSpin();
$("input[name='tch3_22']").TouchSpin({
initval: 40
});
$("input[name='tch5']").TouchSpin({
prefix: "pre",
postfix: "post"
});
// For multiselect
$('#pre-selected-options').multiSelect();
$('#optgroup').multiSelect({
selectableOptgroup: true
});
$('#public-methods').multiSelect();
$('#select-all').click(function() {
$('#public-methods').multiSelect('select_all');
return false;
});
$('#deselect-all').click(function() {
$('#public-methods').multiSelect('deselect_all');
return false;
});
$('#refresh').on('click', function() {
$('#public-methods').multiSelect('refresh');
return false;
});
$('#add-option').on('click', function() {
$('#public-methods').multiSelect('addOption', {
value: 42,
text: 'test 42',
index: 0
});
return false;
});
$(".ajax").select2({
ajax: {
url: "https://api.github.com/search/repositories",
dataType: 'json',
delay: 250,
data: function(params) {
return {
q: params.term, // search term
page: params.page
};
},
processResults: function(data, params) {
// parse the results into the format expected by Select2
// since we are using custom formatting functions we do not need to
// alter the remote JSON data, except to indicate that infinite
// scrolling can be used
params.page = params.page || 1;
return {
results: data.items,
pagination: {
more: (params.page * 30) < data.total_count
}
};
},
cache: true
},
escapeMarkup: function(markup) {
return markup;
}, // let our custom formatter work
minimumInputLength: 1,
//templateResult: formatRepo, // omitted for brevity, see the source of this page
//templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
});
});
</script>

    <script src="assets/plugins/jquery/jquery.min.js"></script>
    <script src="main/js/jquery-ui.js"></script>
    <script src="assets/plugins/bootstrap/js/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="main/js/jquery.slimscroll.js"></script>
    <script src="main/js/waves.js"></script>
    <script src="main/js/sidebarmenu.js"></script>
    <script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="main/js/custom.min.js"></script>
    <script src="assets/plugins/chartist-js/dist/chartist.min.js"></script>
    <script src="assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="assets/plugins/raphael/raphael-min.js"></script>
    <script src="assets/plugins/morrisjs/morris.min.js"></script>
    <script src="assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="assets/plugins/wizard/jquery.steps.min.js"></script>
    <script src="assets/plugins/wizard/jquery.validate.min.js"></script>
    <script src="assets/plugins/sweetalert/sweetalert.min.js"></script>
    <script src="assets/plugins/wizard/steps.js"></script>
    <script src="main/js/dashboard2.js"></script>
    <script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
    <script src="assets/datatables/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="assets/dist/js/jquery.smartWizard.min.js"></script>
 
<script type="text/javascript">
$(document).ready(function(){

// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard').smartWizard({
selected: 0,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>
<script type="text/javascript">
$(document).ready(function(){

// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard1').smartWizard({
selected: 1,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>
<script type="text/javascript">
$(document).ready(function(){

// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard2').smartWizard({
selected: 2,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>

<script type="text/javascript">
$(document).ready(function(){

// Toolbar extra buttons
var btnFinish = $('<button></button>').text('Finish')
.addClass('btn btn-info')
.on('click', function(){ alert('Finish Clicked'); });
var btnCancel = $('<button></button>').text('Cancel')
.addClass('btn btn-danger')
.on('click', function(){ $('#smartwizard').smartWizard("reset"); });

// Smart Wizard
$('#smartwizard3').smartWizard({
selected: 3,
theme: 'arrows',
transitionEffect:'fade',
toolbarSettings: {toolbarPosition: 'bottom',
toolbarExtraButtons: [btnFinish, btnCancel]
}
});
});
</script>


</body>
