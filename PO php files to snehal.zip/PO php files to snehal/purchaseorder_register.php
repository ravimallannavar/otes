<!--modified with customer address -->
<?php 
error_reporting(E_ERROR | E_PARSE);
  include("newdb.php");
  session_start();
  if(!isset($_SESSION['id']))
  {
    header('location:index.php?lmsg=true');
    exit;
  }
   include("includes/config.php");
?>
<?php
  $timezone = 'Asia/Manila';
  date_default_timezone_set($timezone);
   $today = date('d-m-Y');
    $year = date('Y');
    if(isset($_GET['year'])){
    $year = $_GET['year'];
  }
?>
<?php
if(isset($_POST['addpo']))
{

$uid=$_SESSION['id'];
$name=$_SESSION['fullName'];
$department=$_SESSION['department'];
date_default_timezone_set('Asia/Kolkata');// change according timezone
$reg_date=date("d-m-Y h:i:s");

$pono=$_POST['pono'];
$pono=htmlspecialchars($pono,ENT_QUOTES);

$podate=date("d-m-Y h:i:s");

// $inwardagainst=$_POST['inwardagainst'];
// $inwardagainst=htmlspecialchars($inwardagainst,ENT_QUOTES);

require("connection.php");


$supplier_id=$_POST['suppliername'];
$query12="select * from supplier where id=$supplier_id";
$result12 = mysqli_query($con, $query12);
while($rw12 = mysqli_fetch_array($result12))
{
$suppliername=$rw12['suppliername'];
}
$supplierid=$_POST['supplierid'];
$supplierid=htmlspecialchars($supplierid,ENT_QUOTES);

$sameasbill=$_POST['sameasbill'];
$sameasbill=htmlspecialchars($sameasbill,ENT_QUOTES);

$vendorcode=$_POST['vendorcode'];
$vendorcode=htmlspecialchars($vendorcode,ENT_QUOTES);

$paymentterm=$_POST['paymentterm'];
$paymentterm=htmlspecialchars($paymentterm,ENT_QUOTES);

$deliverymode=$_POST['deliverymode'];
$deliverymode=htmlspecialchars($deliverymode,ENT_QUOTES);

$freight=$_POST['freight'];
$freight=htmlspecialchars($freight,ENT_QUOTES);

$ssid=$_POST['ssid'];
$ssid=htmlspecialchars($ssid,ENT_QUOTES);

$notes=$_POST['notes'];
$notes=htmlspecialchars($notes,ENT_QUOTES);

$termsandcond=$_POST['termsandcond'];
$termsandcond=htmlspecialchars($termsandcond,ENT_QUOTES);

//Attach file
$pathd=$_FILES['attachfile']['name'];
$extd = pathinfo($pathd, PATHINFO_EXTENSION);
$based = pathinfo($pathd, PATHINFO_FILENAME);
if($based=="")
{
$attachfile='default.png';
}
else
{
$sqlfile=mysql_query("select id from purchaseorder_reg order by id desc limit 1");
while($rowfile=mysql_fetch_array($sqlfile))
{
$cmpnfile=$rowfile['id'];
}
$complainnofile1=$cmpnfile+1;

$complainnofile2="Supporting_Document".$complainnofile1;
$complainnofile3="_";
$complainnofileimg1=$complainnofile2.$complainnofile3;
$attachfile= $complainnofileimg1.date("YmdHis.").$extd;

}
move_uploaded_file($_FILES["attachfile"]["tmp_name"],"purchaseorderfiles/".$attachfile);


$subtotal=$_POST['subtotal'];
$subtotal=htmlspecialchars($subtotal,ENT_QUOTES);

$cgstvalue=$_POST['cgstvalue'];
$cgstvalue=htmlspecialchars($cgstvalue,ENT_QUOTES);

$sgstvalue=$_POST['sgstvalue'];
$sgstvalue=htmlspecialchars($sgstvalue,ENT_QUOTES);

$igstvalue=$_POST['igstvalue'];
$igstvalue=htmlspecialchars($igstvalue,ENT_QUOTES);

$totalcess=$_POST['totalcess'];
$totalcess=htmlspecialchars($totalcess,ENT_QUOTES);

$roundoff=$_POST['roundoff'];
$roundoff=htmlspecialchars($roundoff,ENT_QUOTES);

$totalrs=$_POST['totalrs'];
$totalrs=htmlspecialchars($totalrs,ENT_QUOTES);


// Table Row 1
require("connection.php");

$partid=$_POST['partname'];
$query="select * from supplierproduct where partnameid=$partid";
$result = mysqli_query($con, $query);
while($rw1 = mysqli_fetch_array($result))
{
$partname=$rw1['partname'];
$partname=htmlspecialchars($partname,ENT_QUOTES);
}
$partnameid=$_POST['partnameid'];
$partnameid=htmlspecialchars($partnameid,ENT_QUOTES);

$drawingno=$_POST['drawingno'];
$drawingno=htmlspecialchars($drawingno,ENT_QUOTES);

$remark=$_POST['remark'];
$remark=htmlspecialchars($remark,ENT_QUOTES);

$hsncode=$_POST['hsncode'];
$hsncode=htmlspecialchars($hsncode,ENT_QUOTES);

$reqqty=$_POST['reqqty'];
$reqqty=htmlspecialchars($reqqty,ENT_QUOTES);

$shortageby=$_POST['shortageby'];
$shortageby=htmlspecialchars($shortageby,ENT_QUOTES);

$poqty=$_POST['poqty'];
$poqty=htmlspecialchars($poqty,ENT_QUOTES);

$unit=$_POST['unit'];
$unit=htmlspecialchars($unit,ENT_QUOTES);

$deliverydate=$_POST['deliverydate'];
$deliverydate=htmlspecialchars($deliverydate,ENT_QUOTES);

$unitprice=$_POST['unitprice'];
$unitprice=htmlspecialchars($unitprice,ENT_QUOTES);

$discount=$_POST['discount'];
$discount=htmlspecialchars($discount,ENT_QUOTES);

$tax=$_POST['tax'];
$tax=htmlspecialchars($tax,ENT_QUOTES);

$cgstper=$_POST['cgstper'];
$cgstper=htmlspecialchars($cgstper,ENT_QUOTES);

$sgstper=$_POST['sgstper'];
$sgstper=htmlspecialchars($sgstper,ENT_QUOTES);

$igstper=$_POST['igstper'];
$igstper=htmlspecialchars($igstper,ENT_QUOTES);

$cesstype=$_POST['cesstype'];
$cesstype=htmlspecialchars($cesstype,ENT_QUOTES);

$cess_cgstper=$_POST['cess_cgstper'];
$cess_cgstper=htmlspecialchars($cess_cgstper,ENT_QUOTES);

$cess_sgstper=$_POST['cess_sgstper'];
$cess_sgstper=htmlspecialchars($cess_sgstper,ENT_QUOTES);

$cess_igstper=$_POST['cess_igstper'];
$cess_igstper=htmlspecialchars($cess_igstper,ENT_QUOTES);

$cessamt=$_POST['cessamt'];
$cessamt=htmlspecialchars($cessamt,ENT_QUOTES);

$totalprice=$_POST['totalprice'];
$totalprice=htmlspecialchars($totalprice,ENT_QUOTES);

$totalpr_wo_dis=$_POST['totalpr_wo_dis'];
$totalpr_wo_dis=htmlspecialchars($totalpr_wo_dis,ENT_QUOTES);

$cgstamt=$_POST['cgstamt'];
$cgstamt=htmlspecialchars($cgstamt,ENT_QUOTES);

$sgstamt=$_POST['sgstamt'];
$sgstamt=htmlspecialchars($sgstamt,ENT_QUOTES);

$igstamt=$_POST['igstamt'];
$igstamt=htmlspecialchars($igstamt,ENT_QUOTES);


// Table Row 2
$partid1=$_POST['partname1'];
$query1="select * from supplierproduct where partnameid=$partid1";
$result1 = mysqli_query($con, $query1);
while($rw2 = mysqli_fetch_array($result1))
{
  $partname1=$rw2['partname'];
  $partname1=htmlspecialchars($partname1,ENT_QUOTES);
}
$partnameid1=$_POST['partnameid1'];
$partnameid1=htmlspecialchars($partnameid1,ENT_QUOTES);

$drawingno1=$_POST['drawingno1'];
$drawingno1=htmlspecialchars($drawingno1,ENT_QUOTES);

$remark1=$_POST['remark1'];
$remark1=htmlspecialchars($remark1,ENT_QUOTES);

$hsncode1=$_POST['hsncode1'];
$hsncode1=htmlspecialchars($hsncode1,ENT_QUOTES);

$reqqty1=$_POST['reqqty1'];
$reqqty1=htmlspecialchars($reqqty1,ENT_QUOTES);

$shortageby1=$_POST['shortageby1'];
$shortageby1=htmlspecialchars($shortageby1,ENT_QUOTES);

$poqty1=$_POST['poqty1'];
$poqty1=htmlspecialchars($poqty1,ENT_QUOTES);

$unit1=$_POST['unit1'];
$unit1=htmlspecialchars($unit1,ENT_QUOTES);

$deliverydate1=$_POST['deliverydate1'];
$deliverydate1=htmlspecialchars($deliverydate1,ENT_QUOTES);

$unitprice1=$_POST['unitprice1'];
$unitprice1=htmlspecialchars($unitprice1,ENT_QUOTES);

$discount1=$_POST['discount1'];
$discount1=htmlspecialchars($discount1,ENT_QUOTES);

$tax1=$_POST['tax1'];
$tax1=htmlspecialchars($tax1,ENT_QUOTES);

$cgstper1=$_POST['cgstper1'];
$cgstper1=htmlspecialchars($cgstper1,ENT_QUOTES);

$sgstper1=$_POST['sgstper1'];
$sgstper1=htmlspecialchars($sgstper1,ENT_QUOTES);

$igstper1=$_POST['igstper1'];
$igstper1=htmlspecialchars($igstper1,ENT_QUOTES);

$cesstype1=$_POST['cesstype1'];
$cesstype1=htmlspecialchars($cesstype1,ENT_QUOTES);

$cess_cgstper1=$_POST['cess_cgstper1'];
$cess_cgstper1=htmlspecialchars($cess_cgstper1,ENT_QUOTES);

$cess_sgstper1=$_POST['cess_sgstper1'];
$cess_sgstper1=htmlspecialchars($cess_sgstper1,ENT_QUOTES);

$cess_igstper1=$_POST['cess_igstper1'];
$cess_igstper1=htmlspecialchars($cess_igstper1,ENT_QUOTES);

$cessamt1=$_POST['cessamt1'];
$cessamt1=htmlspecialchars($cessamt1,ENT_QUOTES);

$totalprice1=$_POST['totalprice1'];
$totalprice1=htmlspecialchars($totalprice1,ENT_QUOTES);

$totalpr_wo_dis1=$_POST['totalpr_wo_dis1'];
$totalpr_wo_dis1=htmlspecialchars($totalpr_wo_dis1,ENT_QUOTES);

$cgstamt1=$_POST['cgstamt1'];
$cgstamt1=htmlspecialchars($cgstamt1,ENT_QUOTES);

$sgstamt1=$_POST['sgstamt1'];
$sgstamt1=htmlspecialchars($sgstamt1,ENT_QUOTES);

$igstamt1=$_POST['igstamt1'];
$igstamt1=htmlspecialchars($igstamt1,ENT_QUOTES);


// Table Row 3
$partid2=$_POST['partname2'];
$query2="select * from supplierproduct where partnameid=$partid2";
$result2 = mysqli_query($con, $query2);
while($rw3 = mysqli_fetch_array($result2))
{
  $partname2=$rw3['partname'];
  $partname2=htmlspecialchars($partname2,ENT_QUOTES);
}
$partnameid2=$_POST['partnameid2'];
$partnameid2=htmlspecialchars($partnameid2,ENT_QUOTES);

$drawingno2=$_POST['drawingno2'];
$drawingno2=htmlspecialchars($drawingno2,ENT_QUOTES);

$remark2=$_POST['remark2'];
$remark2=htmlspecialchars($remark2,ENT_QUOTES);

$hsncode2=$_POST['hsncode2'];
$hsncode2=htmlspecialchars($hsncode2,ENT_QUOTES);

$reqqty2=$_POST['reqqty2'];
$reqqty2=htmlspecialchars($reqqty2,ENT_QUOTES);

$shortageby2=$_POST['shortageby2'];
$shortageby2=htmlspecialchars($shortageby2,ENT_QUOTES);

$poqty2=$_POST['poqty2'];
$poqty2=htmlspecialchars($poqty2,ENT_QUOTES);

$unit2=$_POST['unit2'];
$unit2=htmlspecialchars($unit2,ENT_QUOTES);

$deliverydate2=$_POST['deliverydate2'];
$deliverydate2=htmlspecialchars($deliverydate2,ENT_QUOTES);

$unitprice2=$_POST['unitprice2'];
$unitprice2=htmlspecialchars($unitprice2,ENT_QUOTES);

$discount2=$_POST['discount2'];
$discount2=htmlspecialchars($discount2,ENT_QUOTES);

$tax2=$_POST['tax2'];
$tax2=htmlspecialchars($tax2,ENT_QUOTES);

$cgstper2=$_POST['cgstper2'];
$cgstper2=htmlspecialchars($cgstper2,ENT_QUOTES);

$sgstper2=$_POST['sgstper2'];
$sgstper2=htmlspecialchars($sgstper2,ENT_QUOTES);

$igstper2=$_POST['igstper2'];
$igstper2=htmlspecialchars($igstper2,ENT_QUOTES);

$cesstype2=$_POST['cesstype2'];
$cesstype2=htmlspecialchars($cesstype2,ENT_QUOTES);

$cess_cgstper2=$_POST['cess_cgstper2'];
$cess_cgstper2=htmlspecialchars($cess_cgstper2,ENT_QUOTES);

$cess_sgstper2=$_POST['cess_sgstper2'];
$cess_sgstper2=htmlspecialchars($cess_sgstper2,ENT_QUOTES);

$cess_igstper2=$_POST['cess_igstper2'];
$cess_igstper2=htmlspecialchars($cess_igstper2,ENT_QUOTES);

$cessamt2=$_POST['cessamt2'];
$cessamt2=htmlspecialchars($cessamt2,ENT_QUOTES);

$totalprice2=$_POST['totalprice2'];
$totalprice2=htmlspecialchars($totalprice2,ENT_QUOTES);

$totalpr_wo_dis2=$_POST['totalpr_wo_dis2'];
$totalpr_wo_dis2=htmlspecialchars($totalpr_wo_dis2,ENT_QUOTES);

$cgstamt2=$_POST['cgstamt2'];
$cgstamt2=htmlspecialchars($cgstamt2,ENT_QUOTES);

$sgstamt2=$_POST['sgstamt2'];
$sgstamt2=htmlspecialchars($sgstamt2,ENT_QUOTES);

$igstamt2=$_POST['igstamt2'];
$igstamt2=htmlspecialchars($igstamt2,ENT_QUOTES);


// Table Row 4
$partid3=$_POST['partname3'];
$query4="select * from supplierproduct where partnameid=$partid3";
$result4 = mysqli_query($con, $query4);
while($rw4 = mysqli_fetch_array($result4))
{
$partname3=$rw4['partname'];
$partname3=htmlspecialchars($partname3,ENT_QUOTES);
}
$partnameid3=$_POST['partnameid3'];
$partnameid3=htmlspecialchars($partnameid3,ENT_QUOTES);

$drawingno3=$_POST['drawingno3'];
$drawingno3=htmlspecialchars($drawingno3,ENT_QUOTES);

$remark3=$_POST['remark3'];
$remark3=htmlspecialchars($remark3,ENT_QUOTES);

$hsncode3=$_POST['hsncode3'];
$hsncode3=htmlspecialchars($hsncode3,ENT_QUOTES);

$reqqty3=$_POST['reqqty3'];
$reqqty3=htmlspecialchars($reqqty3,ENT_QUOTES);

$shortageby3=$_POST['shortageby3'];
$shortageby3=htmlspecialchars($shortageby3,ENT_QUOTES);

$poqty3=$_POST['poqty3'];
$poqty3=htmlspecialchars($poqty3,ENT_QUOTES);

$unit3=$_POST['unit3'];
$unit3=htmlspecialchars($unit3,ENT_QUOTES);

$deliverydate3=$_POST['deliverydate3'];
$deliverydate3=htmlspecialchars($deliverydate3,ENT_QUOTES);

$unitprice3=$_POST['unitprice3'];
$unitprice3=htmlspecialchars($unitprice3,ENT_QUOTES);

$discount3=$_POST['discount3'];
$discount3=htmlspecialchars($discount3,ENT_QUOTES);

$tax3=$_POST['tax3'];
$tax3=htmlspecialchars($tax3,ENT_QUOTES);

$cgstper3=$_POST['cgstper3'];
$cgstper3=htmlspecialchars($cgstper3,ENT_QUOTES);

$sgstper3=$_POST['sgstper3'];
$sgstper3=htmlspecialchars($sgstper3,ENT_QUOTES);

$igstper3=$_POST['igstper3'];
$igstper3=htmlspecialchars($igstper3,ENT_QUOTES);

$cesstype3=$_POST['cesstype3'];
$cesstype3=htmlspecialchars($cesstype3,ENT_QUOTES);

$cess_cgstper3=$_POST['cess_cgstper3'];
$cess_cgstper3=htmlspecialchars($cess_cgstper3,ENT_QUOTES);

$cess_sgstper3=$_POST['cess_sgstper3'];
$cess_sgstper3=htmlspecialchars($cess_sgstper3,ENT_QUOTES);

$cess_igstper3=$_POST['cess_igstper3'];
$cess_igstper3=htmlspecialchars($cess_igstper3,ENT_QUOTES);

$cessamt3=$_POST['cessamt3'];
$cessamt3=htmlspecialchars($cessamt3,ENT_QUOTES);

$totalprice3=$_POST['totalprice3'];
$totalprice3=htmlspecialchars($totalprice3,ENT_QUOTES);

$totalpr_wo_dis3=$_POST['totalpr_wo_dis3'];
$totalpr_wo_dis3=htmlspecialchars($totalpr_wo_dis3,ENT_QUOTES);

$cgstamt3=$_POST['cgstamt3'];
$cgstamt3=htmlspecialchars($cgstamt3,ENT_QUOTES);

$sgstamt3=$_POST['sgstamt3'];
$sgstamt3=htmlspecialchars($sgstamt3,ENT_QUOTES);

$igstamt3=$_POST['igstamt3'];
$igstamt3=htmlspecialchars($igstamt3,ENT_QUOTES);


// Table Row 5
 $partid4=$_POST['partname4'];
 $query="select * from supplierproduct where partnameid=$partid4";
 $result = mysqli_query($con, $query);
  while($rw1 = mysqli_fetch_array($result))
  {
    $partname4=$rw1['partname'];
    $partname4=htmlspecialchars($partname4,ENT_QUOTES);
  }
$partnameid4=$_POST['partnameid4'];
$partnameid4=htmlspecialchars($partnameid4,ENT_QUOTES);

$drawingno4=$_POST['drawingno4'];
$drawingno4=htmlspecialchars($drawingno4,ENT_QUOTES);

$remark4=$_POST['remark4'];
$remark4=htmlspecialchars($remark4,ENT_QUOTES);

$hsncode4=$_POST['hsncode4'];
$hsncode4=htmlspecialchars($hsncode4,ENT_QUOTES);

$reqqty4=$_POST['reqqty4'];
$reqqty4=htmlspecialchars($reqqty4,ENT_QUOTES);

$shortageby4=$_POST['shortageby4'];
$shortageby4=htmlspecialchars($shortageby4,ENT_QUOTES);

$poqty4=$_POST['poqty4'];
$poqty4=htmlspecialchars($poqty4,ENT_QUOTES);

$unit4=$_POST['unit4'];
$unit4=htmlspecialchars($unit4,ENT_QUOTES);

$deliverydate4=$_POST['deliverydate4'];
$deliverydate4=htmlspecialchars($deliverydate4,ENT_QUOTES);

$unitprice4=$_POST['unitprice4'];
$unitprice4=htmlspecialchars($unitprice4,ENT_QUOTES);

$discount4=$_POST['discount4'];
$discount4=htmlspecialchars($discount4,ENT_QUOTES);

$tax4=$_POST['tax4'];
$tax4=htmlspecialchars($tax4,ENT_QUOTES);

$cgstper4=$_POST['cgstper4'];
$cgstper4=htmlspecialchars($cgstper4,ENT_QUOTES);

$sgstper4=$_POST['sgstper4'];
$sgstper4=htmlspecialchars($sgstper4,ENT_QUOTES);

$igstper4=$_POST['igstper4'];
$igstper4=htmlspecialchars($igstper4,ENT_QUOTES);

$cesstype4=$_POST['cesstype4'];
$cesstype4=htmlspecialchars($cesstype4,ENT_QUOTES);

$cess_cgstper4=$_POST['cess_cgstper4'];
$cess_cgstper4=htmlspecialchars($cess_cgstper4,ENT_QUOTES);

$cess_sgstper4=$_POST['cess_sgstper4'];
$cess_sgstper4=htmlspecialchars($cess_sgstper4,ENT_QUOTES);

$cess_igstper4=$_POST['cess_igstper4'];
$cess_igstper4=htmlspecialchars($cess_igstper4,ENT_QUOTES);

$cessamt4=$_POST['cessamt4'];
$cessamt4=htmlspecialchars($cessamt4,ENT_QUOTES);

$totalprice4=$_POST['totalprice4'];
$totalprice4=htmlspecialchars($totalprice4,ENT_QUOTES);

$totalpr_wo_dis4=$_POST['totalpr_wo_dis4'];
$totalpr_wo_dis4=htmlspecialchars($totalpr_wo_dis4,ENT_QUOTES);

$cgstamt4=$_POST['cgstamt4'];
$cgstamt4=htmlspecialchars($cgstamt4,ENT_QUOTES);

$sgstamt4=$_POST['sgstamt4'];
$sgstamt4=htmlspecialchars($sgstamt4,ENT_QUOTES);

$igstamt4=$_POST['igstamt4'];
$igstamt4=htmlspecialchars($igstamt4,ENT_QUOTES);


// Table Row 6
 $partid5=$_POST['partname5'];
 $query5="select * from supplierproduct where partnameid=$partid5";
 $result5 = mysqli_query($con, $query5);
  while($rw5 = mysqli_fetch_array($result5))
  {
    $partname5=$rw5['partname'];
    $partname5=htmlspecialchars($partname5,ENT_QUOTES);
  }
$partnameid5=$_POST['partnameid5'];
$partnameid5=htmlspecialchars($partnameid5,ENT_QUOTES);

$drawingno5=$_POST['drawingno5'];
$drawingno5=htmlspecialchars($drawingno5,ENT_QUOTES);

$remark5=$_POST['remark5'];
$remark5=htmlspecialchars($remark5,ENT_QUOTES);

$hsncode5=$_POST['hsncode5'];
$hsncode5=htmlspecialchars($hsncode5,ENT_QUOTES);

$reqqty5=$_POST['reqqty5'];
$reqqty5=htmlspecialchars($reqqty5,ENT_QUOTES);

$shortageby5=$_POST['shortageby5'];
$shortageby5=htmlspecialchars($shortageby5,ENT_QUOTES);

$poqty5=$_POST['poqty5'];
$poqty5=htmlspecialchars($poqty5,ENT_QUOTES);

$unit5=$_POST['unit5'];
$unit5=htmlspecialchars($unit5,ENT_QUOTES);

$deliverydate5=$_POST['deliverydate5'];
$deliverydate5=htmlspecialchars($deliverydate5,ENT_QUOTES);

$unitprice5=$_POST['unitprice5'];
$unitprice5=htmlspecialchars($unitprice5,ENT_QUOTES);

$discount5=$_POST['discount5'];
$discount5=htmlspecialchars($discount5,ENT_QUOTES);

$tax5=$_POST['tax5'];
$tax5=htmlspecialchars($tax5,ENT_QUOTES);

$cgstper5=$_POST['cgstper5'];
$cgstper5=htmlspecialchars($cgstper5,ENT_QUOTES);

$sgstper5=$_POST['sgstper5'];
$sgstper5=htmlspecialchars($sgstper5,ENT_QUOTES);

$igstper5=$_POST['igstper5'];
$igstper5=htmlspecialchars($igstper5,ENT_QUOTES);

$cesstype5=$_POST['cesstype5'];
$cesstype5=htmlspecialchars($cesstype5,ENT_QUOTES);

$cess_cgstper5=$_POST['cess_cgstper5'];
$cess_cgstper5=htmlspecialchars($cess_cgstper5,ENT_QUOTES);

$cess_sgstper5=$_POST['cess_sgstper5'];
$cess_sgstper5=htmlspecialchars($cess_sgstper5,ENT_QUOTES);

$cess_igstper5=$_POST['cess_igstper5'];
$cess_igstper5=htmlspecialchars($cess_igstper5,ENT_QUOTES);

$cessamt5=$_POST['cessamt5'];
$cessamt5=htmlspecialchars($cessamt5,ENT_QUOTES);

$totalprice5=$_POST['totalprice5'];
$totalprice5=htmlspecialchars($totalprice5,ENT_QUOTES);

$totalpr_wo_dis5=$_POST['totalpr_wo_dis5'];
$totalpr_wo_dis5=htmlspecialchars($totalpr_wo_dis5,ENT_QUOTES);

$cgstamt5=$_POST['cgstamt5'];
$cgstamt5=htmlspecialchars($cgstamt5,ENT_QUOTES);

$sgstamt5=$_POST['sgstamt5'];
$sgstamt5=htmlspecialchars($sgstamt5,ENT_QUOTES);

$igstamt5=$_POST['igstamt5'];
$igstamt5=htmlspecialchars($igstamt5,ENT_QUOTES);

// Table Row 7
 $partid6=$_POST['partname6'];
 $query6="select * from supplierproduct where partnameid=$partid6";
 $result6 = mysqli_query($con, $query6);
  while($rw6 = mysqli_fetch_array($result6))
  {
    $partname6=$rw6['partname'];
    $partname6=htmlspecialchars($partname6,ENT_QUOTES);
  }
$partnameid6=$_POST['partnameid6'];
$partnameid6=htmlspecialchars($partnameid6,ENT_QUOTES);

$drawingno6=$_POST['drawingno6'];
$drawingno6=htmlspecialchars($drawingno6,ENT_QUOTES);

$remark6=$_POST['remark6'];
$remark6=htmlspecialchars($remark6,ENT_QUOTES);

$hsncode6=$_POST['hsncode6'];
$hsncode6=htmlspecialchars($hsncode6,ENT_QUOTES);

$reqqty6=$_POST['reqqty6'];
$reqqty6=htmlspecialchars($reqqty6,ENT_QUOTES);

$shortageby6=$_POST['shortageby6'];
$shortageby6=htmlspecialchars($shortageby6,ENT_QUOTES);

$poqty6=$_POST['poqty6'];
$poqty6=htmlspecialchars($poqty6,ENT_QUOTES);

$unit6=$_POST['unit6'];
$unit6=htmlspecialchars($unit6,ENT_QUOTES);

$deliverydate6=$_POST['deliverydate6'];
$deliverydate6=htmlspecialchars($deliverydate6,ENT_QUOTES);

$unitprice6=$_POST['unitprice6'];
$unitprice6=htmlspecialchars($unitprice6,ENT_QUOTES);

$discount6=$_POST['discount6'];
$discount6=htmlspecialchars($discount6,ENT_QUOTES);

$tax6=$_POST['tax6'];
$tax6=htmlspecialchars($tax6,ENT_QUOTES);

$cgstper6=$_POST['cgstper6'];
$cgstper6=htmlspecialchars($cgstper6,ENT_QUOTES);

$sgstper6=$_POST['sgstper6'];
$sgstper6=htmlspecialchars($sgstper6,ENT_QUOTES);

$igstper6=$_POST['igstper6'];
$igstper6=htmlspecialchars($igstper6,ENT_QUOTES);

$cesstype6=$_POST['cesstype6'];
$cesstype6=htmlspecialchars($cesstype6,ENT_QUOTES);

$cess_cgstper6=$_POST['cess_cgstper6'];
$cess_cgstper6=htmlspecialchars($cess_cgstper6,ENT_QUOTES);

$cess_sgstper6=$_POST['cess_sgstper6'];
$cess_sgstper6=htmlspecialchars($cess_sgstper6,ENT_QUOTES);

$cess_igstper6=$_POST['cess_igstper6'];
$cess_igstper6=htmlspecialchars($cess_igstper6,ENT_QUOTES);

$cessamt6=$_POST['cessamt6'];
$cessamt6=htmlspecialchars($cessamt6,ENT_QUOTES);

$totalprice6=$_POST['totalprice6'];
$totalprice6=htmlspecialchars($totalprice6,ENT_QUOTES);

$totalpr_wo_dis6=$_POST['totalpr_wo_dis6'];
$totalpr_wo_dis6=htmlspecialchars($totalpr_wo_dis6,ENT_QUOTES);

$cgstamt6=$_POST['cgstamt6'];
$cgstamt6=htmlspecialchars($cgstamt6,ENT_QUOTES);

$sgstamt6=$_POST['sgstamt6'];
$sgstamt6=htmlspecialchars($sgstamt6,ENT_QUOTES);

$igstamt6=$_POST['igstamt6'];
$igstamt6=htmlspecialchars($igstamt6,ENT_QUOTES);

// Table Row 8
 $partid7=$_POST['partname7'];
 $query7="select * from supplierproduct where partnameid=$partid7";
 $result7 = mysqli_query($con, $query7);
  while($rw7 = mysqli_fetch_array($result7))
  {
    $partname7=$rw7['partname'];
    $partname7=htmlspecialchars($partname7,ENT_QUOTES);
  }
$partnameid7=$_POST['partnameid7'];
$partnameid7=htmlspecialchars($partnameid7,ENT_QUOTES);

$drawingno7=$_POST['drawingno7'];
$drawingno7=htmlspecialchars($drawingno7,ENT_QUOTES);

$remark7=$_POST['remark7'];
$remark7=htmlspecialchars($remark7,ENT_QUOTES);

$hsncode7=$_POST['hsncode7'];
$hsncode7=htmlspecialchars($hsncode7,ENT_QUOTES);

$reqqty7=$_POST['reqqty7'];
$reqqty7=htmlspecialchars($reqqty7,ENT_QUOTES);

$shortageby7=$_POST['shortageby7'];
$shortageby7=htmlspecialchars($shortageby7,ENT_QUOTES);

$poqty7=$_POST['poqty7'];
$poqty7=htmlspecialchars($poqty7,ENT_QUOTES);

$unit7=$_POST['unit7'];
$unit7=htmlspecialchars($unit7,ENT_QUOTES);

$deliverydate7=$_POST['deliverydate7'];
$deliverydate7=htmlspecialchars($deliverydate7,ENT_QUOTES);

$unitprice7=$_POST['unitprice7'];
$unitprice7=htmlspecialchars($unitprice7,ENT_QUOTES);

$discount7=$_POST['discount7'];
$discount7=htmlspecialchars($discount7,ENT_QUOTES);

$tax7=$_POST['tax7'];
$tax7=htmlspecialchars($tax7,ENT_QUOTES);

$cgstper7=$_POST['cgstper7'];
$cgstper7=htmlspecialchars($cgstper7,ENT_QUOTES);

$sgstper7=$_POST['sgstper7'];
$sgstper7=htmlspecialchars($sgstper7,ENT_QUOTES);

$igstper7=$_POST['igstper7'];
$igstper7=htmlspecialchars($igstper7,ENT_QUOTES);

$cesstype7=$_POST['cesstype7'];
$cesstype7=htmlspecialchars($cesstype7,ENT_QUOTES);

$cess_cgstper7=$_POST['cess_cgstper7'];
$cess_cgstper7=htmlspecialchars($cess_cgstper7,ENT_QUOTES);

$cess_sgstper7=$_POST['cess_sgstper7'];
$cess_sgstper7=htmlspecialchars($cess_sgstper7,ENT_QUOTES);

$cess_igstper7=$_POST['cess_igstper7'];
$cess_igstper7=htmlspecialchars($cess_igstper7,ENT_QUOTES);

$cessamt7=$_POST['cessamt7'];
$cessamt7=htmlspecialchars($cessamt7,ENT_QUOTES);

$totalprice7=$_POST['totalprice7'];
$totalprice7=htmlspecialchars($totalprice7,ENT_QUOTES);

$totalpr_wo_dis7=$_POST['totalpr_wo_dis7'];
$totalpr_wo_dis7=htmlspecialchars($totalpr_wo_dis7,ENT_QUOTES);

$cgstamt7=$_POST['cgstamt7'];
$cgstamt7=htmlspecialchars($cgstamt7,ENT_QUOTES);

$sgstamt7=$_POST['sgstamt7'];
$sgstamt7=htmlspecialchars($sgstamt7,ENT_QUOTES);

$igstamt7=$_POST['igstamt7'];
$igstamt7=htmlspecialchars($igstamt7,ENT_QUOTES);
// Table Row 9
 $partid8=$_POST['partname8'];
 $query8="select * from supplierproduct where partnameid=$partid8";
 $result8 = mysqli_query($con, $query8);
  while($rw8 = mysqli_fetch_array($result8))
  {
    $partname8=$rw8['partname'];
    $partname8=htmlspecialchars($partname8,ENT_QUOTES);
  }
$partnameid8=$_POST['partnameid8'];
$partnameid8=htmlspecialchars($partnameid8,ENT_QUOTES);

$drawingno8=$_POST['drawingno8'];
$drawingno8=htmlspecialchars($drawingno8,ENT_QUOTES);

$remark8=$_POST['remark8'];
$remark8=htmlspecialchars($remark8,ENT_QUOTES);

$hsncode8=$_POST['hsncode8'];
$hsncode8=htmlspecialchars($hsncode8,ENT_QUOTES);

$reqqty8=$_POST['reqqty8'];
$reqqty8=htmlspecialchars($reqqty8,ENT_QUOTES);

$shortageby8=$_POST['shortageby8'];
$shortageby8=htmlspecialchars($shortageby8,ENT_QUOTES);

$poqty8=$_POST['poqty8'];
$poqty8=htmlspecialchars($poqty8,ENT_QUOTES);

$unit8=$_POST['unit8'];
$unit8=htmlspecialchars($unit8,ENT_QUOTES);

$deliverydate8=$_POST['deliverydate8'];
$deliverydate8=htmlspecialchars($deliverydate8,ENT_QUOTES);

$unitprice8=$_POST['unitprice8'];
$unitprice8=htmlspecialchars($unitprice8,ENT_QUOTES);

$discount8=$_POST['discount8'];
$discount8=htmlspecialchars($discount8,ENT_QUOTES);

$tax8=$_POST['tax8'];
$tax8=htmlspecialchars($tax8,ENT_QUOTES);

$cgstper8=$_POST['cgstper8'];
$cgstper8=htmlspecialchars($cgstper8,ENT_QUOTES);

$sgstper8=$_POST['sgstper8'];
$sgstper8=htmlspecialchars($sgstper8,ENT_QUOTES);

$igstper8=$_POST['igstper8'];
$igstper8=htmlspecialchars($igstper8,ENT_QUOTES);

$cesstype8=$_POST['cesstype8'];
$cesstype8=htmlspecialchars($cesstype8,ENT_QUOTES);

$cess_cgstper8=$_POST['cess_cgstper8'];
$cess_cgstper8=htmlspecialchars($cess_cgstper8,ENT_QUOTES);

$cess_sgstper8=$_POST['cess_sgstper8'];
$cess_sgstper8=htmlspecialchars($cess_sgstper8,ENT_QUOTES);

$cess_igstper8=$_POST['cess_igstper8'];
$cess_igstper8=htmlspecialchars($cess_igstper8,ENT_QUOTES);

$cessamt8=$_POST['cessamt8'];
$cessamt8=htmlspecialchars($cessamt8,ENT_QUOTES);

$totalprice8=$_POST['totalprice8'];
$totalprice8=htmlspecialchars($totalprice8,ENT_QUOTES);

$totalpr_wo_dis8=$_POST['totalpr_wo_dis8'];
$totalpr_wo_dis8=htmlspecialchars($totalpr_wo_dis8,ENT_QUOTES);

$cgstamt8=$_POST['cgstamt8'];
$cgstamt8=htmlspecialchars($cgstamt8,ENT_QUOTES);

$sgstamt8=$_POST['sgstamt8'];
$sgstamt8=htmlspecialchars($sgstamt8,ENT_QUOTES);

$igstamt8=$_POST['igstamt8'];
$igstamt8=htmlspecialchars($igstamt8,ENT_QUOTES);

// Table Row 10
 $partid9=$_POST['partname9'];
 $query9="select * from supplierproduct where partnameid=$partid9";
 $result9 = mysqli_query($con, $query9);
  while($rw9 = mysqli_fetch_array($result9))
  {
    $partname9=$rw9['partname'];
    $partname9=htmlspecialchars($partname9,ENT_QUOTES);
  }
$partnameid9=$_POST['partnameid9'];
$partnameid9=htmlspecialchars($partnameid9,ENT_QUOTES);

$drawingno9=$_POST['drawingno9'];
$drawingno9=htmlspecialchars($drawingno9,ENT_QUOTES);

$remark9=$_POST['remark9'];
$remark9=htmlspecialchars($remark9,ENT_QUOTES);

$hsncode9=$_POST['hsncode9'];
$hsncode9=htmlspecialchars($hsncode9,ENT_QUOTES);

$reqqty9=$_POST['reqqty9'];
$reqqty9=htmlspecialchars($reqqty9,ENT_QUOTES);

$shortageby9=$_POST['shortageby9'];
$shortageby9=htmlspecialchars($shortageby9,ENT_QUOTES);

$poqty9=$_POST['poqty9'];
$poqty9=htmlspecialchars($poqty9,ENT_QUOTES);

$unit9=$_POST['unit9'];
$unit9=htmlspecialchars($unit9,ENT_QUOTES);

$deliverydate9=$_POST['deliverydate9'];
$deliverydate9=htmlspecialchars($deliverydate9,ENT_QUOTES);

$unitprice9=$_POST['unitprice9'];
$unitprice9=htmlspecialchars($unitprice9,ENT_QUOTES);

$discount9=$_POST['discount9'];
$discount9=htmlspecialchars($discount9,ENT_QUOTES);

$tax9=$_POST['tax9'];
$tax9=htmlspecialchars($tax9,ENT_QUOTES);

$cgstper9=$_POST['cgstper9'];
$cgstper9=htmlspecialchars($cgstper9,ENT_QUOTES);

$sgstper9=$_POST['sgstper9'];
$sgstper9=htmlspecialchars($sgstper9,ENT_QUOTES);

$igstper9=$_POST['igstper9'];
$igstper9=htmlspecialchars($igstper9,ENT_QUOTES);

$cesstype9=$_POST['cesstype9'];
$cesstype9=htmlspecialchars($cesstype9,ENT_QUOTES);

$cess_cgstper9=$_POST['cess_cgstper9'];
$cess_cgstper9=htmlspecialchars($cess_cgstper9,ENT_QUOTES);

$cess_sgstper9=$_POST['cess_sgstper9'];
$cess_sgstper9=htmlspecialchars($cess_sgstper9,ENT_QUOTES);

$cess_igstper9=$_POST['cess_igstper9'];
$cess_igstper9=htmlspecialchars($cess_igstper9,ENT_QUOTES);

$cessamt9=$_POST['cessamt9'];
$cessamt9=htmlspecialchars($cessamt9,ENT_QUOTES);

$totalprice9=$_POST['totalprice9'];
$totalprice9=htmlspecialchars($totalprice9,ENT_QUOTES);

$totalpr_wo_dis9=$_POST['totalpr_wo_dis9'];
$totalpr_wo_dis9=htmlspecialchars($totalpr_wo_dis9,ENT_QUOTES);

$cgstamt9=$_POST['cgstamt9'];
$cgstamt9=htmlspecialchars($cgstamt9,ENT_QUOTES);

$sgstamt9=$_POST['sgstamt9'];
$sgstamt9=htmlspecialchars($sgstamt9,ENT_QUOTES);

$igstamt9=$_POST['igstamt9'];
$igstamt9=htmlspecialchars($igstamt9,ENT_QUOTES);

//table row 10 end


$sql=mysql_query("insert into purchaseorder_reg(pono,podate,suppliername,supplierid,sameasbill,vendorcode,paymentterm,deliverymode,freight,partname,partnameid,drawingno,remark,hsncode,reqqty,shortageby,poqty,unit,deliverydate,unitprice,discount,tax,cgstper,sgstper,igstper,cesstype,cess_cgstper,cess_sgstper,cess_igstper,cessamt,totalprice,totalpr_wo_dis,cgstamt,sgstamt,igstamt,ssid,notes,termsandcond,attachfile,subtotal,cgstvalue,sgstvalue,igstvalue,totalcess,roundoff,totalrs,reg_by,reg_dept,reg_id,reg_date,orderstatus)values('$pono','$podate','$suppliername','$supplierid','$sameasbill','$vendorcode','$paymentterm','$deliverymode','$freight','$partname','$partnameid','$drawingno','$remark','$hsncode','$reqqty','$shortageby','$poqty','$unit','$deliverydate','$unitprice','$discount','$tax','$cgstper','$sgstper','$igstper','$cesstype','$cess_cgstper','$cess_sgstper','$cess_igstper','$cessamt','$totalprice','$totalpr_wo_dis','$cgstamt','$sgstamt','$igstamt','$ssid','$notes','$termsandcond','$attachfile','$subtotal','$cgstvalue','$sgstvalue','$igstvalue','$totalcess','$roundoff','$totalrs','$name','$department','$uid','$reg_date','Open')");

if($partname1!=""){
$sql1=mysql_query("insert into purchaseorder_reg(pono,podate,suppliername,supplierid,sameasbill,vendorcode,paymentterm,deliverymode,freight,partname,partnameid,drawingno,remark,hsncode,reqqty,shortageby,poqty,unit,deliverydate,unitprice,discount,tax,cgstper,sgstper,igstper,cesstype,cess_cgstper,cess_sgstper,cess_igstper,cessamt,totalprice,totalpr_wo_dis,cgstamt,sgstamt,igstamt,ssid,notes,termsandcond,attachfile,subtotal,cgstvalue,sgstvalue,igstvalue,totalcess,roundoff,totalrs,reg_by,reg_dept,reg_id,reg_date,orderstatus)values('$pono','$podate','$suppliername','$supplierid','$sameasbill','$vendorcode','$paymentterm','$deliverymode','$freight','$partname1','$partnameid1','$drawingno1','$remark1','$hsncode1','$reqqty1','$shortageby1','$poqty1','$unit1','$deliverydate1','$unitprice1','$discount1','$tax1','$cgstper1','$sgstper1','$igstper1','$cesstype1','$cess_cgstper1','$cess_sgstper1','$cess_igstper1','$cessamt1','$totalprice1','$totalpr_wo_dis1','$cgstamt1','$sgstamt1','$igstamt1','$ssid','$notes','$termsandcond','$attachfile','$subtotal','$cgstvalue','$sgstvalue','$igstvalue','$totalcess','$roundoff','$totalrs','$name','$department','$uid','$reg_date','Open')");
}
if($partname2!=""){
$sql2=mysql_query("insert into purchaseorder_reg(pono,podate,suppliername,supplierid,sameasbill,vendorcode,paymentterm,deliverymode,freight,partname,partnameid,drawingno,remark,hsncode,reqqty,shortageby,poqty,unit,deliverydate,unitprice,discount,tax,cgstper,sgstper,igstper,cesstype,cess_cgstper,cess_sgstper,cess_igstper,cessamt,totalprice,totalpr_wo_dis,cgstamt,sgstamt,igstamt,ssid,notes,termsandcond,attachfile,subtotal,cgstvalue,sgstvalue,igstvalue,totalcess,roundoff,totalrs,reg_by,reg_dept,reg_id,reg_date,orderstatus)values('$pono','$podate','$suppliername','$supplierid','$sameasbill','$vendorcode','$paymentterm','$deliverymode','$freight','$partname2','$partnameid2','$drawingno2','$remark2','$hsncode2','$reqqty2','$shortageby2','$poqty2','$unit2','$deliverydate2','$unitprice2','$discount2','$tax2','$cgstper2','$sgstper2','$igstper2','$cesstype2','$cess_cgstper2','$cess_sgstper2','$cess_igstper2','$cessamt2','$totalprice2','$totalpr_wo_dis2','$cgstamt2','$sgstamt2','$igstamt2','$ssid','$notes','$termsandcond','$attachfile','$subtotal','$cgstvalue','$sgstvalue','$igstvalue','$totalcess','$roundoff','$totalrs','$name','$department','$uid','$reg_date','Open')");
}
if($partname3!=""){
$sql3=mysql_query("insert into purchaseorder_reg(pono,podate,suppliername,supplierid,sameasbill,vendorcode,paymentterm,deliverymode,freight,partname,partnameid,drawingno,remark,hsncode,reqqty,shortageby,poqty,unit,deliverydate,unitprice,discount,tax,cgstper,sgstper,igstper,cesstype,cess_cgstper,cess_sgstper,cess_igstper,cessamt,totalprice,totalpr_wo_dis,cgstamt,sgstamt,igstamt,ssid,notes,termsandcond,attachfile,subtotal,cgstvalue,sgstvalue,igstvalue,totalcess,roundoff,totalrs,reg_by,reg_dept,reg_id,reg_date,orderstatus)values('$pono','$podate','$suppliername','$supplierid','$sameasbill','$vendorcode','$paymentterm','$deliverymode','$freight','$partname3','$partnameid3','$drawingno3','$remark3','$hsncode3','$reqqty3','$shortageby3','$poqty3','$unit3','$deliverydate3','$unitprice3','$discount3','$tax3','$cgstper3','$sgstper3','$igstper3','$cesstype3','$cess_cgstper3','$cess_sgstper3','$cess_igstper3','$cessamt3','$totalprice3','$totalpr_wo_dis3','$cgstamt3','$sgstamt3','$igstamt3','$ssid','$notes','$termsandcond','$attachfile','$subtotal','$cgstvalue','$sgstvalue','$igstvalue','$totalcess','$roundoff','$totalrs','$name','$department','$uid','$reg_date','Open')");
}
if($partname4!=""){
$sql4=mysql_query("insert into purchaseorder_reg(pono,podate,suppliername,supplierid,sameasbill,vendorcode,paymentterm,deliverymode,freight,partname,partnameid,drawingno,remark,hsncode,reqqty,shortageby,poqty,unit,deliverydate,unitprice,discount,tax,cgstper,sgstper,igstper,cesstype,cess_cgstper,cess_sgstper,cess_igstper,cessamt,totalprice,totalpr_wo_dis,cgstamt,sgstamt,igstamt,ssid,notes,termsandcond,attachfile,subtotal,cgstvalue,sgstvalue,igstvalue,totalcess,roundoff,totalrs,reg_by,reg_dept,reg_id,reg_date,orderstatus)values('$pono','$podate','$suppliername','$supplierid','$sameasbill','$vendorcode','$paymentterm','$deliverymode','$freight','$partname4','$partnameid4','$drawingno4','$remark4','$hsncode4','$reqqty4','$shortageby4','$poqty4','$unit4','$deliverydate4','$unitprice4','$discount4','$tax4','$cgstper4','$sgstper4','$igstper4','$cesstype4','$cess_cgstper4','$cess_sgstper4','$cess_igstper4','$cessamt4','$totalprice4','$totalpr_wo_dis4','$cgstamt4','$sgstamt4','$igstamt4','$ssid','$notes','$termsandcond','$attachfile','$subtotal','$cgstvalue','$sgstvalue','$igstvalue','$totalcess','$roundoff','$totalrs','$name','$department','$uid','$reg_date','Open')");
}

if($partname5!=""){
$sql5=mysql_query("insert into purchaseorder_reg(pono,podate,suppliername,supplierid,sameasbill,vendorcode,paymentterm,deliverymode,freight,partname,partnameid,drawingno,remark,hsncode,reqqty,shortageby,poqty,unit,deliverydate,unitprice,discount,tax,cgstper,sgstper,igstper,cesstype,cess_cgstper,cess_sgstper,cess_igstper,cessamt,totalprice,totalpr_wo_dis,cgstamt,sgstamt,igstamt,ssid,notes,termsandcond,attachfile,subtotal,cgstvalue,sgstvalue,igstvalue,totalcess,roundoff,totalrs,reg_by,reg_dept,reg_id,reg_date,orderstatus)values('$pono','$podate','$suppliername','$supplierid','$sameasbill','$vendorcode','$paymentterm','$deliverymode','$freight','$partname5','$partnameid5','$drawingno5','$remark5','$hsncode5','$reqqty5','$shortageby5','$poqty5','$unit5','$deliverydate5','$unitprice5','$discount5','$tax5','$cgstper5','$sgstper5','$igstper5','$cesstype5','$cess_cgstper5','$cess_sgstper5','$cess_igstper5','$cessamt5','$totalprice5','$totalpr_wo_dis5','$cgstamt5','$sgstamt5','$igstamt5','$ssid','$notes','$termsandcond','$attachfile','$subtotal','$cgstvalue','$sgstvalue','$igstvalue','$totalcess','$roundoff','$totalrs','$name','$department','$uid','$reg_date','Open')");
}

if($partname6!=""){
$sql6=mysql_query("insert into purchaseorder_reg(pono,podate,suppliername,supplierid,sameasbill,vendorcode,paymentterm,deliverymode,freight,partname,partnameid,drawingno,remark,hsncode,reqqty,shortageby,poqty,unit,deliverydate,unitprice,discount,tax,cgstper,sgstper,igstper,cesstype,cess_cgstper,cess_sgstper,cess_igstper,cessamt,totalprice,totalpr_wo_dis,cgstamt,sgstamt,igstamt,ssid,notes,termsandcond,attachfile,subtotal,cgstvalue,sgstvalue,igstvalue,totalcess,roundoff,totalrs,reg_by,reg_dept,reg_id,reg_date,orderstatus)values('$pono','$podate','$suppliername','$supplierid','$sameasbill','$vendorcode','$paymentterm','$deliverymode','$freight','$partname6','$partnameid6','$drawingno6','$remark6','$hsncode6','$reqqty6','$shortageby6','$poqty6','$unit6','$deliverydate6','$unitprice6','$discount6','$tax6','$cgstper6','$sgstper6','$igstper6','$cesstype6','$cess_cgstper6','$cess_sgstper6','$cess_igstper6','$cessamt6','$totalprice6','$totalpr_wo_dis6','$cgstamt6','$sgstamt6','$igstamt6','$ssid','$notes','$termsandcond','$attachfile','$subtotal','$cgstvalue','$sgstvalue','$igstvalue','$totalcess','$roundoff','$totalrs','$name','$department','$uid','$reg_date','Open')");
}

if($partname7!=""){
$sql7=mysql_query("insert into purchaseorder_reg(pono,podate,suppliername,supplierid,sameasbill,vendorcode,paymentterm,deliverymode,freight,partname,partnameid,drawingno,remark,hsncode,reqqty,shortageby,poqty,unit,deliverydate,unitprice,discount,tax,cgstper,sgstper,igstper,cesstype,cess_cgstper,cess_sgstper,cess_igstper,cessamt,totalprice,totalpr_wo_dis,cgstamt,sgstamt,igstamt,ssid,notes,termsandcond,attachfile,subtotal,cgstvalue,sgstvalue,igstvalue,totalcess,roundoff,totalrs,reg_by,reg_dept,reg_id,reg_date,orderstatus)values('$pono','$podate','$suppliername','$supplierid','$sameasbill','$vendorcode','$paymentterm','$deliverymode','$freight','$partname7','$partnameid7','$drawingno7','$remark7','$hsncode7','$reqqty7','$shortageby7','$poqty7','$unit7','$deliverydate7','$unitprice7','$discount7','$tax7','$cgstper7','$sgstper7','$igstper7','$cesstype7','$cess_cgstper7','$cess_sgstper7','$cess_igstper7','$cessamt7','$totalprice7','$totalpr_wo_dis7','$cgstamt7','$sgstamt7','$igstamt7','$ssid','$notes','$termsandcond','$attachfile','$subtotal','$cgstvalue','$sgstvalue','$igstvalue','$totalcess','$roundoff','$totalrs','$name','$department','$uid','$reg_date','Open')");
}

if($partname8!=""){
$sql8=mysql_query("insert into purchaseorder_reg(pono,podate,suppliername,supplierid,sameasbill,vendorcode,paymentterm,deliverymode,freight,partname,partnameid,drawingno,remark,hsncode,reqqty,shortageby,poqty,unit,deliverydate,unitprice,discount,tax,cgstper,sgstper,igstper,cesstype,cess_cgstper,cess_sgstper,cess_igstper,cessamt,totalprice,totalpr_wo_dis,cgstamt,sgstamt,igstamt,ssid,notes,termsandcond,attachfile,subtotal,cgstvalue,sgstvalue,igstvalue,totalcess,roundoff,totalrs,reg_by,reg_dept,reg_id,reg_date,orderstatus)values('$pono','$podate','$suppliername','$supplierid','$sameasbill','$vendorcode','$paymentterm','$deliverymode','$freight','$partname8','$partnameid8','$drawingno8','$remark8','$hsncode8','$reqqty8','$shortageby8','$poqty8','$unit8','$deliverydate8','$unitprice8','$discount8','$tax8','$cgstper8','$sgstper8','$igstper8','$cesstype8','$cess_cgstper8','$cess_sgstper8','$cess_igstper8','$cessamt8','$totalprice8','$totalpr_wo_dis8','$cgstamt8','$sgstamt8','$igstamt8','$ssid','$notes','$termsandcond','$attachfile','$subtotal','$cgstvalue','$sgstvalue','$igstvalue','$totalcess','$roundoff','$totalrs','$name','$department','$uid','$reg_date','Open')");
}

if($partname9!=""){
$sql9=mysql_query("insert into purchaseorder_reg(pono,podate,suppliername,supplierid,sameasbill,vendorcode,paymentterm,deliverymode,freight,partname,partnameid,drawingno,remark,hsncode,reqqty,shortageby,poqty,unit,deliverydate,unitprice,discount,tax,cgstper,sgstper,igstper,cesstype,cess_cgstper,cess_sgstper,cess_igstper,cessamt,totalprice,totalpr_wo_dis,cgstamt,sgstamt,igstamt,ssid,notes,termsandcond,attachfile,subtotal,cgstvalue,sgstvalue,igstvalue,totalcess,roundoff,totalrs,reg_by,reg_dept,reg_id,reg_date,orderstatus)values('$pono','$podate','$suppliername','$supplierid','$sameasbill','$vendorcode','$paymentterm','$deliverymode','$freight','$partname9','$partnameid9','$drawingno9','$remark9','$hsncode9','$reqqty9','$shortageby9','$poqty9','$unit9','$deliverydate9','$unitprice9','$discount9','$tax9','$cgstper9','$sgstper9','$igstper9','$cesstype9','$cess_cgstper9','$cess_sgstper9','$cess_igstper9','$cessamt9','$totalprice9','$totalpr_wo_dis9','$cgstamt9','$sgstamt9','$igstamt9','$ssid','$notes','$termsandcond','$attachfile','$subtotal','$cgstvalue','$sgstvalue','$igstvalue','$totalcess','$roundoff','$totalrs','$name','$department','$uid','$reg_date','Open')");
}
if($sql=="")
  {
        echo '<script>        
        setTimeout(function() {
        swal({  
                    title: "Oops...!!!",
                    text: "Something went wrong",
                    type: "warning"   
          }, 
           function() 
          {
                    window.location = "purchaseorder_register.php";

            });
         }, 1000);
       </script>';       
    }
  else
  {
   $sql=mysql_query("select pono from purchaseorder_reg order by pono desc limit 1");
      while($row=mysql_fetch_array($sql))
      {
        $cmpn=$row['pono'];
      }
      $pono=$cmpn;
      echo '<script>        
        setTimeout(function() {
        swal({  
                    title: "Success!",
                    text: "Your Purchase Order has been successfully Registered.",
                    type: "success"   
          }, 
           function() 
          {
                    window.location = "purchaseorder_viewup.php";
            });
         }, 1000);
       </script>';    
        }
      }        
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="OTlogo.png">
    <title>ESM | Purchase Order</title>
      <link href="assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet">

    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <!-- <link rel="stylesheet" href="/resources/demos/style.css"> -->
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="main/js/jquery-1.12.4.js"></script>
    <!--   <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script> -->
    <!--   <script src="main/js/jquery-inputmask.js"></script> -->
    <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/plugins/html5-editor/bootstrap-wysihtml5.css">
    <!-- This page css -->
    <link href="assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/switchery/dist/switchery.min.css" rel="stylesheet" />
    <link href="assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" />
    <link href="assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" />
    <link href="assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
    <link href="assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/morrisjs/morris.css" rel="stylesheet">
    <link href="assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
    <link href="main/css/style.css" rel="stylesheet">
    <link href="main/css/colors/blue.css" id="theme" rel="stylesheet">
    <!--  <link href="assets/plugins/sweetalert/sweetalert.css"> -->


    <link href="assets/plugins/wizard/steps.css">
    <!--[if lt IE 9]>
      <script src="html5shiv.js"></script>
      <script src="respond.min.js"></script>
  <![endif]-->
    <script src="main/js/jquery-ui.js"></script>
    <script src="jquery.min.js"></script>
    <link href="sweetalert.css" rel="stylesheet" />
    <script src="sweetalert.min.js"></script>

    <!-- script for cost input masking-->
    <script src="main/js/jquery-inputmask.js"></script>
    <!--<script src="main/js/jquery-ui.js"></script>
     <script src="jquery.min.js"></script> -->
  

<style>
     
.drag {

  padding: 4px;
  text-align: center;
  position: relative;
}

.form-control {

  font-size: 11px;
}

@import url('font-awesome.min.css');

.panel-title>a:before {
  float: right !important;
  font-family: FontAwesome;
  content: "\f068";
  padding-right: 5%;
}

.panel-title>a.collapsed:before {
  float: right !important;
  content: "\f067";
}

.panel-title>a:hover,
.panel-title>a:active,
.panel-title>a:focus {
  text-decoration: none;
}

ul.wysihtml5-toolbar li a[title="Insert image"] {
  display: none;
}

ul.wysihtml5-toolbar li.dropdown {
  display: none;
}


/*tr.headcolor
{
background-color: #0080FF;
}*/
th.datacolor{
color:white;
}
td.table1
{
  font-size:11px;
  font-weight:400;
  color:black;
}
tbody td
{
  font-size:11px;
 
}

#firsttab th
{
  border: 1px solid white; 
}
#firsttab td
{
  border: 1px solid #D3D3D3; 
}

#firsttab td, #firsttab th {
   vertical-align: middle;
   }

#firsttab thead th {
   vertical-align: middle;
   }

form label {
    font-size: 13px;
    color: black;
    font-weight: 500;
}

/*#cusdetails td{
  border: 1px solid gray;
}*/
#cusdetails td
{
  border:solid 1px #D3D3D3;
}
#grirdetails td
{
  border:solid 1px #D3D3D3;
}


.wrap {
    position: relative;
    display: inline-block;
   
}
.wrap span {
    position: absolute;
  
    right: 0px;
    } 
.counter{
    background-color: #5dc991;
    color: #fff;
    font-size: 10px;
    padding: 2px 5px;
    line-height: 12px;
    height: 14px;
    text-align: center;
    border-top-right-radius: 4px;
    border-bottom-left-radius: 4px;
    font-weight: 400;
}
.table thead th, .table th {
    font-weight: 400;
}
textarea{
  background-color:white;
  line-height: 1.3;
  text-align: left;
  resize:vertical;
}
</style>


<style type="text/css">
      .card-body {
        border-radius: 5px;
      }
      td.day{
        font-size: 15px;

      }
       td.today.day{
        font-size: 15px;
        
      }

</style>
<!--check box -->
<style type="text/css">
[type="checkbox"].filled-in:not(:checked) + label:before {
    width: 0;
    height: 0;
    border: 3px solid transparent;
    left: 6px;
    top: 10px;
/*    -webkit-transform: rotateZ(37deg);
    -ms-transform: rotate(37deg);*/
    transform: rotateZ(37deg);
  /*  -webkit-transform-origin: 20% 40%;
    -ms-transform-origin: 100% 100%;*/
    transform-origin: 100% 100%;
}
[type="checkbox"].filled-in:not(:checked) + label:after {
    height: 20px;
    width: 20px;
    background-color: transparent;
    border: 1px solid #b1b8bb;
    top: 0px;
    z-index: 0;
}  
</style>

<!--hiding arrow for option tag -->
<style type="text/css">
#ship15, #ship11, #ship12, #ship13, #ship14, #ship16, #ssid{
-webkit-appearance: none;
-moz-appearance: none;
appearance: none;
background: none;
/*font-weight:450;*/
color:black;
font-size:13px
}
</style>

</head>

<!-- fetch customerid on selection of customer name -->
<script type="text/javascript">
  $(document).ready(function(){
    $("#category-list").change(function(){
      var supplierid= $("option:selected", this).attr('data-price7');
      $("#supplierid").val(supplierid);
    });
  });
</script>
<!-- fetch shipping address on selection of shipping type -->
<script type="text/javascript">
  $(document).ready(function(){
    $("#category-list2").change(function(){
      var shipaddress= $("option:selected", this).attr('data-price');
      $("#product-price").val(shipaddress);
 });

  });
</script>


<script>
function fileValidationupload4(){
var fileInput = document.getElementById('offer33');
var filePath = fileInput.value;


var ext = filePath.substring(filePath.lastIndexOf('.') + 1);
var ext1=ext.toLowerCase();
const fileInputsize1 = document.getElementById('sizevalid').value;
const fileInputsize = document.getElementById('filevalid').value;
const filetype2 = document.getElementById('filetype2').value;
const totalsize = document.getElementById('sizevalid1').value;


if(!fileInputsize.includes(ext1)){
swal("Oops...!!!", "Kindly upload a valid file format\n"+fileInputsize, "warning")
fileInput.value = '';
     return false;
}
var size=$('#offer33')[0].files[0].size;
if(size > totalsize)
{
    swal("Oops...!!!","Attachment file size exceeds the allowable file limit\n"+fileInputsize1+filetype2, "warning")
      fileInput.value = '';
      return false;
}
}
</script>

<script type="text/javascript">
  function checkform() {
  if(document.grir_form.suppliername.value == "" )
  {
      swal("Did you miss something ?", "Kindly Select Supplier Name", "warning")
       return false;
  } 
  if(document.grir_form.partname.value == "" )
  {
     swal("Did you miss something ?", "Kindly Select Part Name", "warning")
     return false;
  }
  if(document.grir_form.partname.value != "" )
  {
    if(document.grir_form.poqty.value == "" )
    {
     swal("Did you miss something ?", "Kindly Fill PO Quantity", "warning")
     return false;
    }
  }
  if(document.grir_form.partname1.value != "" )
  {
    if(document.grir_form.poqty1.value == "" )
    {
     swal("Did you miss something ?", "Kindly Fill PO Quantity", "warning")
     return false;
    }
  }
 if(document.grir_form.partname2.value != "" )
  {
    if(document.grir_form.poqty2.value == "" )
    {
     swal("Did you miss something ?", "Kindly Fill PO Quantity", "warning")
     return false;
    }
  }
  if(document.grir_form.partname3.value != "" )
  {
    
   if(document.grir_form.poqty3.value == "" )
    {
     swal("Did you miss something ?", "Kindly Fill PO Quantity", "warning")
     return false;
    }
  }
  if(document.grir_form.partname4.value != "" )
  {
   if(document.grir_form.poqty4.value == "" )
    {
     swal("Did you miss something ?", "Kindly Fill PO Quantity", "warning")
     return false;
    }
  }
  if(document.grir_form.partname5.value != "" )
  {
    if(document.grir_form.poqty5.value == "" )
    {
     swal("Did you miss something ?", "Kindly Fill PO Quantity", "warning")
     return false;
    }
  }
  if(document.grir_form.partname6.value != "" )
  {
    if(document.grir_form.poqty6.value == "" )
    {
     swal("Did you miss something ?", "Kindly Fill PO Quantity", "warning")
     return false;
    }
  }
  if(document.grir_form.partname7.value != "" )
  {
   if(document.grir_form.poqty7.value == "" )
    {
     swal("Did you miss something ?", "Kindly Fill PO Quantity", "warning")
     return false;
    }
  }
  if(document.grir_form.partname8.value != "" )
  {
    if(document.grir_form.poqty8.value == "" )
    {
     swal("Did you miss something ?", "Kindly Fill PO Quantity", "warning")
     return false;
    }
  }
  if(document.grir_form.partname9.value != "" )
  {
    if(document.grir_form.poqty9.value == "" )
    {
     swal("Did you miss something ?", "Kindly Fill PO Quantity", "warning")
     return false;
    }
  }
  else {
    Swal.fire({
                    title: 'Be patient !',
                    text: 'Your Purchase Order is being submitted',
                    showConfirmButton: false,
                    allowEscapeKey: false,
                    allowOutsideClick: false,
                    timer: 60000,
                    imageUrl: 'progressbar.gif',
                  }).then(function(result) {
                    if (result.dismiss === 'timer') {
                      console.log('I was closed by the timer')
                    }
                  })
             document.grir_form.submit();

     }
  }
</script>
<body class="fix-header fix-sidebar card-no-border">
    <div id="main-wrapper" style="font-size:small">
      <?php include("includes/config.php");?>
      <?php include("includes/header.php");?>
      <?php include("includes/sidebar.php");?>
      <div class="page-wrapper">
        <div class="row page-titles m-b-0" style="height:45px">
          <div class="col-md-5 align-self-center">
            <h4 class="text-themecolor">Purchase Order</h4>
          </div>
          <div class="col-md-7 align-self-center">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
              <li class="breadcrumb-item active">Purchase Order</li>
            </ol>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12" style="background-color:#F0F0F0">
            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true"><br>
              <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingTwo" style="height:30px">
              <h5 class="panel-title" style="margin-left:2.5%">Local Dashboard</h5>
                </div>
            </div>
          </div>
        </div>
      </div>
<br>

<div class="container-fluid">
<div class="row">
    <div class="col-12">
      <div class="card">
         <div class="card-body">



<!-- settings start-->
<?php 
$queryacc=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($rowacc=mysql_fetch_array($queryacc)) 
{
?> 
<ul class="nav nav-tabs" role="tablist">
<?php
$query21=mysql_query("select * from users where id='".$_SESSION['id']."'");
while($row21=mysql_fetch_array($query21)) 
{  
$complaintarr1=$row21['purchaseorderaccess'];
$comarr1=explode(',',trim( $complaintarr1));
$secondaryarr1=$row21['multidept'];
$secarr2=explode(',',trim($secondaryarr1));
//to remove last comma from multidept array
$lastcomma = '';
foreach($secarr2 as $i=>$k) 
{
$lastcomma .= $k.',';
}
$lastcomma = rtrim($lastcomma,',');
$secarr1=explode(',',trim($lastcomma));
$querydays1=mysql_query("select * from purchaseorder_setting order by id desc limit 1");
while($rowdays1=mysql_fetch_array($querydays1)) 
{ 
$quadept1=$rowdays1['po_regdept'];
$qua1=explode(',',trim($quadept1));
$result1 = array_intersect($secarr1,$qua1);
if((($result1!=array())||(in_array($row21['department'],$qua1))) && (in_array('regpurchaseorder',$comarr1)))
{  ?>

<?php $query1=mysql_query("select * from master order by id desc limit 1");
while($row1=mysql_fetch_array($query1))
{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt3=date("Y-m-d h:i");
if($row1['licend']<= $dt3) 
{ ?>
<li class="nav-item"><a class="nav-link active"  onclick="myFunctionstatus()" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span><span class="hidden-xs-down">Register</span></a></li> 
<?php } 
else
{ ?>
<li class="nav-item"><a class="nav-link active" href="purchaseorder_register.php" role="tab"><span class="hidden-sm-up"><i class="ti-email"></i></span> <span class="hidden-xs-down"> Register &nbsp;<b>
</b></span></a> 
</li>
<?php } 
} 

}else{

} } } ?>

<?php   
$inhousecomarr=$rowacc['purchaseorderaccess'];
$inhousearr=explode(',',trim( $inhousecomarr));
if(in_array('viewpurchaseorder',$inhousearr))
{ ?>
<?php $query1=mysql_query("select * from master order by id desc limit 1");
while($row1=mysql_fetch_array($query1))
{
date_default_timezone_set('Asia/Kolkata');// change according timezone
$dt3=date("Y-m-d h:i:s");
if($row1['licend']<= $dt3) 
{
?>
<li class="nav-item"><a class="nav-link" onclick="myFunctionstatus()" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span><span class="hidden-xs-down">View/Update</span></a></li> 
<?php } 
else
{ ?>
<li class="nav-item"><a class="nav-link" href="purchaseorder_viewup.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">View/Update</span></a> </li>
<?php } 
} ?>

<?php
} else{

} 
?>

<?php $companymaster=$rowacc['addmanageaccess'];
$compaarr=explode(',',trim($companymaster));
if(in_array('generalmanage',$compaarr))
{?>
<li class="nav-item"> <a class="nav-link"  href="purchaseorder_setting.php" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Settings</span></a> </li>
<?php } } ?>  
</ul>
<!--settings end --> 





<div class="tab-content">
  <div class="tab-pane active" id="home" role="tabpanel">
    <div class="p-20">
   <form class="form-horizontal style-form" method="post" name="grir_form" id="my-form" enctype="multipart/form-data">
 <?php
      $incid=mysql_query("select * from purchaseorder_reg order by id desc limit 1");
      while($rowq=mysql_fetch_array($incid))
      {
        $cmpn12=$rowq['pono'];
      }
      $bkno1=$cmpn12+1;
  ?>   
<div class="row">
<div>
  <p><span style="color:red;margin-left: 870px">*</span>Mandatory Field</p>
</div>
</div>
<br>
<div id="report">

   <div class="row">

      <div class="col-md-3">
       <div class="form-group" style="color:blue;font-size:small;"> 
      <label for="firstName1" style="color:blue;font-size:small;;">PO No. : </label>
              <?php
                echo  $bkno1;
              ?>                                            
         </div>
      </div>
      <div class="col-md-6"></div>
      <div class="col-md-3">
       <div class="form-group" style="color:blue;font-size:small;"> 
      <label for="firstName1" style="color:blue;font-size:small;;">PO Date : </label>
              <?php
                echo " " . date("d-m-Y") . "<br>";
              ?>                                            
         </div>
        </div>
    </div>        
<section>
<?php
    $con = mysqli_connect("localhost","root","","finalcms");
    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }
    ?>
  <?php $query1=mysql_query("select * from master order by id desc limit 1");
    while($row1=mysql_fetch_array($query1))
    {
    date_default_timezone_set('Asia/Kolkata');// change according timezone
    $dt3=date("Y-m-d h:i:s");
    if($row1['licend']<= $dt3) 
    { ?>
  <center>
    <span>
      <h4 style="color:red">Sorry !</h4>
      <h5>You can't register any GRIR.<br>Your license has expired</h5>
    </span>
  </center>
  <?php }
else {?>

<?php
$id6= $bkno1;
?>  

<?php
$sqlfilecheck=mysql_query("select * from purchaseorder_setting order by id desc limit 1");
while($rowfilecheck=mysql_fetch_array($sqlfilecheck))
{ ?>

<input type="text" id="sizevalid" class="form-control" style="color:black;width:150px;display: none;" value="<?php echo htmlentities($rowfilecheck['filesize']);?>" >
<input type="text" id="filevalid" class="form-control" style="color:black;width:150px;display: none;"value="<?php echo  htmlentities($rowfilecheck['filetype']);?>" >
<input type="text" id="filetype2" class="form-control" style="color:black;width:150px;display: none;"value="<?php echo  htmlentities($rowfilecheck['filesize2']);?>" >
<input type="text" id="sizevalid1" class="form-control" style="color:black;width:150px;display: none;"value="<?php echo  htmlentities($rowfilecheck['totalsize']);?>" >
<?php } ?>

<input type="text" value="<?php echo $id6;?>" id="pono" name="pono" class="form-control" autocomplete=off style="display:none;">  


<!-- fetching company details-->
<?php 
$querycom=mysql_query("select * from company order by id desc limit 1");
while($rowcompany=mysql_fetch_array($querycom)) 
{
$companyname=$rowcompany['name'];
$address1=$rowcompany['address1'];
$address2=$rowcompany['address2'];
$address3=$rowcompany['address3'];
$city=$rowcompany['city'];
$state=$rowcompany['state'];
$country=$rowcompany['country'];
$pincode=$rowcompany['pincode'];
$logo=$rowcompany['logo'];
$gstno=$rowcompany['gstno'];

$bankname=$rowcompany['bankname'];
$branch=$rowcompany['branch'];
$accno=$rowcompany['accno'];
$ifsc=$rowcompany['ifsc'];
$micr=$rowcompany['micr'];
}
?> 


<table class="table table-sm">
<tr>
<td>
<label>Supplier Name</label><br>
<div class="form-material" style="height:45px;">
<select class="form-control" name="suppliername" id="category-list"  value="<?php echo htmlspecialchars_decode($row11['suppliername']);?>">
<option><?php echo htmlspecialchars_decode($row11['suppliername']);?></option>
<?php
$querydept =mysql_query("SELECT * FROM supplierproduct group by suppliername");
while($machine=mysql_fetch_array($querydept))
{
?>
<option data-price7="<?php echo htmlentities($machine['supplierid']);?>" value="<?php echo htmlentities($machine['supplierid']);?>"><?php echo htmlspecialchars_decode($machine['suppliername']);?></option>
<?php
}
?>
</select> 
<input id="supplierid"  style="display:none" name="supplierid" value="<?php echo htmlentities($row11['supplierid']);?>"> 
</div>

<!-- <label>GSTIN</label>
<div class="form-material" style="height:17px;">
<select id="gstin" class="form-control" name="gstno" value="<?php echo $gstno ?>" readonly="">
<option><?php echo $gstno ?></option>
</select></div> -->

<!-- <div class="form-material" style="height:17px;">
<select id="email" class="form-control" name="email" value="<?php echo $email ?>" readonly="">
<option><?php echo $email ?></option>
</select></div> -->

<!-- <div class="form-material" style="height:17px;">
<select id="contactno" class="form-control" name="contactno" value="<?php echo $contactno ?>" readonly="">
<option><?php echo $contactno ?></option>
</select></div><br> -->
</td>

<td>
<label>Billing Address</label><br>
<span style="font-size:13px;color:black;"><?php echo htmlspecialchars_decode($companyname);?></span><br>
<span style="font-size:13px;color:black;"><?php echo $address1; ?>&nbsp;<?php echo $address2; ?></span><br>
<span style="font-size:13px;color:black;"><?php echo $address3; ?></span><br>
<span style="font-size:13px;color:black;"><?php echo $city; ?>&nbsp;<?php echo $pincode; ?></span><br>
<span style="font-size:13px;color:black;"><?php echo $state; ?>&nbsp;<?php echo $country; ?></span><br>
<span style="font-size:13px;color:black;">GSTIN : <?php echo $gstno; ?></span>
<!-- <div class="form-material" style="height:17px;">
<select value="<?php echo $add1 ?>" id="officeaddress2" class="form-control" readonly="" style="width:300px;">
<option><?php echo $add1 ?></option>
</select></div> -->

<!-- <div class="form-material" style="height:17px;">
<select value="<?php echo $add2 ?><?php echo $add3 ?>" id="officeaddress3" class="form-control" readonly="" style="width:300px;">
<option><?php echo $add2 ?>&nbsp;<?php echo $add3 ?></option>
</select>
</div> -->

<!-- <div class="form-material" style="height:17px;">
<select value="<?php echo $add4 ?><?php echo $add5 ?><?php echo $add6 ?><?php echo $add8 ?>" id="officeaddress4" class="form-control" readonly="" style="width:300px;">
<option><?php echo $add4 ?>&nbsp;<?php echo $add5 ?>&nbsp;<?php echo $add8 ?></option>
</select>
</div> -->

<!-- <div class="form-material" style="height:17px;">
<select value="<?php echo $add7 ?>" id="officeaddress5" class="form-control" readonly="" style="width:300px;">
<option><?php echo $add6 ?>&nbsp;<?php echo $add7 ?></option>
</select>
</div> -->
</td>  

<td>
<label>Delivery To</label>
<input type="checkbox" id="basic_checkbox_2" value="Yes" <?php if($row11['sameasbill']=="Yes"){echo "checked";} ?> onchange="valueChanged()" name="sameasbill">
<label for="basic_checkbox_2" style="font-size:10px;">Same as Billing Address</label>
<div id="autoUpdate" class="autoUpdate" style="display:none;">
<span style="font-size:13px;color:black;"><?php echo htmlspecialchars_decode($companyname);?></span><br>
<span style="font-size:13px;color:black;"><?php echo $address1; ?>&nbsp;<?php echo $address2; ?></span><br>
<span style="font-size:13px;color:black;"><?php echo $address3; ?></span><br>
<span style="font-size:13px;color:black;"><?php echo $city; ?>&nbsp;<?php echo $pincode; ?></span><br>
<span style="font-size:13px;color:black;"><?php echo $state; ?>&nbsp;<?php echo $country; ?></span><br>
<span style="font-size:13px;color:black;">GSTIN : <?php echo $gstno; ?></span>
<!-- <div class="form-material" style="height:17px;"> 
<select value="<?php echo $add1 ?>" id="shipadd1" class="form-control" readonly="" style="width:300px;">
<option><?php echo $add1 ?></option>
</select></div> -->

<!-- <div class="form-material" style="height:17px;">
<select value="<?php echo $add2 ?><?php echo $add3 ?>" id="shipadd2" class="form-control" readonly="" style="width:300px;">
<option><?php echo $add2 ?>&nbsp;<?php echo $add3 ?></option>
</select>
</div> -->

<!-- <div class="form-material" style="height:17px;">
<select value="<?php echo $add4 ?><?php echo $add5 ?><?php echo $add6 ?><?php echo $add8 ?>" id="shipadd3" class="form-control" readonly="" style="width:300px;">
<option><?php echo $add4 ?>&nbsp;<?php echo $add5 ?>&nbsp;<?php echo $add8 ?></option>
</select>
</div> -->

<!-- <div class="form-material" style="height:17px;">
<select value="<?php echo $add7 ?>" id="shipadd4" class="form-control" readonly="" style="width:300px;">
<option><?php echo $add7 ?>&nbsp;<?php echo $add6 ?></option>
</select>
</div> -->
</div>

<div id="ship" style="display:none;">

  <div class="form-material" style="height:30px;">
  <select class="form-control" name="shippingtype" value="" id="shippingtypeid" style="width:200px" value="<?php echo htmlspecialchars_decode($row11['shippingtype']);?>">
<?php 
 if($row11['shippingtype']=="")
  { ?>
 <option value="">Select Shipping Address</option> 
<?php   }
  else if($row11['shippingtype']!="")
{  ?>
 <option><?php echo htmlspecialchars_decode($row11['shippingtype']);?></option>
<?php } ?> 

    <?php
    require_once("dbcontrollernew.php");
    $db_handle1 = new DBController();
    $querycustomer ="select * from company_address";
    $customers = $db_handle1->runQuery($querycustomer);
    foreach($customers as $customer)
    {
    ?>
    <option data-price="<?php echo $customer['shipping_address'];?>" value="<?php echo htmlentities($customer['id']);?>"><?php echo htmlspecialchars_decode($customer['shipping_type']);?></option>
    <?php
    }
    ?>    
    </select> 
  </div> 

<div class="form-material" style="height:17px;">
<select id="ship15" class="form-control" readonly="" style="width:300px;">
<option></option>
</select>
</div>

<div class="form-material" style="height:17px;">
<select id="ship11" class="form-control" readonly="" style="width:300px;">
<option></option>
</select>
</div>

<div class="form-material" style="height:17px;">
<select id="ship12" class="form-control" readonly="" style="width:300px;">
<option></option>
</select>
</div>

<div class="form-material" style="height:17px;">
<select id="ship13" class="form-control" readonly="" style="width:300px;">
<option></option>
</select>
</div>

<div class="form-material" style="height:17px;">
<select id="ship14" class="form-control" readonly="" style="width:300px;">
<option></option>
</select>
</div>

<div class="form-material" style="height:17px;">
<select id="ship16" class="form-control" readonly="" style="width:300px;">
<option></option>
</select>
</div>

<!--fetch autoinc id from supplier_address table-->
<div class="form-material">
<select id="ssid" name="ssid" class="form-control" readonly="" style="width:300px;display:none;">
<option></option>
</select>
</div>

</div>
</td> 
</tr> 
</table>  

<table class="table table-sm">
<tr>
<td>
<label>Vendor Code</label><br>
<div class="form-material" style="height:17px;">
<select id="vendorcode" class="form-control" name="vendorcode" readonly="">
<option></option>
</select></div> 
</td>

<td>
<label>Payment Term</label><br>
<div class="form-material" style="height:17px;">
<select id="paymentterm" class="form-control" name="paymentterm" value="<?php echo $payment_term ?>" readonly="">
<option><?php echo $payment_term ?></option>
</select></div> 
</td>

<td>
<label>Delivery Mode</label><br>
<div class="form-material">
<select name="deliverymode" class="form-control first" value="<?php echo htmlspecialchars_decode($row11['deliverymode']);?>">
<?php 
if($row11['deliverymode']=="")
{ ?>
<option value="">Please Select</option> 
<?php   }
else if($row11['deliverymode']!="")
{  ?>
<option><?php echo htmlspecialchars_decode($row11['deliverymode']);?></option>
<?php } ?> 
<option value="By Road">By Road</option>
<option value="Air">By Air</option>
<option value="Rail">By Rail</option>
<option value="By Water">By Water</option>
    <?php
        require_once("dbcontrollernew.php");
        $db_handle = new DBController();
        $query ="SELECT * FROM salesinvoice_transportmd where status='1'";
        $products = $db_handle->runQuery($query);
        foreach($products as $product)
        { ?>
        <option value="<?php echo $product['transport_mode'];?>"><?php echo $product['transport_mode'];?></option>
  <?php } ?>

  </select> 
</div>
</td>
<td>
<label>Freight</label> <br>
<div class="form-material">
<select class="form-control" name="freight" value="<?php echo htmlspecialchars_decode($row11['freight']);?>">
<?php 
if($row11['freight']=="")
{ ?>
<option value="">Please Select</option> 
<?php   }
else if($row11['freight']!="")
{  ?>
<option><?php echo htmlspecialchars_decode($row11['freight']);?></option>
<?php } ?> 
    <option value="Paid">Paid</option>
    <option value="To Pay">To Pay</option>
</select>
</div>
</td>
</tr>
</table>


<br>
  <table id="grirdetails">
  <div class="table-responsive"> 
  <table class="table table-bordered table-sm" id="firsttab">
    <thead>
      <tr style="text-align: center;vertical-align: middle;background-color: #0080FF;font-size: smaller">
        <th class="datacolor" style="width:10px;">Sl No.</th>
        <th class="datacolor" style="width:150px;">Part Name</th>
        <th class="datacolor" style="width:100px;">Dwg No</th>
        <th class="datacolor" style="width:100px;">Item Remark</th>
        <th class="datacolor" style="width:70px;">HSN/SAC</th>
        <th class="datacolor" style="width:100px;">Req Qty</th>
        <th class="datacolor" style="width:70px;">Shortage by</th>
        <th class="datacolor" style="width:140px;">PO Qty</th>
        <th class="datacolor" style="width:20px;">Unit</th>
        <th class="datacolor" style="width:100px;">Delivery Date</th>
        <th class="datacolor" style="width:180px;">Unit Price</th>
        <th class="datacolor" style="width:100px;">Discount</th>
        <th class="datacolor" style="width:200px;">Tax %</th>
        <th class="datacolor" style="width:200px;">CESS %</th>
        <th class="datacolor" style="width:100px;">Total Price</th>
      </tr>
    </thead>
<tbody>
<!--adding details start : Row 1 -->
<tr class="itemdetails">
  <td>1</td>
  <!-- Part name -->
  <td> 
    <div class="form-material">          
     <select name="partname" id="productname" class="form-control">
        <option>Select</option>
        <?php
        require_once("dbcontrollernew.php");
        $db_handle = new DBController();
        $query ="SELECT * FROM supplierproduct where supplierid='$supplierid' order by partname";
        $products = $db_handle->runQuery($query);
        foreach($products as $product)
        {
          ?>
          <option data-price7="<?php echo htmlentities($product['drawingno']);?>" data-price8="<?php echo htmlentities($product['partnameid']);?>" value="<?php echo $product['partnameid'];?>"><?php echo $product['partname'];?></option>
        <?php } ?>
      </select>
    </div>
    <div class="form-material"> 
      <select name="partnameid" id="partnameid" class="form-control" readonly="" style="display: none">
        <option></option>
      </select>
    </div>
  </td>
<!-- Drawing No. -->
<td> 
    <div class="form-material"> 
      <select name="drawingno" id="drawingno" class="form-control" readonly="">
        <option></option>
      </select>
    </div>
</td>
<!-- Item Remark -->
<td>   
<div class="form-material">
 <textarea class="form-control"  maxlength="100" name="remark" rows="4" autocomplete="off" ></textarea>
</div>
</td>
<!-- hsn code -->
<td> 
<div class="form-material"> 
<select name="hsncode" id="hsncode" class="form-control" readonly="">
<option></option>
</select> 
</div>
</td>
<!-- Req Qty -->
<td>
<div class="form-material">
<input type="text" name="reqqty" id="reqqty" onkeypress="return validateFloatKeyPress(this,event);" class="form-control" autocomplete="off"/>
</div>
</td> 
<!-- Shortage by -->
<td>
<div class="form-material">
<input type="text" name="shortageby" id="shortageby" class="form-control" autocomplete="off"/>
</div>
</td> 
<!--PO Qty-->
<td>
<div class="form-material">
<input type="text" name="poqty" id="poqty" onkeypress="return validateFloatKeyPress(this,event);" oninput="rowcalculate()" class="form-control qty1" autocomplete="off"/>
</div>
</td> 
<!-- Unit -->
<td> 
<div class="form-material"> 
<select name="unit" id="unit" class="form-control" readonly="">
<option></option>
</select>
</div>
</td>
<!-- delivery date-->
<td>
<div class="form-material">
<input type="text" name="deliverydate" id="deliverydatepicker" class="form-control" autocomplete="off" placeholder="dd-mm-yyyy" /></div>  
</td>
<!--unit price -->
<td>
<div class="form-material">
<input type="text" name="unitprice" id="unitprice" onkeypress="return validateFloatKeyPress(this,event);" class="form-control qty1" oninput="rowcalculate()" autocomplete="off"/>
</div>
</td>
<!--discount -->
<td> 
<div class="form-material"> 
<div class="input-group">
<div class="input-group-prepend">
<input type="text" id="discount" class="form-control qty1" onkeypress="return validateFloatKeyPress(this,event);" name="discount" placeholder="0" value="0" oninput="rowcalculate()" autocomplete="off">
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>
</td>
<!--tax -->
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="tax" id="tax" onchange="rowcalculate()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-priceid="<?php echo htmlentities($product['id']);?>"data-pricecg="<?php echo $product['cgstvalue']; ?>" data-pricesg="<?php echo $product['sgstvalue']; ?>" data-priceig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of tax type fetch corresponding igst,cgst,sgst percentage values from tax settings -->
<div class="form-material">
<input class="form-control" id="cgstper" name="cgstper" style="display:none;">
<input class="form-control" id="sgstper" name="sgstper" style="display:none;">
<input class="form-control" id="igstper" name="igstper" style="display:none;">
</div>

<label style="font-size:10px;">CGST</label>&nbsp;<span id="cgstdis"></span><br>
<label style="font-size:10px;">SGST</label>&nbsp;<span id="sgstdis"></span><br>
<label style="font-size:10px;">IGST</label>&nbsp;<span id="igstdis"></span>
</td>
<!--CESS --> 
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="cesstype" id="cesstype" onchange="rowcalculate()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM cess_taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-pricecid="<?php echo htmlentities($product['id']);?>" data-priceccg="<?php echo $product['cgstvalue']; ?>" data-pricecsg="<?php echo $product['sgstvalue']; ?>" data-pricecig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of cess type fetch corresponding igst,cgst,sgst percentage values from cess settings -->
<div class="form-material">
<input class="form-control" id="cess_cgstper" name="cess_cgstper" style="display:none;">
<input class="form-control" id="cess_sgstper" name="cess_sgstper" style="display:none;">
<input class="form-control" id="cess_igstper" name="cess_igstper" style="display:none;">
<input type="text" name="cessamt" id="cessamt" class="form-control cessam" readonly="" style="font-weight:550;color:black;" />
</div>
</td>
<!--total price -->
<td>
<div class="form-material">  
<input type="text" name="totalprice" id="result" class="form-control tp" style="font-weight:550;color:black;" readonly="" />

<input type="text" name="totalpr_wo_dis" id="result2" class="form-control" style="font-weight:550;color:black;"/>

<input type="text" name="cgstamt" id="cgstamt" class="form-control cgstam" style="font-weight:550;color:black;"/>

<input type="text" name="sgstamt" id="sgstamt" class="form-control sgstam" style="font-weight:550;color:black;"/>

<input type="text" name="igstamt" id="igstamt" class="form-control igstam" style="font-weight:550;color:black;"/>

</div>  
</td>
</tr><!--adding details end : Row 1--> 
 


<!--adding details start : Row 2-->
<tr class="itemdetails">
  <td>2</td>
  <!-- Part name -->
  <td> 
    <div class="form-material">          
     <select name="partname1" id="productname1" class="form-control">
        <option>Select</option>
        <?php
        require_once("dbcontrollernew.php");
        $db_handle = new DBController();
        $query ="SELECT * FROM supplierproduct where supplierid='$supplierid' order by partname";
        $products = $db_handle->runQuery($query);
        foreach($products as $product)
        {
          ?>
          <option data-price7="<?php echo htmlentities($product['drawingno']);?>" data-price8="<?php echo htmlentities($product['partnameid']);?>" value="<?php echo $product['partnameid'];?>"><?php echo $product['partname'];?></option>
        <?php } ?>
      </select>
    </div>
    <div class="form-material"> 
      <select name="partnameid1" id="partnameid1" class="form-control" readonly="" style="display: none">
        <option></option>
      </select>
    </div>
  </td>
<!-- Drawing No. -->
<td> 
    <div class="form-material"> 
      <select name="drawingno1" id="drawingno1" class="form-control" readonly="">
        <option></option>
      </select>
    </div>
</td>
<!-- Item Remark -->
<td>   
<div class="form-material">
 <textarea class="form-control" maxlength="100" name="remark1" rows="4" autocomplete="off" ></textarea>
</div>
</td>
<!-- hsn code -->
<td> 
<div class="form-material"> 
<select name="hsncode1" id="hsncode1" class="form-control" readonly="">
<option></option>
</select> 
</div>
</td>
<!-- Req Qty -->
<td>
<div class="form-material">
<input type="text" name="reqqty1" id="reqqty1" onkeypress="return validateFloatKeyPress(this,event);" class="form-control" autocomplete="off"/>
</div>
</td> 
<!-- Shortage by -->
<td>
<div class="form-material">
<input type="text" name="shortageby1" id="shortageby1" class="form-control" autocomplete="off"/>
</div>
</td> 
<!--PO Qty-->
<td>
<div class="form-material">
<input type="text" name="poqty1" id="poqty1" onkeypress="return validateFloatKeyPress(this,event);" class="form-control qty1" oninput="secondrow()" autocomplete="off"/>
</div>
</td> 
<!-- Unit -->
<td> 
<div class="form-material"> 
<select name="unit1" id="unit1" class="form-control" readonly="" style="width:50px;">
<option></option>
</select>
</div>
</td>
<!-- delivery date-->
<td>
<div class="form-material">
<input type="text" name="deliverydate1" id="deliverydatepicker1" class="form-control" autocomplete="off" placeholder="dd-mm-yyyy" /></div>  
</td>
<!--unit price -->
<td>
<div class="form-material">
<input type="text" name="unitprice1" id="unitprice1" onkeypress="return validateFloatKeyPress(this,event);" class="form-control qty1" oninput="secondrow()" autocomplete="off" />
</div>
</td>
<!--discount -->
<td> 
<div class="form-material"> 
<div class="input-group">
<div class="input-group-prepend">
<input type="text" id="discount1" class="form-control qty1" onkeypress="return validateFloatKeyPress(this,event);" name="discount1" placeholder="0" value="0" oninput="secondrow()" autocomplete="off">
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>
</td>
<!--tax -->
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="tax1" id="tax1" onchange="secondrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-priceid="<?php echo htmlentities($product['id']);?>"data-pricecg="<?php echo $product['cgstvalue']; ?>" data-pricesg="<?php echo $product['sgstvalue']; ?>" data-priceig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of tax type fetch corresponding igst,cgst,sgst percentage values from tax settings -->
<div class="form-material">
<input class="form-control" id="cgstper1" name="cgstper1" style="display:none;">
<input class="form-control" id="sgstper1" name="sgstper1" style="display:none;">
<input class="form-control" id="igstper1" name="igstper1" style="display:none;">
</div>

<label style="font-size:10px;">CGST</label>&nbsp;<span id="cgstdis1"></span><br>
<label style="font-size:10px;">SGST</label>&nbsp;<span id="sgstdis1"></span><br>
<label style="font-size:10px;">IGST</label>&nbsp;<span id="igstdis1"></span>
</td>
<!--CESS --> 
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="cesstype1" id="cesstype1" onchange="secondrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM cess_taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-pricecid="<?php echo htmlentities($product['id']);?>" data-priceccg="<?php echo $product['cgstvalue']; ?>" data-pricecsg="<?php echo $product['sgstvalue']; ?>" data-pricecig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of cess type fetch corresponding igst,cgst,sgst percentage values from cess settings -->
<div class="form-material">
<input class="form-control" id="cess_cgstper1" name="cess_cgstper1" style="display:none;">
<input class="form-control" id="cess_sgstper1" name="cess_sgstper1" style="display:none;">
<input class="form-control" id="cess_igstper1" name="cess_igstper1" style="display:none;">
<input type="text" name="cessamt1" id="cessamt1" class="form-control cessam" readonly="" style="font-weight:550;color:black;" />
</div>
</td>
<!--total price -->
<td>
<div class="form-material">  
<input type="text" name="totalprice1" id="result1" class="form-control tp" style="font-weight:550;color:black;" readonly="" />

<input type="text" name="totalpr_wo_dis1" id="result21" class="form-control" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="cgstamt1" id="cgstamt1" class="form-control cgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="sgstamt1" id="sgstamt1" class="form-control sgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="igstamt1" id="igstamt1" class="form-control igstam" style="font-weight:550;color:black;display:none;"/>

</div>  
</td>
</tr><!--adding details end : Row 2--> 



<!--adding details start : Row 3-->
<tr class="itemdetails">
  <td>3</td>
  <!-- Part name -->
  <td> 
    <div class="form-material">          
     <select name="partname2" id="productname2" class="form-control">
        <option>Select</option>
        <?php
        require_once("dbcontrollernew.php");
        $db_handle = new DBController();
        $query ="SELECT * FROM supplierproduct where supplierid='$supplierid' order by partname";
        $products = $db_handle->runQuery($query);
        foreach($products as $product)
        {
          ?>
          <option data-price7="<?php echo htmlentities($product['drawingno']);?>" data-price8="<?php echo htmlentities($product['partnameid']);?>" value="<?php echo $product['partnameid'];?>"><?php echo $product['partname'];?></option>
        <?php } ?>
      </select>
    </div>
    <div class="form-material"> 
      <select name="partnameid2" id="partnameid2" class="form-control" readonly="" style="display: none">
        <option></option>
      </select>
    </div>
  </td>
<!-- Drawing No. -->
<td> 
    <div class="form-material"> 
      <select name="drawingno2" id="drawingno2" class="form-control" readonly="">
        <option></option>
      </select>
    </div>
</td> 
<!-- Item Remark -->
<td>   
<div class="form-material">
 <textarea class="form-control" maxlength="100" name="remark2" rows="4" autocomplete="off" ></textarea>
</div>
</td>
<!-- hsn code -->
<td> 
<div class="form-material"> 
<select name="hsncode2" id="hsncode2" class="form-control" readonly="">
<option></option>
</select> 
</div>
</td>
<!-- Req Qty -->
<td>
<div class="form-material">
<input type="text" name="reqqty2" id="reqqty2" onkeypress="return validateFloatKeyPress(this,event);" class="form-control" autocomplete="off"/>
</div>
</td> 
<!-- Shortage by -->
<td>
<div class="form-material">
<input type="text" name="shortageby2" id="shortageby2" class="form-control" autocomplete="off"/>
</div>
</td> 
<!--PO Qty-->
<td>
<div class="form-material">
<input type="text" name="poqty2" id="poqty2" onkeypress="return validateFloatKeyPress(this,event);" oninput="thirdrow()" class="form-control qty1" autocomplete="off"/>
</div>
</td> 
<!-- Unit -->
<td> 
<div class="form-material"> 
<select name="unit2" id="unit2" class="form-control" readonly="" style="width:50px;">
<option></option>
</select>
</div>
</td>
<!-- delivery date-->
<td>
<div class="form-material">
<input type="text" name="deliverydate2" id="deliverydatepicker2" class="form-control" autocomplete="off" placeholder="dd-mm-yyyy" /></div>  
</td>
<!--unit price -->
<td>
<div class="form-material">
<input type="text" name="unitprice2" id="unitprice2" onkeypress="return validateFloatKeyPress(this,event);" oninput="thirdrow()" autocomplete="off" class="form-control qty1"/>
</div>
</td>
<!--discount -->
<td> 
<div class="form-material"> 
<div class="input-group">
<div class="input-group-prepend">
<input type="text" id="discount2" class="form-control qty1" onkeypress="return validateFloatKeyPress(this,event);" name="discount2" placeholder="0" value="0" oninput="thirdrow()" autocomplete="off">
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>
</td>
<!--tax -->
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="tax2" id="tax2" onchange="thirdrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-priceid="<?php echo htmlentities($product['id']);?>"data-pricecg="<?php echo $product['cgstvalue']; ?>" data-pricesg="<?php echo $product['sgstvalue']; ?>" data-priceig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of tax type fetch corresponding igst,cgst,sgst percentage values from tax settings -->
<div class="form-material">
<input class="form-control" id="cgstper2" name="cgstper2" style="display:none;">
<input class="form-control" id="sgstper2" name="sgstper2" style="display:none;">
<input class="form-control" id="igstper2" name="igstper2" style="display:none;">
</div>

<label style="font-size:10px;">CGST</label>&nbsp;<span id="cgstdis2"></span><br>
<label style="font-size:10px;">SGST</label>&nbsp;<span id="sgstdis2"></span><br>
<label style="font-size:10px;">IGST</label>&nbsp;<span id="igstdis2"></span>
</td>
<!--CESS --> 
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="cesstype2" id="cesstype2" onchange="thirdrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM cess_taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-pricecid="<?php echo htmlentities($product['id']);?>" data-priceccg="<?php echo $product['cgstvalue']; ?>" data-pricecsg="<?php echo $product['sgstvalue']; ?>" data-pricecig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of cess type fetch corresponding igst,cgst,sgst percentage values from cess settings -->
<div class="form-material">
<input class="form-control" id="cess_cgstper2" name="cess_cgstper2" style="display:none;">
<input class="form-control" id="cess_sgstper2" name="cess_sgstper2" style="display:none;">
<input class="form-control" id="cess_igstper2" name="cess_igstper2" style="display:none;">
<input type="text" name="cessamt2" id="cessamt2" class="form-control cessam" readonly="" style="font-weight:550;color:black;" />
</div>
</td>
<!--total price -->
<td>
<div class="form-material">  
<input type="text" name="totalprice2" id="totalprice2" class="form-control tp" style="font-weight:550;color:black;" readonly="" />

<input type="text" name="totalpr_wo_dis2" id="totalpr_wo_dis2" class="form-control" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="cgstamt2" id="cgstamt2" class="form-control cgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="sgstamt2" id="sgstamt2" class="form-control sgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="igstamt2" id="igstamt2" class="form-control igstam" style="font-weight:550;color:black;display:none;"/>

</div>  
</td>
</tr>


<!--adding details start : Row 4-->
<tr class="itemdetails">
  <td>4</td>
  <!-- Part name -->
  <td> 
    <div class="form-material">          
     <select name="partname3" id="productname3" class="form-control">
        <option>Select</option>
        <?php
        require_once("dbcontrollernew.php");
        $db_handle = new DBController();
        $query ="SELECT * FROM supplierproduct where supplierid='$supplierid' order by partname";
        $products = $db_handle->runQuery($query);
        foreach($products as $product)
        {
          ?>
          <option data-price7="<?php echo htmlentities($product['drawingno']);?>" data-price8="<?php echo htmlentities($product['partnameid']);?>" value="<?php echo $product['partnameid'];?>"><?php echo $product['partname'];?></option>
        <?php } ?>
      </select>
    </div>
    <div class="form-material"> 
      <select name="partnameid3" id="partnameid3" class="form-control" readonly="" style="display: none">
        <option></option>
      </select>
    </div>
  </td>
<!-- Drawing No. -->
<td> 
    <div class="form-material"> 
      <select name="drawingno3" id="drawingno3" class="form-control" readonly="">
        <option></option>
      </select>
    </div>
</td>
<!-- Item Remark -->
<td>   
<div class="form-material">
 <textarea class="form-control" maxlength="100" name="remark3" rows="4" autocomplete="off" ></textarea>
</div>
</td>
<!-- hsn code -->
<td> 
<div class="form-material"> 
<select name="hsncode3" id="hsncode3" class="form-control" readonly="">
<option></option>
</select> 
</div>
</td>
<!-- Req Qty -->
<td>
<div class="form-material">
<input type="text" name="reqqty3" id="reqqty3" onkeypress="return validateFloatKeyPress(this,event);" class="form-control" autocomplete="off"/>
</div>
</td> 
<!-- Shortage by -->
<td>
<div class="form-material">
<input type="text" name="shortageby3" id="shortageby3" class="form-control" autocomplete="off"/>
</div>
</td> 
<!--PO Qty-->
<td>
<div class="form-material">
<input type="text" name="poqty3" id="poqty3" onkeypress="return validateFloatKeyPress(this,event);" oninput="fourthrow()" class="form-control qty1" autocomplete="off"/>
</div>
</td> 
<!-- Unit -->
<td> 
<div class="form-material"> 
<select name="unit3" id="unit3" class="form-control" readonly="" style="width:50px;">
<option></option>
</select>
</div>
</td>
<!-- delivery date-->
<td>
<div class="form-material">
<input type="text" name="deliverydate3" id="deliverydatepicker3" class="form-control" autocomplete="off" placeholder="dd-mm-yyyy" /></div>  
</td>
<!--unit price -->
<td>
<div class="form-material">
<input type="text" name="unitprice3" id="unitprice3" onkeypress="return validateFloatKeyPress(this,event);" oninput="fourthrow()" autocomplete="off" class="form-control qty1"/>
</div>
</td>
<!--discount -->
<td> 
<div class="form-material"> 
<div class="input-group">
<div class="input-group-prepend">
<input type="text" id="discount3" class="form-control qty1" onkeypress="return validateFloatKeyPress(this,event);" name="discount3" placeholder="0" value="0" oninput="fourthrow()" autocomplete="off">
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>
</td>
<!--tax -->
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="tax3" id="tax3" onchange="fourthrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-priceid="<?php echo htmlentities($product['id']);?>"data-pricecg="<?php echo $product['cgstvalue']; ?>" data-pricesg="<?php echo $product['sgstvalue']; ?>" data-priceig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of tax type fetch corresponding igst,cgst,sgst percentage values from tax settings -->
<div class="form-material">
<input class="form-control" id="cgstper3" name="cgstper3" style="display:none;">
<input class="form-control" id="sgstper3" name="sgstper3" style="display:none;">
<input class="form-control" id="igstper3" name="igstper3" style="display:none;">
</div>

<label style="font-size:10px;">CGST</label>&nbsp;<span id="cgstdis3"></span><br>
<label style="font-size:10px;">SGST</label>&nbsp;<span id="sgstdis3"></span><br>
<label style="font-size:10px;">IGST</label>&nbsp;<span id="igstdis3"></span>
</td>
<!--CESS --> 
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="cesstype3" id="cesstype3" onchange="fourthrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM cess_taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-pricecid="<?php echo htmlentities($product['id']);?>" data-priceccg="<?php echo $product['cgstvalue']; ?>" data-pricecsg="<?php echo $product['sgstvalue']; ?>" data-pricecig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of cess type fetch corresponding igst,cgst,sgst percentage values from cess settings -->
<div class="form-material">
<input class="form-control" id="cess_cgstper3" name="cess_cgstper3" style="display:none;">
<input class="form-control" id="cess_sgstper3" name="cess_sgstper3" style="display:none;">
<input class="form-control" id="cess_igstper3" name="cess_igstper3" style="display:none;">
<input type="text" name="cessamt3" id="cessamt3" class="form-control cessam" readonly="" style="font-weight:550;color:black;" />
</div>
</td>
<!--total price -->
<td>
<div class="form-material">  
<input type="text" name="totalprice3" id="totalprice3" class="form-control tp" style="font-weight:550;color:black;" readonly="" />

<input type="text" name="totalpr_wo_dis3" id="totalpr_wo_dis3" class="form-control" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="cgstamt3" id="cgstamt3" class="form-control cgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="sgstamt3" id="sgstamt3" class="form-control sgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="igstamt3" id="igstamt3" class="form-control igstam" style="font-weight:550;color:black;display:none;"/>

</div>  
</td>
</tr>


<!--adding details start : Row 5-->
<tr class="itemdetails">
  <td>5</td>
  <!-- Part name -->
  <td> 
    <div class="form-material">          
     <select name="partname4" id="productname4" class="form-control">
        <option>Select</option>
        <?php
        require_once("dbcontrollernew.php");
        $db_handle = new DBController();
        $query ="SELECT * FROM supplierproduct where supplierid='$supplierid' order by partname";
        $products = $db_handle->runQuery($query);
        foreach($products as $product)
        {
          ?>
          <option data-price7="<?php echo htmlentities($product['drawingno']);?>" data-price8="<?php echo htmlentities($product['partnameid']);?>" value="<?php echo $product['partnameid'];?>"><?php echo $product['partname'];?></option>
        <?php } ?>
      </select>
    </div>
    <div class="form-material"> 
      <select name="partnameid4" id="partnameid4" class="form-control" readonly="" style="display: none">
        <option></option>
      </select>
    </div>
  </td>
<!-- Drawing No. -->
<td> 
    <div class="form-material"> 
      <select name="drawingno4" id="drawingno4" class="form-control" readonly="">
        <option></option>
      </select>
    </div>
</td>
<!-- Item Remark -->
<td>   
<div class="form-material">
 <textarea class="form-control"  maxlength="100" name="remark4" rows="4" autocomplete="off" ></textarea>
</div>
</td>
<!-- hsn code -->
<td> 
<div class="form-material"> 
<select name="hsncode4" id="hsncode4" class="form-control" readonly="">
<option></option>
</select> 
</div>
</td>
<!-- Req Qty -->
<td>
<div class="form-material">
<input type="text" name="reqqty4" id="reqqty4" onkeypress="return validateFloatKeyPress(this,event);" class="form-control" autocomplete="off"/>
</div>
</td> 
<!-- Shortage by -->
<td>
<div class="form-material">
<input type="text" name="shortageby4" id="shortageby4" class="form-control" autocomplete="off"/>
</div>
</td> 
<!--PO Qty-->
<td>
<div class="form-material">
<input type="text" name="poqty4" id="poqty4" onkeypress="return validateFloatKeyPress(this,event);" oninput="fifthrow()" class="form-control qty1" autocomplete="off"/>
</div>
</td> 
<!-- Unit -->
<td> 
<div class="form-material"> 
<select name="unit4" id="unit4" class="form-control" readonly="" style="width:50px;">
<option></option>
</select>
</div>
</td>
<!-- delivery date-->
<td>
<div class="form-material">
<input type="text" name="deliverydate4" id="deliverydatepicker4" class="form-control" autocomplete="off" placeholder="dd-mm-yyyy" /></div>  
</td>
<!--unit price -->
<td>
<div class="form-material">
<input type="text" name="unitprice4" id="unitprice4" onkeypress="return validateFloatKeyPress(this,event);" oninput="fifthrow()" autocomplete="off" class="form-control qty1"/>
</div>
</td>
<!--discount -->
<td> 
<div class="form-material"> 
<div class="input-group">
<div class="input-group-prepend">
<input type="text" id="discount4" class="form-control qty1" onkeypress="return validateFloatKeyPress(this,event);" name="discount4" placeholder="0" value="0" oninput="fifthrow()" autocomplete="off">
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>
</td>
<!--tax -->
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="tax4" id="tax4" onchange="fifthrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-priceid="<?php echo htmlentities($product['id']);?>"data-pricecg="<?php echo $product['cgstvalue']; ?>" data-pricesg="<?php echo $product['sgstvalue']; ?>" data-priceig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of tax type fetch corresponding igst,cgst,sgst percentage values from tax settings -->
<div class="form-material">
<input class="form-control" id="cgstper4" name="cgstper4" style="display:none;">
<input class="form-control" id="sgstper4" name="sgstper4" style="display:none;">
<input class="form-control" id="igstper4" name="igstper4" style="display:none;">
</div>

<label style="font-size:10px;">CGST</label>&nbsp;<span id="cgstdis4"></span><br>
<label style="font-size:10px;">SGST</label>&nbsp;<span id="sgstdis4"></span><br>
<label style="font-size:10px;">IGST</label>&nbsp;<span id="igstdis4"></span>
</td>
<!--CESS --> 
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="cesstype4" id="cesstype4" onchange="fifthrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM cess_taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-pricecid="<?php echo htmlentities($product['id']);?>" data-priceccg="<?php echo $product['cgstvalue']; ?>" data-pricecsg="<?php echo $product['sgstvalue']; ?>" data-pricecig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of cess type fetch corresponding igst,cgst,sgst percentage values from cess settings -->
<div class="form-material">
<input class="form-control" id="cess_cgstper4" name="cess_cgstper4" style="display:none;">
<input class="form-control" id="cess_sgstper4" name="cess_sgstper4" style="display:none;">
<input class="form-control" id="cess_igstper4" name="cess_igstper4" style="display:none;">
<input type="text" name="cessamt4" id="cessamt4" class="form-control cessam" readonly="" style="font-weight:550;color:black;" />
</div>
</td>
<!--total price -->
<td>
<div class="form-material">  
<input type="text" name="totalprice4" id="totalprice4" class="form-control tp" style="font-weight:550;color:black;" readonly="" />

<input type="text" name="totalpr_wo_dis4" id="totalpr_wo_dis4" class="form-control" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="cgstamt4" id="cgstamt4" class="form-control cgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="sgstamt4" id="sgstamt4" class="form-control sgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="igstamt4" id="igstamt4" class="form-control igstam" style="font-weight:550;color:black;display:none;"/>

</div>  
</td>
</tr>



<!--adding details start : Row 6 -->
<tr class="itemdetails">
  <td>6</td>
  <!-- Part name -->
  <td> 
    <div class="form-material">          
     <select name="partname5" id="productname5" class="form-control">
        <option>Select</option>
        <?php
        require_once("dbcontrollernew.php");
        $db_handle = new DBController();
        $query ="SELECT * FROM supplierproduct where supplierid='$supplierid' order by partname";
        $products = $db_handle->runQuery($query);
        foreach($products as $product)
        {
          ?>
          <option data-price7="<?php echo htmlentities($product['drawingno']);?>" data-price8="<?php echo htmlentities($product['partnameid']);?>" value="<?php echo $product['partnameid'];?>"><?php echo $product['partname'];?></option>
        <?php } ?>
      </select>
    </div>
    <div class="form-material"> 
      <select name="partnameid5" id="partnameid5" class="form-control" readonly="" style="display: none">
        <option></option>
      </select>
    </div>
  </td>
<!-- Drawing No. -->
<td> 
    <div class="form-material"> 
      <select name="drawingno5" id="drawingno5" class="form-control" readonly="">
        <option></option>
      </select>
    </div>
</td>
<!-- Item Remark -->
<td>   
<div class="form-material">
 <textarea class="form-control"  maxlength="100" name="remark5" rows="4" autocomplete="off" ></textarea>
</div>
</td>
<!-- hsn code -->
<td> 
<div class="form-material"> 
<select name="hsncode5" id="hsncode5" class="form-control" readonly="">
<option></option>
</select> 
</div>
</td>
<!-- Req Qty -->
<td>
<div class="form-material">
<input type="text" name="reqqty5" id="reqqty5" onkeypress="return validateFloatKeyPress(this,event);" class="form-control" autocomplete="off"/>
</div>
</td> 
<!-- Shortage by -->
<td>
<div class="form-material">
<input type="text" name="shortageby5" id="shortageby5" class="form-control" autocomplete="off"/>
</div>
</td> 
<!--PO Qty-->
<td>
<div class="form-material">
<input type="text" name="poqty5" id="poqty5" onkeypress="return validateFloatKeyPress(this,event);" oninput="sixthrow()" class="form-control qty1" autocomplete="off"/>
</div>
</td> 
<!-- Unit -->
<td> 
<div class="form-material"> 
<select name="unit5" id="unit5" class="form-control" readonly="" style="width:50px;">
<option></option>
</select>
</div>
</td>
<!-- delivery date-->
<td>
<div class="form-material">
<input type="text" name="deliverydate5" id="deliverydatepicker5" class="form-control" autocomplete="off" placeholder="dd-mm-yyyy" /></div>  
</td>
<!--unit price -->
<td>
<div class="form-material">
<input type="text" name="unitprice5" id="unitprice5" onkeypress="return validateFloatKeyPress(this,event);" oninput="sixthrow()" autocomplete="off" class="form-control qty1"/>
</div>
</td>
<!--discount -->
<td> 
<div class="form-material"> 
<div class="input-group">
<div class="input-group-prepend">
<input type="text" id="discount5" class="form-control qty1" onkeypress="return validateFloatKeyPress(this,event);" name="discount5" placeholder="0" value="0" oninput="sixthrow()" autocomplete="off">
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>
</td>
<!--tax -->
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="tax5" id="tax5" onchange="sixthrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-priceid="<?php echo htmlentities($product['id']);?>"data-pricecg="<?php echo $product['cgstvalue']; ?>" data-pricesg="<?php echo $product['sgstvalue']; ?>" data-priceig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of tax type fetch corresponding igst,cgst,sgst percentage values from tax settings -->
<div class="form-material">
<input class="form-control" id="cgstper5" name="cgstper5" style="display:none;">
<input class="form-control" id="sgstper5" name="sgstper5" style="display:none;">
<input class="form-control" id="igstper5" name="igstper5" style="display:none;">
</div>

<label style="font-size:10px;">CGST</label>&nbsp;<span id="cgstdis5"></span><br>
<label style="font-size:10px;">SGST</label>&nbsp;<span id="sgstdis5"></span><br>
<label style="font-size:10px;">IGST</label>&nbsp;<span id="igstdis5"></span>
</td>
<!--CESS --> 
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="cesstype5" id="cesstype5" onchange="sixthrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM cess_taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-pricecid="<?php echo htmlentities($product['id']);?>" data-priceccg="<?php echo $product['cgstvalue']; ?>" data-pricecsg="<?php echo $product['sgstvalue']; ?>" data-pricecig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of cess type fetch corresponding igst,cgst,sgst percentage values from cess settings -->
<div class="form-material">
<input class="form-control" id="cess_cgstper5" name="cess_cgstper5" style="display:none;">
<input class="form-control" id="cess_sgstper5" name="cess_sgstper5" style="display:none;">
<input class="form-control" id="cess_igstper5" name="cess_igstper5" style="display:none;">
<input type="text" name="cessamt5" id="cessamt5" class="form-control cessam" readonly="" style="font-weight:550;color:black;" />
</div>
</td>
<!--total price -->
<td>
<div class="form-material">  
<input type="text" name="totalprice5" id="totalprice5" class="form-control tp" style="font-weight:550;color:black;" readonly="" />

<input type="text" name="totalpr_wo_dis5" id="totalpr_wo_dis5" class="form-control" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="cgstamt5" id="cgstamt5" class="form-control cgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="sgstamt5" id="sgstamt5" class="form-control sgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="igstamt5" id="igstamt5" class="form-control igstam" style="font-weight:550;color:black;display:none;"/>

</div>  
</td>
</tr>
<!--adding details end : Row 6--> 


<!--adding details start : Row 7-->
<tr class="itemdetails">
  <td>7</td>
  <!-- Part name -->
  <td> 
    <div class="form-material">          
     <select name="partname6" id="productname6" class="form-control">
        <option>Select</option>
        <?php
        require_once("dbcontrollernew.php");
        $db_handle = new DBController();
        $query ="SELECT * FROM supplierproduct where supplierid='$supplierid' order by partname";
        $products = $db_handle->runQuery($query);
        foreach($products as $product)
        {
          ?>
          <option data-price7="<?php echo htmlentities($product['drawingno']);?>" data-price8="<?php echo htmlentities($product['partnameid']);?>" value="<?php echo $product['partnameid'];?>"><?php echo $product['partname'];?></option>
        <?php } ?>
      </select>
    </div>
    <div class="form-material"> 
      <select name="partnameid6" id="partnameid6" class="form-control" readonly="" style="display: none">
        <option></option>
      </select>
    </div>
  </td>
<!-- Drawing No. -->
<td> 
    <div class="form-material"> 
      <select name="drawingno6" id="drawingno6" class="form-control" readonly="">
        <option></option>
      </select>
    </div>
</td>
<!-- Item Remark -->
<td>   
<div class="form-material">
 <textarea class="form-control"  maxlength="100" name="remark6" rows="4" autocomplete="off" ></textarea>
</div>
</td>
<!-- hsn code -->
<td> 
<div class="form-material"> 
<select name="hsncode6" id="hsncode6" class="form-control" readonly="">
<option></option>
</select> 
</div>
</td>
<!-- Req Qty -->
<td>
<div class="form-material">
<input type="text" name="reqqty6" id="reqqty6" onkeypress="return validateFloatKeyPress(this,event);" class="form-control" autocomplete="off"/>
</div>
</td> 
<!-- Shortage by -->
<td>
<div class="form-material">
<input type="text" name="shortageby6" id="shortageby6" class="form-control" autocomplete="off"/>
</div>
</td> 
<!--PO Qty-->
<td>
<div class="form-material">
<input type="text" name="poqty6" id="poqty6" onkeypress="return validateFloatKeyPress(this,event);" oninput="seventhrow()" class="form-control qty1" autocomplete="off"/>
</div>
</td> 
<!-- Unit -->
<td> 
<div class="form-material"> 
<select name="unit6" id="unit6" class="form-control" readonly="" style="width:50px;">
<option></option>
</select>
</div>
</td>
<!-- delivery date-->
<td>
<div class="form-material">
<input type="text" name="deliverydate6" id="deliverydatepicker6" class="form-control" autocomplete="off" placeholder="dd-mm-yyyy" /></div>  
</td>
<!--unit price -->
<td>
<div class="form-material">
<input type="text" name="unitprice6" id="unitprice6" onkeypress="return validateFloatKeyPress(this,event);" oninput="seventhrow()" autocomplete="off" class="form-control qty1"/>
</div>
</td>
<!--discount -->
<td> 
<div class="form-material"> 
<div class="input-group">
<div class="input-group-prepend">
<input type="text" id="discount6" class="form-control qty1" onkeypress="return validateFloatKeyPress(this,event);" name="discount6" placeholder="0" value="0" oninput="seventhrow()" autocomplete="off">
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>
</td>
<!--tax -->
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="tax6" id="tax6" onchange="seventhrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-priceid="<?php echo htmlentities($product['id']);?>"data-pricecg="<?php echo $product['cgstvalue']; ?>" data-pricesg="<?php echo $product['sgstvalue']; ?>" data-priceig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of tax type fetch corresponding igst,cgst,sgst percentage values from tax settings -->
<div class="form-material">
<input class="form-control" id="cgstper6" name="cgstper6" style="display:none;">
<input class="form-control" id="sgstper6" name="sgstper6" style="display:none;">
<input class="form-control" id="igstper6" name="igstper6" style="display:none;">
</div>

<label style="font-size:10px;">CGST</label>&nbsp;<span id="cgstdis6"></span><br>
<label style="font-size:10px;">SGST</label>&nbsp;<span id="sgstdis6"></span><br>
<label style="font-size:10px;">IGST</label>&nbsp;<span id="igstdis6"></span>
</td>
<!--CESS --> 
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="cesstype6" id="cesstype6" onchange="seventhrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM cess_taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-pricecid="<?php echo htmlentities($product['id']);?>" data-priceccg="<?php echo $product['cgstvalue']; ?>" data-pricecsg="<?php echo $product['sgstvalue']; ?>" data-pricecig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of cess type fetch corresponding igst,cgst,sgst percentage values from cess settings -->
<div class="form-material">
<input class="form-control" id="cess_cgstper6" name="cess_cgstper6" style="display:none;">
<input class="form-control" id="cess_sgstper6" name="cess_sgstper6" style="display:none;">
<input class="form-control" id="cess_igstper6" name="cess_igstper6" style="display:none;">
<input type="text" name="cessamt6" id="cessamt6" class="form-control cessam" readonly="" style="font-weight:550;color:black;" />
</div>
</td>
<!--total price -->
<td>
<div class="form-material">  
<input type="text" name="totalprice6" id="totalprice6" class="form-control tp" style="font-weight:550;color:black;" readonly="" />

<input type="text" name="totalpr_wo_dis6" id="totalpr_wo_dis6" class="form-control" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="cgstamt6" id="cgstamt6" class="form-control cgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="sgstamt6" id="sgstamt6" class="form-control sgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="igstamt6" id="igstamt6" class="form-control igstam" style="font-weight:550;color:black;display:none;"/>

</div>  
</td>
</tr>



<!--adding details start : Row 8-->
<tr class="itemdetails">
  <td>8</td>
  <!-- Part name -->
  <td> 
    <div class="form-material">          
     <select name="partname7" id="productname7" class="form-control">
        <option>Select</option>
        <?php
        require_once("dbcontrollernew.php");
        $db_handle = new DBController();
        $query ="SELECT * FROM supplierproduct where supplierid='$supplierid' order by partname";
        $products = $db_handle->runQuery($query);
        foreach($products as $product)
        {
          ?>
          <option data-price7="<?php echo htmlentities($product['drawingno']);?>" data-price8="<?php echo htmlentities($product['partnameid']);?>" value="<?php echo $product['partnameid'];?>"><?php echo $product['partname'];?></option>
        <?php } ?>
      </select>
    </div>
    <div class="form-material"> 
      <select name="partnameid7" id="partnameid7" class="form-control" readonly="" style="display: none">
        <option></option>
      </select>
    </div>
  </td>
<!-- Drawing No. -->
<td> 
    <div class="form-material"> 
      <select name="drawingno7" id="drawingno7" class="form-control" readonly="">
        <option></option>
      </select>
    </div>
</td>
<!-- Item Remark -->
<td>   
<div class="form-material">
 <textarea class="form-control"  maxlength="100" name="remark7" rows="4" autocomplete="off" ></textarea>
</div>
</td>
<!-- hsn code -->
<td> 
<div class="form-material"> 
<select name="hsncode7" id="hsncode7" class="form-control" readonly="">
<option></option>
</select> 
</div>
</td>
<!-- Req Qty -->
<td>
<div class="form-material">
<input type="text" name="reqqty7" id="reqqty7" onkeypress="return validateFloatKeyPress(this,event);" class="form-control" autocomplete="off"/>
</div>
</td> 
<!-- Shortage by -->
<td>
<div class="form-material">
<input type="text" name="shortageby7" id="shortageby7" class="form-control" autocomplete="off"/>
</div>
</td> 
<!--PO Qty-->
<td>
<div class="form-material">
<input type="text" name="poqty7" id="poqty7" onkeypress="return validateFloatKeyPress(this,event);" oninput="eighthrow()" class="form-control qty1" autocomplete="off"/>
</div>
</td> 
<!-- Unit -->
<td> 
<div class="form-material"> 
<select name="unit7" id="unit7" class="form-control" readonly="" style="width:50px;">
<option></option>
</select>
</div>
</td>
<!-- delivery date-->
<td>
<div class="form-material">
<input type="text" name="deliverydate7" id="deliverydatepicker7" class="form-control" autocomplete="off" placeholder="dd-mm-yyyy" /></div>  
</td>
<!--unit price -->
<td>
<div class="form-material">
<input type="text" name="unitprice7" id="unitprice7" onkeypress="return validateFloatKeyPress(this,event);" oninput="eighthrow()" autocomplete="off" class="form-control qty1"/>
</div>
</td>
<!--discount -->
<td> 
<div class="form-material"> 
<div class="input-group">
<div class="input-group-prepend">
<input type="text" id="discount7" class="form-control qty1" onkeypress="return validateFloatKeyPress(this,event);" name="discount7" placeholder="0" value="0" oninput="eighthrow()" autocomplete="off">
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>
</td>
<!--tax -->
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="tax7" id="tax7" onchange="eighthrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-priceid="<?php echo htmlentities($product['id']);?>"data-pricecg="<?php echo $product['cgstvalue']; ?>" data-pricesg="<?php echo $product['sgstvalue']; ?>" data-priceig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of tax type fetch corresponding igst,cgst,sgst percentage values from tax settings -->
<div class="form-material">
<input class="form-control" id="cgstper7" name="cgstper7" style="display:none;">
<input class="form-control" id="sgstper7" name="sgstper7" style="display:none;">
<input class="form-control" id="igstper7" name="igstper7" style="display:none;">
</div>

<label style="font-size:10px;">CGST</label>&nbsp;<span id="cgstdis7"></span><br>
<label style="font-size:10px;">SGST</label>&nbsp;<span id="sgstdis7"></span><br>
<label style="font-size:10px;">IGST</label>&nbsp;<span id="igstdis7"></span>
</td>
<!--CESS --> 
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="cesstype7" id="cesstype7" onchange="eighthrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM cess_taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-pricecid="<?php echo htmlentities($product['id']);?>" data-priceccg="<?php echo $product['cgstvalue']; ?>" data-pricecsg="<?php echo $product['sgstvalue']; ?>" data-pricecig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of cess type fetch corresponding igst,cgst,sgst percentage values from cess settings -->
<div class="form-material">
<input class="form-control" id="cess_cgstper7" name="cess_cgstper7" style="display:none;">
<input class="form-control" id="cess_sgstper7" name="cess_sgstper7" style="display:none;">
<input class="form-control" id="cess_igstper7" name="cess_igstper7" style="display:none;">
<input type="text" name="cessamt7" id="cessamt7" class="form-control cessam" readonly="" style="font-weight:550;color:black;" />
</div>
</td>
<!--total price -->
<td>
<div class="form-material">  
<input type="text" name="totalprice7" id="totalprice7" class="form-control tp" style="font-weight:550;color:black;" readonly="" />

<input type="text" name="totalpr_wo_dis7" id="totalpr_wo_dis7" class="form-control" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="cgstamt7" id="cgstamt7" class="form-control cgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="sgstamt7" id="sgstamt7" class="form-control sgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="igstamt7" id="igstamt7" class="form-control igstam" style="font-weight:550;color:black;display:none;"/>

</div>  
</td> 
</tr>



<!--adding details start : Row 9-->
<tr class="itemdetails">
  <td>9</td>
  <!-- Part name -->
  <td> 
    <div class="form-material">          
     <select name="partname8" id="productname8" class="form-control">
        <option>Select</option>
        <?php
        require_once("dbcontrollernew.php");
        $db_handle = new DBController();
        $query ="SELECT * FROM supplierproduct where supplierid='$supplierid' order by partname";
        $products = $db_handle->runQuery($query);
        foreach($products as $product)
        {
          ?>
          <option data-price7="<?php echo htmlentities($product['drawingno']);?>" data-price8="<?php echo htmlentities($product['partnameid']);?>" value="<?php echo $product['partnameid'];?>"><?php echo $product['partname'];?></option>
        <?php } ?>
      </select>
    </div>
    <div class="form-material"> 
      <select name="partnameid8" id="partnameid8" class="form-control" readonly="" style="display: none">
        <option></option>
      </select>
    </div>
  </td>
<!-- Drawing No. -->
<td> 
    <div class="form-material"> 
      <select name="drawingno8" id="drawingno8" class="form-control" readonly="">
        <option></option>
      </select>
    </div>
</td>
<!-- Item Remark -->
<td>   
<div class="form-material">
 <textarea class="form-control"  maxlength="100" name="remark8" rows="4" autocomplete="off" ></textarea>
</div>
</td>
<!-- hsn code -->
<td> 
<div class="form-material"> 
<select name="hsncode8" id="hsncode8" class="form-control" readonly="">
<option></option>
</select> 
</div>
</td>
<!-- Req Qty -->
<td>
<div class="form-material">
<input type="text" name="reqqty8" id="reqqty8" onkeypress="return validateFloatKeyPress(this,event);" class="form-control" autocomplete="off"/>
</div>
</td> 
<!-- Shortage by -->
<td>
<div class="form-material">
<input type="text" name="shortageby8" id="shortageby8" class="form-control" autocomplete="off"/>
</div>
</td> 
<!--PO Qty-->
<td>
<div class="form-material">
<input type="text" name="poqty8" id="poqty8" onkeypress="return validateFloatKeyPress(this,event);" oninput="ninthrow()" class="form-control qty1" autocomplete="off"/>
</div>
</td> 
<!-- Unit -->
<td> 
<div class="form-material"> 
<select name="unit8" id="unit8" class="form-control" readonly="" style="width:50px;">
<option></option>
</select>
</div>
</td>
<!-- delivery date-->
<td>
<div class="form-material">
<input type="text" name="deliverydate8" id="deliverydatepicker8" class="form-control" autocomplete="off" placeholder="dd-mm-yyyy" /></div>  
</td>
<!--unit price -->
<td>
<div class="form-material">
<input type="text" name="unitprice8" id="unitprice8" onkeypress="return validateFloatKeyPress(this,event);" oninput="ninthrow()" autocomplete="off" class="form-control qty1"/>
</div>
</td>
<!--discount -->
<td> 
<div class="form-material"> 
<div class="input-group">
<div class="input-group-prepend">
<input type="text" id="discount8" class="form-control qty1" onkeypress="return validateFloatKeyPress(this,event);" name="discount8" placeholder="0" value="0" oninput="ninthrow()" autocomplete="off">
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>
</td>
<!--tax -->
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="tax8" id="tax8" onchange="ninthrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-priceid="<?php echo htmlentities($product['id']);?>"data-pricecg="<?php echo $product['cgstvalue']; ?>" data-pricesg="<?php echo $product['sgstvalue']; ?>" data-priceig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of tax type fetch corresponding igst,cgst,sgst percentage values from tax settings -->
<div class="form-material">
<input class="form-control" id="cgstper8" name="cgstper8" style="display:none;">
<input class="form-control" id="sgstper8" name="sgstper8" style="display:none;">
<input class="form-control" id="igstper8" name="igstper8" style="display:none;">
</div>

<label style="font-size:10px;">CGST</label>&nbsp;<span id="cgstdis8"></span><br>
<label style="font-size:10px;">SGST</label>&nbsp;<span id="sgstdis8"></span><br>
<label style="font-size:10px;">IGST</label>&nbsp;<span id="igstdis8"></span>
</td>
<!--CESS --> 
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="cesstype8" id="cesstype8" onchange="ninthrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM cess_taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-pricecid="<?php echo htmlentities($product['id']);?>" data-priceccg="<?php echo $product['cgstvalue']; ?>" data-pricecsg="<?php echo $product['sgstvalue']; ?>" data-pricecig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of cess type fetch corresponding igst,cgst,sgst percentage values from cess settings -->
<div class="form-material">
<input class="form-control" id="cess_cgstper8" name="cess_cgstper8" style="display:none;">
<input class="form-control" id="cess_sgstper8" name="cess_sgstper8" style="display:none;">
<input class="form-control" id="cess_igstper8" name="cess_igstper8" style="display:none;">
<input type="text" name="cessamt8" id="cessamt8" class="form-control cessam" readonly="" style="font-weight:550;color:black;" />
</div>
</td>
<!--total price -->
<td>
<div class="form-material">  
<input type="text" name="totalprice8" id="totalprice8" class="form-control tp" style="font-weight:550;color:black;" readonly="" />

<input type="text" name="totalpr_wo_dis8" id="totalpr_wo_dis8" class="form-control" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="cgstamt8" id="cgstamt8" class="form-control cgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="sgstamt8" id="sgstamt8" class="form-control sgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="igstamt8" id="igstamt8" class="form-control igstam" style="font-weight:550;color:black;display:none;"/>

</div>  
</td> 
</tr>



<!--adding details start : Row 10-->
<tr class="itemdetails">
  <td>10</td>
  <!-- Part name -->
  <td> 
    <div class="form-material">          
     <select name="partname9" id="productname9" class="form-control">
        <option>Select</option>
        <?php
        require_once("dbcontrollernew.php");
        $db_handle = new DBController();
        $query ="SELECT * FROM supplierproduct where supplierid='$supplierid' order by partname";
        $products = $db_handle->runQuery($query);
        foreach($products as $product)
        {
          ?>
          <option data-price7="<?php echo htmlentities($product['drawingno']);?>" data-price8="<?php echo htmlentities($product['partnameid']);?>" value="<?php echo $product['partnameid'];?>"><?php echo $product['partname'];?></option>
        <?php } ?>
      </select>
    </div>
    <div class="form-material"> 
      <select name="partnameid9" id="partnameid9" class="form-control" readonly="" style="display: none">
        <option></option>
      </select>
    </div>
  </td>
<!-- Drawing No. -->
<td> 
    <div class="form-material"> 
      <select name="drawingno9" id="drawingno9" class="form-control" readonly="">
        <option></option>
      </select>
    </div>
</td>
<!-- Item Remark -->
<td>   
<div class="form-material">
 <textarea class="form-control"  maxlength="100" name="remark9" rows="4" autocomplete="off" ></textarea>
</div>
</td>
<!-- hsn code -->
<td> 
<div class="form-material"> 
<select name="hsncode9" id="hsncode9" class="form-control" readonly="">
<option></option>
</select> 
</div>
</td>
<!-- Req Qty -->
<td>
<div class="form-material">
<input type="text" name="reqqty9" id="reqqty9" onkeypress="return validateFloatKeyPress(this,event);" class="form-control" autocomplete="off"/>
</div>
</td> 
<!-- Shortage by -->
<td>
<div class="form-material">
<input type="text" name="shortageby9" id="shortageby9" class="form-control" autocomplete="off"/>
</div>
</td> 
<!--PO Qty-->
<td>
<div class="form-material">
<input type="text" name="poqty9" id="poqty9" onkeypress="return validateFloatKeyPress(this,event);" oninput="tenthrow()" class="form-control qty1" autocomplete="off"/>
</div>
</td> 
<!-- Unit -->
<td> 
<div class="form-material"> 
<select name="unit9" id="unit9" class="form-control" readonly="" style="width:50px;">
<option></option>
</select>
</div>
</td>
<!-- delivery date-->
<td>
<div class="form-material">
<input type="text" name="deliverydate9" id="deliverydatepicker9" class="form-control" autocomplete="off" placeholder="dd-mm-yyyy" /></div>  
</td>
<!--unit price -->
<td>
<div class="form-material">
<input type="text" name="unitprice9" id="unitprice9" onkeypress="return validateFloatKeyPress(this,event);" oninput="tenthrow()" autocomplete="off" class="form-control qty1"/>
</div>
</td>
<!--discount -->
<td> 
<div class="form-material"> 
<div class="input-group">
<div class="input-group-prepend">
<input type="text" id="discount9" class="form-control qty1" onkeypress="return validateFloatKeyPress(this,event);" name="discount9" placeholder="0" value="0" oninput="tenthrow()" autocomplete="off">
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>
</td>
<!--tax -->
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="tax9" id="tax9" onchange="tenthrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-priceid="<?php echo htmlentities($product['id']);?>"data-pricecg="<?php echo $product['cgstvalue']; ?>" data-pricesg="<?php echo $product['sgstvalue']; ?>" data-priceig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of tax type fetch corresponding igst,cgst,sgst percentage values from tax settings -->
<div class="form-material">
<input class="form-control" id="cgstper9" name="cgstper9" style="display:none;">
<input class="form-control" id="sgstper9" name="sgstper9" style="display:none;">
<input class="form-control" id="igstper9" name="igstper9" style="display:none;">
</div>

<label style="font-size:10px;">CGST</label>&nbsp;<span id="cgstdis9"></span><br>
<label style="font-size:10px;">SGST</label>&nbsp;<span id="sgstdis9"></span><br>
<label style="font-size:10px;">IGST</label>&nbsp;<span id="igstdis9"></span>
</td>
<!--CESS --> 
<td>
<div class="form-material">
<div class="input-group">
<div class="input-group-prepend">
<select name="cesstype9" id="cesstype9" onchange="tenthrow()" class="form-control qtys">
<option>0</option>
<?php
require_once("dbcontrollernew.php");
$db_handle = new DBController();
$query ="SELECT * FROM cess_taxation where status='1'";
$products = $db_handle->runQuery($query);
foreach($products as $product)
{ ?>
<option data-pricecid="<?php echo htmlentities($product['id']);?>" data-priceccg="<?php echo $product['cgstvalue']; ?>" data-pricecsg="<?php echo $product['sgstvalue']; ?>" data-pricecig="<?php echo $product['igstvalue']; ?>" value="<?php echo $product['taxdesc'];?>"><?php echo $product['taxdesc'];?></option>
<?php } ?>
</select>
<span class="input-group-text" style="height:20px;padding:2px;margin-top:15px;">%</span>
</div>
</div>
</div>

<!--on select of cess type fetch corresponding igst,cgst,sgst percentage values from cess settings -->
<div class="form-material">
<input class="form-control" id="cess_cgstper9" name="cess_cgstper9" style="display:none;">
<input class="form-control" id="cess_sgstper9" name="cess_sgstper9" style="display:none;">
<input class="form-control" id="cess_igstper9" name="cess_igstper9" style="display:none;">
<input type="text" name="cessamt9" id="cessamt9" class="form-control cessam" readonly="" style="font-weight:550;color:black;" />
</div>
</td>
<!--total price -->
<td>
<div class="form-material">  
<input type="text" name="totalprice9" id="totalprice9" class="form-control tp" style="font-weight:550;color:black;" readonly="" />

<input type="text" name="totalpr_wo_dis9" id="totalpr_wo_dis9" class="form-control" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="cgstamt9" id="cgstamt9" class="form-control cgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="sgstamt9" id="sgstamt9" class="form-control sgstam" style="font-weight:550;color:black;display:none;"/>

<input type="text" name="igstamt9" id="igstamt9" class="form-control igstam" style="font-weight:550;color:black;display:none;"/>

</div>  
</td>
</tr>

<tr>
<td colspan="7" style="text-align:right;"><label>Total Quantity</label></td>
<td>
<div class="form-material">
<input type="text" name="totalquantity" id="totalquantity" class="form-control" autocomplete=off> 
</div>
</td>
<td colspan="4"></td>
<td colspan="2" style="text-align:right;"><label>Subtotal&nbsp;&nbsp;<span style="font-family: Verdana,sans-serif; font-size: 12px;">&#8377</span></label></td>
<td>
<div class="form-material">
<input type="text" id="subtotal" name="subtotal" class="form-control total amtclass" readonly="" style="text-align:right;font-weight:bold;font-size:15px;color:black;width:100px;"/>
</div>
</td>
</tr>

<tr>
<td colspan="12" rowspan="3">
<label>Terms and Conditions</label><br>
<div class="wrap">
<textarea class=" form-control" style="background-color:white;line-height:1.6;text-align:justify;margin-top:8px;max-height:90px;height:90px;resize:vertical;width:600px;" name="termsandcond" id="terms" maxlength="300"><?php echo htmlspecialchars_decode($row11['termsandcond']);?></textarea>
<span id="termscnt" class="counter"></span>
</div>
</td>
<td colspan="2" style="text-align:right;"><label>CGST Value&nbsp;&nbsp;<span style="font-family: Verdana,sans-serif; font-size: 12px;">&#8377</span></label></td>
<td>
<div class="form-material">  
<input type="text" class="form-control cgs amtclass" id="cgstvalue" name="cgstvalue" readonly="" style="text-align:right;font-weight:bold;font-size:15px;color:black;width:100px;">
</div>
</td>
</tr>
<tr>
<!-- <td colspan="12"></td> -->
<td colspan="2" style="text-align:right;"><label>SGST Value&nbsp;&nbsp;<span style="font-family: Verdana,sans-serif; font-size: 12px;">&#8377</span></label></td>
<td>
<div class="form-material">  
<input type="text" class="form-control sgs amtclass" id="sgstvalue" name="sgstvalue" readonly="" style="text-align:right;font-weight:bold;font-size:15px;color:black;width:100px;">
</div>
</td>
</tr>

<tr>
<!-- <td colspan="12"></td> -->
<td colspan="2" style="text-align:right;"><label>IGST Value&nbsp;&nbsp;<span style="font-family: Verdana,sans-serif; font-size: 12px;">&#8377</span></label></td>
<td>
<div class="form-material">  
<input type="text" class="form-control igs amtclass" id="igstvalue" name="igstvalue" readonly="" style="text-align:right;font-weight:bold;font-size:15px;color:black;width:100px;">
</div>
</td>
</tr>
<tr>
<td colspan="12" rowspan="2">
<label>Notes</label><br>
<div class="wrap">
<textarea class=" form-control" style="background-color:white;line-height: 1.6;text-align: justify;height:90px;max-height:90px;resize:vertical;width:600px;" name="notes" id="notes" maxlength="300"><?php echo htmlspecialchars_decode($row11['notes']);?></textarea>
<span id="notescnt" class="counter"></span>
</div>
</td>
<td colspan="2" style="text-align:right;"><label>Total CESS&nbsp;&nbsp;<span style="font-family: Verdana,sans-serif; font-size: 12px;">&#8377</span></label></td>
<td>
<div class="form-material">  
<input type="text" class="form-control tcess amtclass" id="totalcess" name="totalcess" readonly="" style="text-align:right;font-weight:bold;font-size:15px;color:black;width:100px;">
</div>
</td>
</tr>

<tr>
<!-- <td colspan="12"></td> -->
<td colspan="2" style="text-align:right;"><label>Round Off&nbsp;&nbsp;<span style="font-family: Verdana,sans-serif; font-size: 12px;">&#8377</span></label></td>
<td>
<div class="form-material">  
<input type="text" class="form-control amtclass" id="roundoff" name="roundoff" value="0.00" style="text-align:right;font-weight:bold;font-size:15px;color:black;width:100px;">
</div>
</td>
</tr>

<tr>
<td colspan="12">
<label>Attach File</label><br>
<input type="file" name="attachfile" id="offer33" class="form-control" onchange="return fileValidationupload4()">
</td>
<td colspan="2" style="text-align:right;"><label>Total Amount&nbsp;&nbsp;<span style="font-family: Verdana,sans-serif; font-size: 12px;">&#8377</span></label></td>
<td>
<div class="form-material">  
<input type="text" class="form-control totalamtclass" id="totalrs" name="totalrs" readonly="" style="text-align:right;font-weight:bold;font-size:15px;color:black;width:100px;">
</div>
</td>
</tr>

</tbody>
</table> 

</div>
<br>
<div class="row">
  <!-- <div class="col-md-2">
    <a id="reportprint" target="_blank"><button type="submit" class="btn btn-info"><span><i class="fa fa-print"></i>&nbsp;Preview</span></button></a>
  </div> -->
  <div class="col-xs-6 col-md-4">
    <button type="reset" class="btn btn-inverse waves-effect waves-light"  onclick="clear_form_elements(this.form)"><i class="fa fa-undo" aria-hidden="true"></i>&nbsp;Reset</button> 
  </div>
  
  <div class="col-xs-8 col-md-6">
     <button type="submit" class="btn  waves-effect waves-light"  name="addpo" onclick="return checkform()" style="background:#5BB75B;color: white;width: 140px"><i class="fa fa-floppy-o" aria-hidden="true"></i>&nbsp;Save</button> 
<!--  <input type="submit" class="btn btn-success"value="Save"  style="margin-left:50px;"><i class="fa fa-floppy-o" aria-hidden="true"></i> -->

</div>

<div class="col-xs-4 col-md-2">
 <button class="btn btn-danger waves-effect waves-light" style="margin-left:40px;"><a href="purchaseorder_viewup.php" style="color:white"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;Cancel</a></button>
</div>

</div>
<br><br>


</section>
</form> <?php } }?>


</div><!-- p 20 -->
</div> <!--tab pave active -->
</div><!--tab content -->
</div><!--card body -->
</div><!--card -->
</div><!--col 12 -->
</div><!--row -->

      <?php include("includes/footer.php"); ?>  
         
</div><!--container fluid -->
</div><!-- page wrapper -->

        <script src="assets/plugins/jquery/jquery.min.js"></script>
        <script src="main/js/jquery-ui.js"></script>
        <script src="assets/plugins/bootstrap/js/popper.min.js"></script>
        <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="main/js/jquery.slimscroll.js"></script>
        <script src="main/js/waves.js"></script>
        <script src="main/js/sidebarmenu.js"></script>
        <script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
        <script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
        <script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
        <script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
        <script src="main/js/custom.min.js"></script>
        <!--  <script src="assets/plugins/chartist-js/dist/chartist.min.js"></script>
        <script src="assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script> -->
        <script src="assets/plugins/raphael/raphael-min.js"></script>
        <script src="assets/plugins/morrisjs/morris.min.js"></script>
        <script src="assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
        <script src="assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
        <script src="assets/plugins/wizard/jquery.steps.min.js"></script>
        <script src="assets/plugins/wizard/jquery.validate.min.js"></script>
        <script src="assets/plugins/wizard/steps.js"></script>
        <script src="main/js/dashboard2.js"></script>
        <script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
<!--on select of tax type fetch corresponding igst,cgst,sgst percentage values from tax settings -->
<script type="text/javascript">
$(document).ready(function(){
$("#tax").change(function(){
var cgstper= $("option:selected", this).attr('data-pricecg');
var sgstper=$("option:selected", this).attr('data-pricesg');
var igstper=$("option:selected", this).attr('data-priceig');

$("#cgstper").val(cgstper);
$("#sgstper").val(sgstper);
$("#igstper").val(igstper);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#tax1").change(function(){
var cgstper1= $("option:selected", this).attr('data-pricecg');
var sgstper1=$("option:selected", this).attr('data-pricesg');
var igstper1=$("option:selected", this).attr('data-priceig');

$("#cgstper1").val(cgstper1);
$("#sgstper1").val(sgstper1);
$("#igstper1").val(igstper1);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#tax2").change(function(){
var cgstper2= $("option:selected", this).attr('data-pricecg');
var sgstper2=$("option:selected", this).attr('data-pricesg');
var igstper2=$("option:selected", this).attr('data-priceig');

$("#cgstper2").val(cgstper2);
$("#sgstper2").val(sgstper2);
$("#igstper2").val(igstper2);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#tax3").change(function(){
var cgstper3= $("option:selected", this).attr('data-pricecg');
var sgstper3=$("option:selected", this).attr('data-pricesg');
var igstper3=$("option:selected", this).attr('data-priceig');

$("#cgstper3").val(cgstper3);
$("#sgstper3").val(sgstper3);
$("#igstper3").val(igstper3);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#tax4").change(function(){
var cgstper4= $("option:selected", this).attr('data-pricecg');
var sgstper4=$("option:selected", this).attr('data-pricesg');
var igstper4=$("option:selected", this).attr('data-priceig');

$("#cgstper4").val(cgstper4);
$("#sgstper4").val(sgstper4);
$("#igstper4").val(igstper4);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#tax5").change(function(){
var cgstper5= $("option:selected", this).attr('data-pricecg');
var sgstper5=$("option:selected", this).attr('data-pricesg');
var igstper5=$("option:selected", this).attr('data-priceig');

$("#cgstper5").val(cgstper5);
$("#sgstper5").val(sgstper5);
$("#igstper5").val(igstper5);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#tax6").change(function(){
var cgstper6= $("option:selected", this).attr('data-pricecg');
var sgstper6=$("option:selected", this).attr('data-pricesg');
var igstper6=$("option:selected", this).attr('data-priceig');

$("#cgstper6").val(cgstper6);
$("#sgstper6").val(sgstper6);
$("#igstper6").val(igstper6);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#tax7").change(function(){
var cgstper7= $("option:selected", this).attr('data-pricecg');
var sgstper7=$("option:selected", this).attr('data-pricesg');
var igstper7=$("option:selected", this).attr('data-priceig');

$("#cgstper7").val(cgstper7);
$("#sgstper7").val(sgstper7);
$("#igstper7").val(igstper7);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#tax8").change(function(){
var cgstper8= $("option:selected", this).attr('data-pricecg');
var sgstper8=$("option:selected", this).attr('data-pricesg');
var igstper8=$("option:selected", this).attr('data-priceig');

$("#cgstper8").val(cgstper8);
$("#sgstper8").val(sgstper8);
$("#igstper8").val(igstper8);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#tax9").change(function(){
var cgstper9= $("option:selected", this).attr('data-pricecg');
var sgstper9=$("option:selected", this).attr('data-pricesg');
var igstper9=$("option:selected", this).attr('data-priceig');

$("#cgstper9").val(cgstper9);
$("#sgstper9").val(sgstper9);
$("#igstper9").val(igstper9);

});
});
</script>
<!--END OF FETCHING TAX VALUES  -->



<!--on select of cess type fetching cgst,sgst and igst value for corresponding cess type from cess settings start -->
<script type="text/javascript">
$(document).ready(function(){
$("#cesstype").change(function(){
var cess_cgstper= $("option:selected", this).attr('data-priceccg');
var cess_sgstper=$("option:selected", this).attr('data-pricecsg');
var cess_igstper=$("option:selected", this).attr('data-pricecig');

$("#cess_cgstper").val(cess_cgstper);
$("#cess_sgstper").val(cess_sgstper);
$("#cess_igstper").val(cess_igstper);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#cesstype1").change(function(){
var cess_cgstper1= $("option:selected", this).attr('data-priceccg');
var cess_sgstper1=$("option:selected", this).attr('data-pricecsg');
var cess_igstper1=$("option:selected", this).attr('data-pricecig');

$("#cess_cgstper1").val(cess_cgstper1);
$("#cess_sgstper1").val(cess_sgstper1);
$("#cess_igstper1").val(cess_igstper1);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#cesstype2").change(function(){
var cess_cgstper2= $("option:selected", this).attr('data-priceccg');
var cess_sgstper2=$("option:selected", this).attr('data-pricecsg');
var cess_igstper2=$("option:selected", this).attr('data-pricecig');

$("#cess_cgstper2").val(cess_cgstper2);
$("#cess_sgstper2").val(cess_sgstper2);
$("#cess_igstper2").val(cess_igstper2);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#cesstype3").change(function(){
var cess_cgstper3= $("option:selected", this).attr('data-priceccg');
var cess_sgstper3=$("option:selected", this).attr('data-pricecsg');
var cess_igstper3=$("option:selected", this).attr('data-pricecig');

$("#cess_cgstper3").val(cess_cgstper3);
$("#cess_sgstper3").val(cess_sgstper3);
$("#cess_igstper3").val(cess_igstper3);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#cesstype4").change(function(){
var cess_cgstper4= $("option:selected", this).attr('data-priceccg');
var cess_sgstper4=$("option:selected", this).attr('data-pricecsg');
var cess_igstper4=$("option:selected", this).attr('data-pricecig');

$("#cess_cgstper4").val(cess_cgstper4);
$("#cess_sgstper4").val(cess_sgstper4);
$("#cess_igstper4").val(cess_igstper4);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#cesstype5").change(function(){
var cess_cgstper5= $("option:selected", this).attr('data-priceccg');
var cess_sgstper5=$("option:selected", this).attr('data-pricecsg');
var cess_igstper5=$("option:selected", this).attr('data-pricecig');

$("#cess_cgstper5").val(cess_cgstper5);
$("#cess_sgstper5").val(cess_sgstper5);
$("#cess_igstper5").val(cess_igstper5);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#cesstype6").change(function(){
var cess_cgstper6= $("option:selected", this).attr('data-priceccg');
var cess_sgstper6=$("option:selected", this).attr('data-pricecsg');
var cess_igstper6=$("option:selected", this).attr('data-pricecig');

$("#cess_cgstper6").val(cess_cgstper6);
$("#cess_sgstper6").val(cess_sgstper6);
$("#cess_igstper6").val(cess_igstper6);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#cesstype7").change(function(){
var cess_cgstper7= $("option:selected", this).attr('data-priceccg');
var cess_sgstper7=$("option:selected", this).attr('data-pricecsg');
var cess_igstper7=$("option:selected", this).attr('data-pricecig');

$("#cess_cgstper7").val(cess_cgstper7);
$("#cess_sgstper7").val(cess_sgstper7);
$("#cess_igstper7").val(cess_igstper7);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#cesstype8").change(function(){
var cess_cgstper8= $("option:selected", this).attr('data-priceccg');
var cess_sgstper8=$("option:selected", this).attr('data-pricecsg');
var cess_igstper8=$("option:selected", this).attr('data-pricecig');

$("#cess_cgstper8").val(cess_cgstper8);
$("#cess_sgstper8").val(cess_sgstper8);
$("#cess_igstper8").val(cess_igstper8);

});
});
</script>

<script type="text/javascript">
$(document).ready(function(){
$("#cesstype9").change(function(){
var cess_cgstper9= $("option:selected", this).attr('data-priceccg');
var cess_sgstper9=$("option:selected", this).attr('data-pricecsg');
var cess_igstper9=$("option:selected", this).attr('data-pricecig');

$("#cess_cgstper9").val(cess_cgstper9);
$("#cess_sgstper9").val(cess_sgstper9);
$("#cess_igstper9").val(cess_igstper9);

});
});
</script>
<!--CESS VALUES FETCH END -->

<!--filter partname on change of customer name -->
<script>
  $('#category-list').on('change', function(){
    var productname = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'productname='+productname,
      success: function(result){
        $("#productname").html(result);
      }
    });
  });
</script>

<script>
  $('#productname').on('change', function(){
    var partnameid = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'partnameid='+partnameid,
      success: function(result){
        $("#partnameid").html(result);
      }
    });
  });
</script>

<script>
  $('#productname').on('change', function(){
    var drawingno = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'drawingno='+drawingno,
      success: function(result){
        $("#drawingno").html(result);
      }
    });
  });
</script>

<!-- Table Row :2 -->
<script>
  $('#category-list').on('change', function(){
    var productname = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'productname='+productname,
      success: function(result){
        $("#productname1").html(result);
      }
    });
  });
</script>
<script>
  $('#productname1').on('change', function(){
    var partnameid = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'partnameid='+partnameid,
      success: function(result){
        $("#partnameid1").html(result);
      }
    });
  });
</script>

<script>
  $('#productname1').on('change', function(){
    var drawingno = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'drawingno='+drawingno,
      success: function(result){
        $("#drawingno1").html(result);
      }
    });
  });
</script>
<!-- Table Row :3 -->
<script>
  $('#category-list').on('change', function(){
    var productname = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'productname='+productname,
      success: function(result){
        $("#productname2").html(result);
      }
    });
  });
</script>
<script>
  $('#productname2').on('change', function(){
    var partnameid = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'partnameid='+partnameid,
      success: function(result){
        $("#partnameid2").html(result);
      }
    });
  });
</script>

<script>
  $('#productname2').on('change', function(){
    var drawingno = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'drawingno='+drawingno,
      success: function(result){
        $("#drawingno2").html(result);
      }
    });
  });
</script>
<!-- Table Row :4 -->
<script>
  $('#category-list').on('change', function(){
    var productname = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'productname='+productname,
      success: function(result){
        $("#productname3").html(result);
      }
    });
  });
</script>
<script>
  $('#productname3').on('change', function(){
    var partnameid = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'partnameid='+partnameid,
      success: function(result){
        $("#partnameid3").html(result);
      }
    });
  });
</script>

<script>
  $('#productname3').on('change', function(){
    var drawingno = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'drawingno='+drawingno,
      success: function(result){
        $("#drawingno3").html(result);
      }
    });
  });
</script>
<!-- Table Row :5 -->
<script>
  $('#category-list').on('change', function(){
    var productname = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'productname='+productname,
      success: function(result){
        $("#productname4").html(result);
      }
    });
  });
</script>
<script>
  $('#productname4').on('change', function(){
    var partnameid = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'partnameid='+partnameid,
      success: function(result){
        $("#partnameid4").html(result);
      }
    });
  });
</script>

<script>
  $('#productname4').on('change', function(){
    var drawingno = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'drawingno='+drawingno,
      success: function(result){
        $("#drawingno4").html(result);
      }
    });
  });
</script>
<!-- Table Row :6 -->
<script>
  $('#category-list').on('change', function(){
    var productname = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'productname='+productname,
      success: function(result){
        $("#productname5").html(result);
      }
    });
  });
</script>
<script>
  $('#productname5').on('change', function(){
    var partnameid = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'partnameid='+partnameid,
      success: function(result){
        $("#partnameid5").html(result);
      }
    });
  });
</script>

<script>
  $('#productname5').on('change', function(){
    var drawingno = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'drawingno='+drawingno,
      success: function(result){
        $("#drawingno5").html(result);
      }
    });
  });
</script>
<!-- Table Row :7 -->
<script>
  $('#category-list').on('change', function(){
    var productname = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'productname='+productname,
      success: function(result){
        $("#productname6").html(result);
      }
    });
  });
</script>
<script>
  $('#productname6').on('change', function(){
    var partnameid = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'partnameid='+partnameid,
      success: function(result){
        $("#partnameid6").html(result);
      }
    });
  });
</script>

<script>
  $('#productname6').on('change', function(){
    var drawingno = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'drawingno='+drawingno,
      success: function(result){
        $("#drawingno6").html(result);
      }
    });
  });
</script>
<!-- Table Row :8 -->
<script>
  $('#category-list').on('change', function(){
    var productname = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'productname='+productname,
      success: function(result){
        $("#productname7").html(result);
      }
    });
  });
</script>
<script>
  $('#productname7').on('change', function(){
    var partnameid = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'partnameid='+partnameid,
      success: function(result){
        $("#partnameid7").html(result);
      }
    });
  });
</script>

<script>
  $('#productname7').on('change', function(){
    var drawingno = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'drawingno='+drawingno,
      success: function(result){
        $("#drawingno7").html(result);
      }
    });
  });
</script>
<!-- Table Row :9 -->
<script>
  $('#category-list').on('change', function(){
    var productname = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'productname='+productname,
      success: function(result){
        $("#productname8").html(result);
      }
    });
  });
</script>
<script>
  $('#productname8').on('change', function(){
    var partnameid = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'partnameid='+partnameid,
      success: function(result){
        $("#partnameid8").html(result);
      }
    });
  });
</script>

<script>
  $('#productname8').on('change', function(){
    var drawingno = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'drawingno='+drawingno,
      success: function(result){
        $("#drawingno8").html(result);
      }
    });
  });
</script>
<!-- Table Row :10 -->
<script>
  $('#category-list').on('change', function(){
    var productname = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'productname='+productname,
      success: function(result){
        $("#productname9").html(result);
      }
    });
  });
</script>
<script>
  $('#productname9').on('change', function(){
    var partnameid = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'partnameid='+partnameid,
      success: function(result){
        $("#partnameid9").html(result);
      }
    });
  });
</script>

<script>
  $('#productname9').on('change', function(){
    var drawingno = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'drawingno='+drawingno,
      success: function(result){
        $("#drawingno9").html(result);
      }
    });
  });
</script>

<!--details of supllier billing address start -->


<!--fetching gst no. of -->
<script>
  $('#category-list').on('change', function(){
    var gstin = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'gstin='+gstin,
      success: function(result){
        $("#gstin").html(result);
      }
    });
  });
</script>
<!--fetching email of supplier -->
<script>
  $('#category-list').on('change', function(){
    var email = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'email='+email,
      success: function(result){
        $("#email").html(result);
      }
    });
  });
</script>
<!--fetching contact no. of supplier-->
<script>
  $('#category-list').on('change', function(){
    var contactno = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'contactno='+contactno,
      success: function(result){
        $("#contactno").html(result);
      }
    });
  });
</script>

<!--fetching payment term of supplier -->
<script>
  $('#category-list').on('change', function(){
    var paymentterm = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'paymentterm='+paymentterm,
      success: function(result){
        $("#paymentterm").html(result);
      }
    });
  });
</script>

<!--fetching vendor code of supplier -->
<script>
  $('#category-list').on('change', function(){
    var vendorcode = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'vendorcode='+vendorcode,
      success: function(result){
        $("#vendorcode").html(result);
      }
    });
  });
</script>


<!--fetching address1 of supplier billing address-->
<script>
  $('#category-list').on('change', function(){
    var country_id = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'country_id='+country_id,
      success: function(result){
        $("#officeaddress2").html(result);
      }
    });
  });
</script>
<!--fetching address2,address3 of supplier billing address-->
<script>
  $('#category-list').on('change', function(){
    var country_id1 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'country_id1='+country_id1,
      success: function(result){
        $("#officeaddress3").html(result);
      }
    });
  });
</script>
<!--fetching city,district,pincode of supplier billing address-->
<script>
  $('#category-list').on('change', function(){
    var office4 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'office4='+office4,
      success: function(result){
        $("#officeaddress4").html(result);
      }
    });
  });
</script>
<!--fetching state and country of supplier billing address-->
<script>
  $('#category-list').on('change', function(){
    var office5 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'office5='+office5,
      success: function(result){
        $("#officeaddress5").html(result);
      }
    });
  });
</script>
<!--fetching address1 of supplier billing address(if sameasbill is checked)-->
<script>
  $('#category-list').on('change', function(){
    var country_id2 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'country_id2='+country_id2,
      success: function(result){
        $("#shipadd1").html(result);
      }
    });
  });
</script>
<!--fetching address2,address3 of supplier billing address(if sameasbill is checked)-->
<script>
  $('#category-list').on('change', function(){
    var country_id3 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'country_id3='+country_id3,
      success: function(result){
        $("#shipadd2").html(result);
      }
    });
  });
</script>
<!--fetching city,district,pincode of supplier billing address(if sameasbill is checked)-->
<script>
  $('#category-list').on('change', function(){
    var shipadd3 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'shipadd3='+shipadd3,
      success: function(result){
        $("#shipadd3").html(result);
      }
    });
  });
</script>
<!--fetching state and country of supplier billing address(if sameasbill is checked)-->
<script>
  $('#category-list').on('change', function(){
    var shipadd4 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'shipadd4='+shipadd4,
      success: function(result){
        $("#shipadd4").html(result);
      }
    });
  });
</script>
<!--details of supplier billing address end -->


<!--fetching supplier shipping address details start-->
<!--filter shipping type on change of supplier name -->
<!-- <script>
  $('#category-list').on('change', function(){
    var shippingtypeid = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'shippingtypeid='+shippingtypeid,
      success: function(result){
        $("#shippingtypeid").html(result);
      }
    });
  });
</script> -->
<!-- fetching company name from supplier shipping address -->
<script>
  $('#shippingtypeid').on('change', function(){
    var ship15 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'ship15='+ship15,
      success: function(result){
        $("#ship15").html(result);
      }
    });
  });
</script>
<!-- fetching address1 from supplier shipping address -->
<script>
  $('#shippingtypeid').on('change', function(){
    var ship11 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'ship11='+ship11,
      success: function(result){
        $("#ship11").html(result);
      }
    });
  });
</script>
<!-- fetching address2 from supplier shipping address -->
<script>
  $('#shippingtypeid').on('change', function(){
    var ship12 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'ship12='+ship12,
      success: function(result){
        $("#ship12").html(result);
      }
    });
  });
</script>
<!-- fetching city and pincode from supplier shipping address -->
<script>
  $('#shippingtypeid').on('change', function(){
    var ship13 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'ship13='+ship13,
      success: function(result){
        $("#ship13").html(result);
      }
    });
  });
</script>
<!-- fetching state and country from supplier shipping address -->
<script>
  $('#shippingtypeid').on('change', function(){
    var ship14 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'ship14='+ship14,
      success: function(result){
        $("#ship14").html(result);
      }
    });
  });
</script>
<!-- fetching gstno. from supplier shipping address -->
<script>
  $('#shippingtypeid').on('change', function(){
    var ship16 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'ship16='+ship16,
      success: function(result){
        $("#ship16").html(result);
      }
    });
  });
</script>

<!-- fetch autoinc id from supplier_address table -->
<script>
  $('#shippingtypeid').on('change', function(){
    var ssid = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'ssid='+ssid,
      success: function(result){
        $("#ssid").html(result);
      }
    });
  });
</script>

<!--fetching supplier shipping address details end-->


<!--fetching hsncode and unit onselect of partname start-->
<!-- 1st row-->
<script>
  $('#productname').on('change', function(){
    var hsncode = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'hsncode='+hsncode,
      success: function(result){
        $("#hsncode").html(result);
      }
    });
  });
</script>
<script>
  $('#productname').on('change', function(){
    var unit = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'unit='+unit,
      success: function(result){
        $("#unit").html(result);
      }
    });
  });
</script>
<!--for 2nd row -->
<script>
  $('#productname1').on('change', function(){
    var hsncode1 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'hsncode1='+hsncode1,
      success: function(result){
        $("#hsncode1").html(result);
      }
    });
  });
</script>
<script>
  $('#productname1').on('change', function(){
    var unit1 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'unit1='+unit1,
      success: function(result){
        $("#unit1").html(result);
      }
    });
  });
</script>
<!--for 3rd row -->
<script>
  $('#productname2').on('change', function(){
    var hsncode2 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'hsncode2='+hsncode2,
      success: function(result){
        $("#hsncode2").html(result);
      }
    });
  });
</script>
<script>
  $('#productname2').on('change', function(){
    var unit2 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'unit2='+unit2,
      success: function(result){
        $("#unit2").html(result);
      }
    });
  });
</script>
<!--for 4th row -->
<script>
  $('#productname3').on('change', function(){
    var hsncode3 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'hsncode3='+hsncode3,
      success: function(result){
        $("#hsncode3").html(result);
      }
    });
  });
</script>
<script>
  $('#productname3').on('change', function(){
    var unit3 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'unit3='+unit3,
      success: function(result){
        $("#unit3").html(result);
      }
    });
  });
</script>
<!--for 5th row -->
<script>
  $('#productname4').on('change', function(){
    var hsncode4 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'hsncode4='+hsncode4,
      success: function(result){
        $("#hsncode4").html(result);
      }
    });
  });
</script>
<script>
  $('#productname4').on('change', function(){
    var unit4 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'unit4='+unit4,
      success: function(result){
        $("#unit4").html(result);
      }
    });
  });
</script>
<!--for 6th row -->
<script>
  $('#productname5').on('change', function(){
    var hsncode5 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'hsncode5='+hsncode5,
      success: function(result){
        $("#hsncode5").html(result);
      }
    });
  });
</script>
<script>
  $('#productname5').on('change', function(){
    var unit5 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'unit5='+unit5,
      success: function(result){
        $("#unit5").html(result);
      }
    });
  });
</script>
<!--for 7th row -->
<script>
  $('#productname6').on('change', function(){
    var hsncode6 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'hsncode6='+hsncode6,
      success: function(result){
        $("#hsncode6").html(result);
      }
    });
  });
</script>
<script>
  $('#productname6').on('change', function(){
    var unit6 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'unit6='+unit6,
      success: function(result){
        $("#unit6").html(result);
      }
    });
  });
</script>
<!--for 8th row -->
<script>
  $('#productname7').on('change', function(){
    var hsncode7 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'hsncode7='+hsncode7,
      success: function(result){
        $("#hsncode7").html(result);
      }
    });
  });
</script>
<script>
  $('#productname7').on('change', function(){
    var unit7 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'unit7='+unit7,
      success: function(result){
        $("#unit7").html(result);
      }
    });
  });
</script>
<!--for 9th row -->
<script>
  $('#productname8').on('change', function(){
    var hsncode8 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'hsncode8='+hsncode8,
      success: function(result){
        $("#hsncode8").html(result);
      }
    });
  });
</script>
<script>
  $('#productname8').on('change', function(){
    var unit8 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'unit8='+unit8,
      success: function(result){
        $("#unit8").html(result);
      }
    });
  });
</script>
<!--for 10th row -->
<script>
  $('#productname9').on('change', function(){
    var hsncode9 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'hsncode9='+hsncode9,
      success: function(result){
        $("#hsncode9").html(result);
      }
    });
  });
</script>
<script>
  $('#productname9').on('change', function(){
    var unit9 = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getsupplier.php",
      data:'unit9='+unit9,
      success: function(result){
        $("#unit9").html(result);
      }
    });
  });
</script>
<!--fetching hsncode and unit onselect of partname end-->

<!--fetch total rate(unitprice) from supplierrc table on select of partname -->
<script>
  $('#productname').on('change', function(){
    var unitprice = this.value;
    $.ajax({
      type: "POST",
      url: "purchaseorder_getunitprice.php",
      data:'unitprice='+unitprice,
      success: function(result){
        $("#unitprice").val(result);
      }
    });
  });
</script>

<script type="text/javascript">
$(document).ready(function(){
$('#basic_checkbox_2').change(function(){
if(this.checked)
{

  document.getElementById("autoUpdate").style.display="block";
  document.getElementById("ship").style.display="none";
}
else
{
  
  document.getElementById("autoUpdate").style.display="none";
  document.getElementById("ship").style.display="block";
// $('#autoUpdate').fadeIn('slow'); 
}  
});
});
</script>

<script type="text/javascript">
$(document).ready(function()
{

var same = document.getElementById('basic_checkbox_2')
if(same.checked==false)
{

  document.getElementById("autoUpdate").style.display="none";
  document.getElementById("ship").style.display="block";
}
if(same.checked==true)
{

  document.getElementById("autoUpdate").style.display="block";
  document.getElementById("ship").style.display="none";
}
});
</script>



     
<script type="text/javascript">
var el_t = document.getElementById('terms');
var length = el_t.getAttribute("maxlength");
var el_c = document.getElementById('termscnt');
var totallength=el_t.value;
 document.getElementById('termscnt').innerHTML=(length-totallength.length);
//el_c.innerHTML = length;
el_t.onkeyup = function () 
{
  document.getElementById('termscnt').innerHTML = (length - this.value.length);
};
</script>

<script type="text/javascript">
var el_t = document.getElementById('notes');
var length = el_t.getAttribute("maxlength");
var el_c = document.getElementById('notescnt');
var totallength=el_t.value;
 document.getElementById('notescnt').innerHTML=(length-totallength.length);
//el_c.innerHTML = length;
el_t.onkeyup = function () 
{
  document.getElementById('notescnt').innerHTML = (length - this.value.length);
};
</script>

<script>
$('.li-modal').on('click', function(e){
e.preventDefault();
$('#theModal').modal('show').find('.modal-content').load($(this).attr('href'));
});
</script>


<!-- restricting user input to only 2 numbers after decimal point -->
<script type="text/javascript">
function validateFloatKeyPress(el, evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    var number = el.value.split('.');
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    //just one dot
    if(number.length>1 && charCode == 46){
         return false;
    }
    //get the carat position
    var caratPos = getSelectionStart(el);
    var dotPos = el.value.indexOf(".");
    if( caratPos > dotPos && dotPos>-1 && (number[1].length > 1)){
        return false;
    }
    return true;
}

//thanks: http://javascript.nwbox.com/cursor_position/
function getSelectionStart(o) {
  if (o.createTextRange) {
    var r = document.selection.createRange().duplicate()
    r.moveEnd('character', o.value.length)
    if (r.text == '') return o.value.length
    return o.value.lastIndexOf(r.text)
  } else return o.selectionStart
}
</script>

        <!-- script for dropdown with search box -->
        <script type="text/javascript">
          jQuery(document).ready(function() {
            // Switchery
            var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
            $('.js-switch').each(function() {
              new Switchery($(this)[0], $(this).data());
            });
            // For select 2
            $(".select2").select2();
            $('.selectpicker').selectpicker();
            //Bootstrap-TouchSpin
            $(".vertical-spin").TouchSpin({
              verticalbuttons: true,
              verticalupclass: 'ti-plus',
              verticaldownclass: 'ti-minus'
            });
            var vspinTrue = $(".vertical-spin").TouchSpin({
              verticalbuttons: true
            });
            if (vspinTrue) {
              $('.vertical-spin').prev('.bootstrap-touchspin-prefix').remove();
            }
            $("input[name='tch1']").TouchSpin({
              min: 0,
              max: 100,
              step: 0.1,
              decimals: 2,
              boostat: 5,
              maxboostedstep: 10,
              postfix: '%'
            });
            $("input[name='tch2']").TouchSpin({
              min: -1000000000,
              max: 1000000000,
              stepinterval: 50,
              maxboostedstep: 10000000,
              prefix: '$'
            });
            $("input[name='tch3']").TouchSpin();
            $("input[name='tch3_22']").TouchSpin({
              initval: 40
            });
            $("input[name='tch5']").TouchSpin({
              prefix: "pre",
              postfix: "post"
            });
            // For multiselect
            $('#pre-selected-options').multiSelect();
            $('#optgroup').multiSelect({
              selectableOptgroup: true
            });
            $('#public-methods').multiSelect();
            $('#select-all').click(function() {
              $('#public-methods').multiSelect('select_all');
              return false;
            });
            $('#deselect-all').click(function() {
              $('#public-methods').multiSelect('deselect_all');
              return false;
            });
            $('#refresh').on('click', function() {
              $('#public-methods').multiSelect('refresh');
              return false;
            });
            $('#add-option').on('click', function() {
              $('#public-methods').multiSelect('addOption', {
                value: 42,
                text: 'test 42',
                index: 0
              });
              return false;
            });
            $(".ajax").select2({
              ajax: {
                url: "https://api.github.com/search/repositories",
                dataType: 'json',
                delay: 250,
                data: function(params) {
                  return {
                    q: params.term, // search term
                    page: params.page
                  };
                },
                processResults: function(data, params) {
                  // parse the results into the format expected by Select2
                  // since we are using custom formatting functions we do not need to
                  // alter the remote JSON data, except to indicate that infinite
                  // scrolling can be used
                  params.page = params.page || 1;
                  return {
                    results: data.items,
                    pagination: {
                      more: (params.page * 30) < data.total_count
                    }
                  };
                },
                cache: true
              },
              escapeMarkup: function(markup) {
                return markup;
              }, // let our custom formatter work
              minimumInputLength: 1,
              //templateResult: formatRepo, // omitted for brevity, see the source of this page
              //templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
            });
          });

        </script>
  <script>
  // To Reset all the fields like Text, TextArea, File, Select, Password, RadioButton and Checkbox that were filled   
        $('button[type="reset"]').click(function(e) {
          $my-form = $(this.form);
          $my-form.find('input:text, input:password, input:file, select, textarea').val('');
          $my-form.find('input:radio, input:checkbox').removeAttr('checked').removeAttr('selected');
          e.preventDefault();
        }); 
  </script>
  <script>  
  // To Reset Select2 options that are fetched by AJAX    
        $('button[type="reset"]').click(function(e) {
        $(document).ready(function(){
          $(".select2").select2({
              placeholder: "Select",
              allowClear: true
              });
                $('#ship15').empty();  
                $('#ship11').empty();
                $('#ship12').empty();  
                $('#ship13').empty();
                $('#ship14').empty();
                $('#ship16').empty(); 

                $('#vendorcode').empty();
                $('#paymentterm').empty(); 

                $('#drawingno').empty();  
                $('#drawingno1').empty();
                $('#drawingno2').empty();  
                $('#drawingno3').empty();
                $('#drawingno4').empty();
                $('#drawingno5').empty();  
                $('#drawingno6').empty();
                $('#drawingno7').empty();  
                $('#drawingno8').empty();
                $('#drawingno9').empty();

                $('#hsncode').empty();  
                $('#hsncode1').empty();
                $('#hsncode2').empty();  
                $('#hsncode3').empty();
                $('#hsncode4').empty();
                $('#hsncode5').empty();  
                $('#hsncode6').empty();
                $('#hsncode7').empty();  
                $('#hsncode8').empty();
                $('#hsncode9').empty();

                $('#unit').empty();  
                $('#unit1').empty();
                $('#unit2').empty();  
                $('#unit3').empty();
                $('#unit4').empty();
                $('#unit5').empty();  
                $('#unit6').empty();
                $('#unit7').empty();  
                $('#unit8').empty();
                $('#unit9').empty();
              }); 
          });
  </script>

        <script src="assets/plugins/switchery/dist/switchery.min.js"></script>
        <script src="assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
        <script src="assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
        <script src="assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
        <script src="assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js" type="text/javascript"></script>
        <script src="assets/plugins/dff/dff.js" type="text/javascript"></script>
        <script type="text/javascript" src="assets/plugins/multiselect/js/jquery.multi-select.js"></script>
        <script src="assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
        <script src="assets/plugins/html5-editor/wysihtml5-0.3.0.js"></script>
        <script src="assets/plugins/html5-editor/bootstrap-wysihtml5.js"></script>
        <link rel="stylesheet" href="assets/plugins/html5-editor/bootstrap-wysihtml5.css">
  <script src="assets/plugins/moment/moment.js"></script>
  <script src="assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>



<!--calculation of total price ,igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
function rowcalculate() 
{
    var unitpr = document.getElementById('unitprice').value;   //15
    var qty = document.getElementById('poqty').value;  //2
    var discnt = document.getElementById('discount').value;  //2%
    var result = document.getElementById('result'); 
    
    var cgstper = document.getElementById('cgstper').value;
    var sgstper = document.getElementById('sgstper').value;
    var igstper = document.getElementById('igstper').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('result2').value = z11;
 
    if(discnt!='0')
    {
      result.value = fg4; 

      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt').value = cgstamt3;
      document.getElementById("cgstdis").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt').value = sgstamt3;
      document.getElementById("sgstdis").innerHTML = sgstamt3;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt').value = igstamt3;
      document.getElementById("igstdis").innerHTML = igstamt3;

    }
    if(discnt=='0')
    {
        var z=qty2;
        var z1=z.toFixed(2);
        result.value = z1;

        var cgstamt=qty2*cgstper;
        var cgstamt2=cgstamt/100;
        var cgstamt3=cgstamt2.toFixed(2);
        document.getElementById('cgstamt').value = cgstamt3;
        document.getElementById("cgstdis").innerHTML = cgstamt3;

        var sgstamt=qty2*sgstper;
        var sgstamt2=sgstamt/100;
        var sgstamt3=sgstamt2.toFixed(2);
        document.getElementById('sgstamt').value = sgstamt3;
        document.getElementById("sgstdis").innerHTML = sgstamt3;

        var igstamt=qty2*igstper;
        var igstamt2=igstamt/100;
        var igstamt3=igstamt2.toFixed(2);
        document.getElementById('igstamt').value = igstamt3;
        document.getElementById("igstdis").innerHTML = igstamt3;
    } 
    var cess_cgstper = document.getElementById('cess_cgstper').value;
    var cess_sgstper = document.getElementById('cess_sgstper').value;
    var cess_igstper = document.getElementById('cess_igstper').value;
    
    var cgstamt = document.getElementById('cgstamt').value;
    var sgstamt = document.getElementById('sgstamt').value;
    var igstamt = document.getElementById('igstamt').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt').value=cgst_cessamt3;
    }
 
}
</script>

<!--onchange of tax type calculating igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
$(document).ready(function(){
$('#tax').on('change', function(){
    var unitpr = document.getElementById('unitprice').value;   
    var qty = document.getElementById('poqty').value;
    var discnt = document.getElementById('discount').value;  
    var result = document.getElementById('result').value;; 

    var cgstper = document.getElementById('cgstper').value;
    var sgstper = document.getElementById('sgstper').value;
    var igstper = document.getElementById('igstper').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('result2').value = z11;

    if(discnt!='0')
    {
      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt').value = cgstamt3;
      document.getElementById("cgstdis").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt').value = sgstamt3;
      document.getElementById("sgstdis").innerHTML = sgstamt3; ;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt').value = igstamt3;
      document.getElementById("igstdis").innerHTML = igstamt3; ;
    }
    if(discnt=='0')
    {
      var cgstamt=qty2*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt').value = cgstamt3;
      document.getElementById("cgstdis").innerHTML = cgstamt3;

      var sgstamt=qty2*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt').value = sgstamt3;
      document.getElementById("sgstdis").innerHTML = sgstamt3;

      var igstamt=qty2*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt').value = igstamt3;
      document.getElementById("igstdis").innerHTML = igstamt3;
    }

    var cess_cgstper = document.getElementById('cess_cgstper').value;
    var cess_sgstper = document.getElementById('cess_sgstper').value;
    var cess_igstper = document.getElementById('cess_igstper').value;
    
    var cgstamt = document.getElementById('cgstamt').value;
    var sgstamt = document.getElementById('sgstamt').value;
    var igstamt = document.getElementById('igstamt').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt').value=cgst_cessamt3;
    }
   
});
});
</script>
<!--onchange of CESS type calculating CESS amount -->
<script type="text/javascript">
$(document).ready(function(){
$('#cesstype').on('change', function(){
  
    var cess_cgstper = document.getElementById('cess_cgstper').value;
    var cess_sgstper = document.getElementById('cess_sgstper').value;
    var cess_igstper = document.getElementById('cess_igstper').value;
    
    var cgstamt = document.getElementById('cgstamt').value;
    var sgstamt = document.getElementById('sgstamt').value;
    var igstamt = document.getElementById('igstamt').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt').value=cgst_cessamt3;
    }
   
});
});
</script>

<!--calculation of total price ,igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
function secondrow() 
{
    var unitpr = document.getElementById('unitprice1').value;   //15
    var qty = document.getElementById('poqty1').value;  //2
    var discnt = document.getElementById('discount1').value;  //2%
    var result = document.getElementById('result1'); 
    
    var cgstper = document.getElementById('cgstper1').value;
    var sgstper = document.getElementById('sgstper1').value;
    var igstper = document.getElementById('igstper1').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('result21').value = z11;
 
    if(discnt!='0')
    {
      result.value = fg4; 

      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt1').value = cgstamt3;
      document.getElementById("cgstdis1").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt1').value = sgstamt3;
      document.getElementById("sgstdis1").innerHTML = sgstamt3;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt1').value = igstamt3;
      document.getElementById("igstdis1").innerHTML = igstamt3;

    }
    if(discnt=='0')
    {
        var z=qty2;
        var z1=z.toFixed(2);
        result.value = z1;

        var cgstamt=qty2*cgstper;
        var cgstamt2=cgstamt/100;
        var cgstamt3=cgstamt2.toFixed(2);
        document.getElementById('cgstamt1').value = cgstamt3;
        document.getElementById("cgstdis1").innerHTML = cgstamt3;

        var sgstamt=qty2*sgstper;
        var sgstamt2=sgstamt/100;
        var sgstamt3=sgstamt2.toFixed(2);
        document.getElementById('sgstamt1').value = sgstamt3;
        document.getElementById("sgstdis1").innerHTML = sgstamt3;

        var igstamt=qty2*igstper;
        var igstamt2=igstamt/100;
        var igstamt3=igstamt2.toFixed(2);
        document.getElementById('igstamt1').value = igstamt3;
        document.getElementById("igstdis1").innerHTML = igstamt3;
    } 
    var cess_cgstper = document.getElementById('cess_cgstper1').value;
    var cess_sgstper = document.getElementById('cess_sgstper1').value;
    var cess_igstper = document.getElementById('cess_igstper1').value;
    
    var cgstamt = document.getElementById('cgstamt1').value;
    var sgstamt = document.getElementById('sgstamt1').value;
    var igstamt = document.getElementById('igstamt1').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt1').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt1').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt1').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt1').value=cgst_cessamt3;
    }
 
}
</script>

<!--onchange of tax type calculating igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
$(document).ready(function(){
$('#tax1').on('change', function(){
    var unitpr = document.getElementById('unitprice1').value;   
    var qty = document.getElementById('poqty1').value;
    var discnt = document.getElementById('discount1').value;  
    var result = document.getElementById('result1').value;; 

    var cgstper = document.getElementById('cgstper1').value;
    var sgstper = document.getElementById('sgstper1').value;
    var igstper = document.getElementById('igstper1').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('result21').value = z11;

    if(discnt!='0')
    {
      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt1').value = cgstamt3;
      document.getElementById("cgstdis1").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt1').value = sgstamt3;
      document.getElementById("sgstdis1").innerHTML = sgstamt3; ;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt1').value = igstamt3;
      document.getElementById("igstdis1").innerHTML = igstamt3; ;
    }
    if(discnt=='0')
    {
      var cgstamt=qty2*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt1').value = cgstamt3;
      document.getElementById("cgstdis1").innerHTML = cgstamt3;

      var sgstamt=qty2*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt1').value = sgstamt3;
      document.getElementById("sgstdis1").innerHTML = sgstamt3;

      var igstamt=qty2*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt1').value = igstamt3;
      document.getElementById("igstdis1").innerHTML = igstamt3;
    }

    var cess_cgstper = document.getElementById('cess_cgstper1').value;
    var cess_sgstper = document.getElementById('cess_sgstper1').value;
    var cess_igstper = document.getElementById('cess_igstper1').value;
    
    var cgstamt = document.getElementById('cgstamt1').value;
    var sgstamt = document.getElementById('sgstamt1').value;
    var igstamt = document.getElementById('igstamt1').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt1').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt1').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt1').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt1').value=cgst_cessamt3;
    }
   
});
});
</script>
<!--onchange of CESS type calculating CESS amount -->
<script type="text/javascript">
$(document).ready(function(){
$('#cesstype1').on('change', function(){
  
    var cess_cgstper = document.getElementById('cess_cgstper1').value;
    var cess_sgstper = document.getElementById('cess_sgstper1').value;
    var cess_igstper = document.getElementById('cess_igstper1').value;
    
    var cgstamt = document.getElementById('cgstamt1').value;
    var sgstamt = document.getElementById('sgstamt1').value;
    var igstamt = document.getElementById('igstamt1').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt1').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt1').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt1').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt1').value=cgst_cessamt3;
    }
   
});
});
</script>

<!--calculation of total price ,igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
function thirdrow() 
{
    var unitpr = document.getElementById('unitprice2').value;   //15
    var qty = document.getElementById('poqty2').value;  //2
    var discnt = document.getElementById('discount2').value;  //2%
    var result = document.getElementById('totalprice2'); 
    
    var cgstper = document.getElementById('cgstper2').value;
    var sgstper = document.getElementById('sgstper2').value;
    var igstper = document.getElementById('igstper2').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis2').value = z11;
 
    if(discnt!='0')
    {
      result.value = fg4; 

      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt2').value = cgstamt3;
      document.getElementById("cgstdis2").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt2').value = sgstamt3;
      document.getElementById("sgstdis2").innerHTML = sgstamt3;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt2').value = igstamt3;
      document.getElementById("igstdis2").innerHTML = igstamt3;

    }
    if(discnt=='0')
    {
        var z=qty2;
        var z1=z.toFixed(2);
        result.value = z1;

        var cgstamt=qty2*cgstper;
        var cgstamt2=cgstamt/100;
        var cgstamt3=cgstamt2.toFixed(2);
        document.getElementById('cgstamt2').value = cgstamt3;
        document.getElementById("cgstdis2").innerHTML = cgstamt3;

        var sgstamt=qty2*sgstper;
        var sgstamt2=sgstamt/100;
        var sgstamt3=sgstamt2.toFixed(2);
        document.getElementById('sgstamt2').value = sgstamt3;
        document.getElementById("sgstdis2").innerHTML = sgstamt3;

        var igstamt=qty2*igstper;
        var igstamt2=igstamt/100;
        var igstamt3=igstamt2.toFixed(2);
        document.getElementById('igstamt2').value = igstamt3;
        document.getElementById("igstdis2").innerHTML = igstamt3;
    } 
    var cess_cgstper = document.getElementById('cess_cgstper2').value;
    var cess_sgstper = document.getElementById('cess_sgstper2').value;
    var cess_igstper = document.getElementById('cess_igstper2').value;
    
    var cgstamt = document.getElementById('cgstamt2').value;
    var sgstamt = document.getElementById('sgstamt2').value;
    var igstamt = document.getElementById('igstamt2').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt2').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt2').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt2').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt2').value=cgst_cessamt3;
    }
 
}
</script>

<!--onchange of tax type calculating igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
$(document).ready(function(){
$('#tax2').on('change', function(){
    var unitpr = document.getElementById('unitprice2').value;   
    var qty = document.getElementById('poqty2').value;
    var discnt = document.getElementById('discount2').value;  
    var result = document.getElementById('totalprice2').value;; 

    var cgstper = document.getElementById('cgstper2').value;
    var sgstper = document.getElementById('sgstper2').value;
    var igstper = document.getElementById('igstper2').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis2').value = z11;

    if(discnt!='0')
    {
      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt2').value = cgstamt3;
      document.getElementById("cgstdis2").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt2').value = sgstamt3;
      document.getElementById("sgstdis2").innerHTML = sgstamt3; ;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt2').value = igstamt3;
      document.getElementById("igstdis2").innerHTML = igstamt3; ;
    }
    if(discnt=='0')
    {
      var cgstamt=qty2*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt2').value = cgstamt3;
      document.getElementById("cgstdis2").innerHTML = cgstamt3;

      var sgstamt=qty2*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt2').value = sgstamt3;
      document.getElementById("sgstdis2").innerHTML = sgstamt3;

      var igstamt=qty2*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt2').value = igstamt3;
      document.getElementById("igstdis2").innerHTML = igstamt3;
    }

    var cess_cgstper = document.getElementById('cess_cgstper2').value;
    var cess_sgstper = document.getElementById('cess_sgstper2').value;
    var cess_igstper = document.getElementById('cess_igstper2').value;
    
    var cgstamt = document.getElementById('cgstamt2').value;
    var sgstamt = document.getElementById('sgstamt2').value;
    var igstamt = document.getElementById('igstamt2').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt2').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt2').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt2').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt2').value=cgst_cessamt3;
    }
   
});
});
</script>
<!--onchange of CESS type calculating CESS amount -->
<script type="text/javascript">
$(document).ready(function(){
$('#cesstype2').on('change', function(){
  
    var cess_cgstper = document.getElementById('cess_cgstper2').value;
    var cess_sgstper = document.getElementById('cess_sgstper2').value;
    var cess_igstper = document.getElementById('cess_igstper2').value;
    
    var cgstamt = document.getElementById('cgstamt2').value;
    var sgstamt = document.getElementById('sgstamt2').value;
    var igstamt = document.getElementById('igstamt2').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt2').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt2').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt2').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt2').value=cgst_cessamt3;
    }
   
});
});
</script>


<!--FOURTH ROW CALCULATION -->
<!--calculation of total price ,igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
function fourthrow() 
{
    var unitpr = document.getElementById('unitprice3').value;   //15
    var qty = document.getElementById('poqty3').value;  //2
    var discnt = document.getElementById('discount3').value;  //2%
    var result = document.getElementById('totalprice3'); 
    
    var cgstper = document.getElementById('cgstper3').value;
    var sgstper = document.getElementById('sgstper3').value;
    var igstper = document.getElementById('igstper3').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis3').value = z11;
 
    if(discnt!='0')
    {
      result.value = fg4; 

      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt3').value = cgstamt3;
      document.getElementById("cgstdis3").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt3').value = sgstamt3;
      document.getElementById("sgstdis3").innerHTML = sgstamt3;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt3').value = igstamt3;
      document.getElementById("igstdis3").innerHTML = igstamt3;

    }
    if(discnt=='0')
    {
        var z=qty2;
        var z1=z.toFixed(2);
        result.value = z1;

        var cgstamt=qty2*cgstper;
        var cgstamt2=cgstamt/100;
        var cgstamt3=cgstamt2.toFixed(2);
        document.getElementById('cgstamt3').value = cgstamt3;
        document.getElementById("cgstdis3").innerHTML = cgstamt3;

        var sgstamt=qty2*sgstper;
        var sgstamt2=sgstamt/100;
        var sgstamt3=sgstamt2.toFixed(2);
        document.getElementById('sgstamt3').value = sgstamt3;
        document.getElementById("sgstdis3").innerHTML = sgstamt3;

        var igstamt=qty2*igstper;
        var igstamt2=igstamt/100;
        var igstamt3=igstamt2.toFixed(2);
        document.getElementById('igstamt3').value = igstamt3;
        document.getElementById("igstdis3").innerHTML = igstamt3;
    } 
    var cess_cgstper = document.getElementById('cess_cgstper3').value;
    var cess_sgstper = document.getElementById('cess_sgstper3').value;
    var cess_igstper = document.getElementById('cess_igstper3').value;
    
    var cgstamt = document.getElementById('cgstamt3').value;
    var sgstamt = document.getElementById('sgstamt3').value;
    var igstamt = document.getElementById('igstamt3').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt3').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt3').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt3').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt3').value=cgst_cessamt3;
    }
 
}
</script>

<!--onchange of tax type calculating igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
$(document).ready(function(){
$('#tax3').on('change', function(){
    var unitpr = document.getElementById('unitprice3').value;   
    var qty = document.getElementById('poqty3').value;
    var discnt = document.getElementById('discount3').value;  
    var result = document.getElementById('totalprice3').value;; 

    var cgstper = document.getElementById('cgstper3').value;
    var sgstper = document.getElementById('sgstper3').value;
    var igstper = document.getElementById('igstper3').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis3').value = z11;

    if(discnt!='0')
    {
      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt3').value = cgstamt3;
      document.getElementById("cgstdis3").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt3').value = sgstamt3;
      document.getElementById("sgstdis3").innerHTML = sgstamt3; ;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt3').value = igstamt3;
      document.getElementById("igstdis3").innerHTML = igstamt3; ;
    }
    if(discnt=='0')
    {
      var cgstamt=qty2*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt3').value = cgstamt3;
      document.getElementById("cgstdis3").innerHTML = cgstamt3;

      var sgstamt=qty2*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt3').value = sgstamt3;
      document.getElementById("sgstdis3").innerHTML = sgstamt3;

      var igstamt=qty2*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt3').value = igstamt3;
      document.getElementById("igstdis3").innerHTML = igstamt3;
    }

    var cess_cgstper = document.getElementById('cess_cgstper3').value;
    var cess_sgstper = document.getElementById('cess_sgstper3').value;
    var cess_igstper = document.getElementById('cess_igstper3').value;
    
    var cgstamt = document.getElementById('cgstamt3').value;
    var sgstamt = document.getElementById('sgstamt3').value;
    var igstamt = document.getElementById('igstamt3').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt3').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt3').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt3').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt3').value=cgst_cessamt3;
    }
   
});
});
</script>
<!--onchange of CESS type calculating CESS amount -->
<script type="text/javascript">
$(document).ready(function(){
$('#cesstype3').on('change', function(){
  
    var cess_cgstper = document.getElementById('cess_cgstper3').value;
    var cess_sgstper = document.getElementById('cess_sgstper3').value;
    var cess_igstper = document.getElementById('cess_igstper3').value;
    
    var cgstamt = document.getElementById('cgstamt3').value;
    var sgstamt = document.getElementById('sgstamt3').value;
    var igstamt = document.getElementById('igstamt3').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt3').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt3').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt3').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt3').value=cgst_cessamt3;
    }
   
});
});
</script>

<!--FIFTH ROW CALCULATION -->
<!--calculation of total price ,igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
function fifthrow() 
{
    var unitpr = document.getElementById('unitprice4').value;   //15
    var qty = document.getElementById('poqty4').value;  //2
    var discnt = document.getElementById('discount4').value;  //2%
    var result = document.getElementById('totalprice4'); 
    
    var cgstper = document.getElementById('cgstper4').value;
    var sgstper = document.getElementById('sgstper4').value;
    var igstper = document.getElementById('igstper4').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis4').value = z11;
 
    if(discnt!='0')
    {
      result.value = fg4; 

      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt4').value = cgstamt3;
      document.getElementById("cgstdis4").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt4').value = sgstamt3;
      document.getElementById("sgstdis4").innerHTML = sgstamt3;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt4').value = igstamt3;
      document.getElementById("igstdis4").innerHTML = igstamt3;

    }
    if(discnt=='0')
    {
        var z=qty2;
        var z1=z.toFixed(2);
        result.value = z1;

        var cgstamt=qty2*cgstper;
        var cgstamt2=cgstamt/100;
        var cgstamt3=cgstamt2.toFixed(2);
        document.getElementById('cgstamt4').value = cgstamt3;
        document.getElementById("cgstdis4").innerHTML = cgstamt3;

        var sgstamt=qty2*sgstper;
        var sgstamt2=sgstamt/100;
        var sgstamt3=sgstamt2.toFixed(2);
        document.getElementById('sgstamt4').value = sgstamt3;
        document.getElementById("sgstdis4").innerHTML = sgstamt3;

        var igstamt=qty2*igstper;
        var igstamt2=igstamt/100;
        var igstamt3=igstamt2.toFixed(2);
        document.getElementById('igstamt4').value = igstamt3;
        document.getElementById("igstdis4").innerHTML = igstamt3;
    } 
    var cess_cgstper = document.getElementById('cess_cgstper4').value;
    var cess_sgstper = document.getElementById('cess_sgstper4').value;
    var cess_igstper = document.getElementById('cess_igstper4').value;
    
    var cgstamt = document.getElementById('cgstamt4').value;
    var sgstamt = document.getElementById('sgstamt4').value;
    var igstamt = document.getElementById('igstamt4').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt4').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt4').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt4').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt4').value=cgst_cessamt3;
    }
 
}
</script>

<!--onchange of tax type calculating igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
$(document).ready(function(){
$('#tax4').on('change', function(){
    var unitpr = document.getElementById('unitprice4').value;   
    var qty = document.getElementById('poqty4').value;
    var discnt = document.getElementById('discount4').value;  
    var result = document.getElementById('totalprice4').value;; 

    var cgstper = document.getElementById('cgstper4').value;
    var sgstper = document.getElementById('sgstper4').value;
    var igstper = document.getElementById('igstper4').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis4').value = z11;

    if(discnt!='0')
    {
      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt4').value = cgstamt3;
      document.getElementById("cgstdis4").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt4').value = sgstamt3;
      document.getElementById("sgstdis4").innerHTML = sgstamt3; ;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt4').value = igstamt3;
      document.getElementById("igstdis4").innerHTML = igstamt3; ;
    }
    if(discnt=='0')
    {
      var cgstamt=qty2*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt4').value = cgstamt3;
      document.getElementById("cgstdis4").innerHTML = cgstamt3;

      var sgstamt=qty2*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt4').value = sgstamt3;
      document.getElementById("sgstdis4").innerHTML = sgstamt3;

      var igstamt=qty2*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt4').value = igstamt3;
      document.getElementById("igstdis4").innerHTML = igstamt3;
    }

    var cess_cgstper = document.getElementById('cess_cgstper4').value;
    var cess_sgstper = document.getElementById('cess_sgstper4').value;
    var cess_igstper = document.getElementById('cess_igstper4').value;
    
    var cgstamt = document.getElementById('cgstamt4').value;
    var sgstamt = document.getElementById('sgstamt4').value;
    var igstamt = document.getElementById('igstamt4').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt4').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt4').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt4').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt4').value=cgst_cessamt3;
    }
   
});
});
</script>
<!--onchange of CESS type calculating CESS amount -->
<script type="text/javascript">
$(document).ready(function(){
$('#cesstype4').on('change', function(){
  
    var cess_cgstper = document.getElementById('cess_cgstper4').value;
    var cess_sgstper = document.getElementById('cess_sgstper4').value;
    var cess_igstper = document.getElementById('cess_igstper4').value;
    
    var cgstamt = document.getElementById('cgstamt4').value;
    var sgstamt = document.getElementById('sgstamt4').value;
    var igstamt = document.getElementById('igstamt4').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt4').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt4').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt4').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt4').value=cgst_cessamt3;
    }
   
});
});
</script>

<!--6TH ROW CALCULATION -->
<!--calculation of total price ,igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
function sixthrow() 
{
    var unitpr = document.getElementById('unitprice5').value;   //15
    var qty = document.getElementById('poqty5').value;  //2
    var discnt = document.getElementById('discount5').value;  //2%
    var result = document.getElementById('totalprice5'); 
    
    var cgstper = document.getElementById('cgstper5').value;
    var sgstper = document.getElementById('sgstper5').value;
    var igstper = document.getElementById('igstper5').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis5').value = z11;
 
    if(discnt!='0')
    {
      result.value = fg4; 

      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt5').value = cgstamt3;
      document.getElementById("cgstdis5").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt5').value = sgstamt3;
      document.getElementById("sgstdis5").innerHTML = sgstamt3;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt5').value = igstamt3;
      document.getElementById("igstdis5").innerHTML = igstamt3;

    }
    if(discnt=='0')
    {
        var z=qty2;
        var z1=z.toFixed(2);
        result.value = z1;

        var cgstamt=qty2*cgstper;
        var cgstamt2=cgstamt/100;
        var cgstamt3=cgstamt2.toFixed(2);
        document.getElementById('cgstamt5').value = cgstamt3;
        document.getElementById("cgstdis5").innerHTML = cgstamt3;

        var sgstamt=qty2*sgstper;
        var sgstamt2=sgstamt/100;
        var sgstamt3=sgstamt2.toFixed(2);
        document.getElementById('sgstamt5').value = sgstamt3;
        document.getElementById("sgstdis5").innerHTML = sgstamt3;

        var igstamt=qty2*igstper;
        var igstamt2=igstamt/100;
        var igstamt3=igstamt2.toFixed(2);
        document.getElementById('igstamt5').value = igstamt3;
        document.getElementById("igstdis5").innerHTML = igstamt3;
    } 
    var cess_cgstper = document.getElementById('cess_cgstper5').value;
    var cess_sgstper = document.getElementById('cess_sgstper5').value;
    var cess_igstper = document.getElementById('cess_igstper5').value;
    
    var cgstamt = document.getElementById('cgstamt5').value;
    var sgstamt = document.getElementById('sgstamt5').value;
    var igstamt = document.getElementById('igstamt5').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt5').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt5').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt5').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt5').value=cgst_cessamt3;
    }
 
}
</script>

<!--onchange of tax type calculating igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
$(document).ready(function(){
$('#tax5').on('change', function(){
    var unitpr = document.getElementById('unitprice5').value;   
    var qty = document.getElementById('poqty5').value;
    var discnt = document.getElementById('discount5').value;  
    var result = document.getElementById('totalprice5').value;; 

    var cgstper = document.getElementById('cgstper5').value;
    var sgstper = document.getElementById('sgstper5').value;
    var igstper = document.getElementById('igstper5').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis5').value = z11;

    if(discnt!='0')
    {
      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt5').value = cgstamt3;
      document.getElementById("cgstdis5").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt5').value = sgstamt3;
      document.getElementById("sgstdis5").innerHTML = sgstamt3; ;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt5').value = igstamt3;
      document.getElementById("igstdis5").innerHTML = igstamt3; ;
    }
    if(discnt=='0')
    {
      var cgstamt=qty2*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt5').value = cgstamt3;
      document.getElementById("cgstdis5").innerHTML = cgstamt3;

      var sgstamt=qty2*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt5').value = sgstamt3;
      document.getElementById("sgstdis5").innerHTML = sgstamt3;

      var igstamt=qty2*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt5').value = igstamt3;
      document.getElementById("igstdis5").innerHTML = igstamt3;
    }

    var cess_cgstper = document.getElementById('cess_cgstper5').value;
    var cess_sgstper = document.getElementById('cess_sgstper5').value;
    var cess_igstper = document.getElementById('cess_igstper5').value;
    
    var cgstamt = document.getElementById('cgstamt5').value;
    var sgstamt = document.getElementById('sgstamt5').value;
    var igstamt = document.getElementById('igstamt5').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt5').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt5').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt5').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt5').value=cgst_cessamt3;
    }
   
});
});
</script>
<!--onchange of CESS type calculating CESS amount -->
<script type="text/javascript">
$(document).ready(function(){
$('#cesstype5').on('change', function(){
  
    var cess_cgstper = document.getElementById('cess_cgstper5').value;
    var cess_sgstper = document.getElementById('cess_sgstper5').value;
    var cess_igstper = document.getElementById('cess_igstper5').value;
    
    var cgstamt = document.getElementById('cgstamt5').value;
    var sgstamt = document.getElementById('sgstamt5').value;
    var igstamt = document.getElementById('igstamt5').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt5').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt5').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt5').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt5').value=cgst_cessamt3;
    }
   
});
});
</script>


<!--7TH ROW CALCULATION -->

<!--calculation of total price ,igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
function seventhrow() 
{
    var unitpr = document.getElementById('unitprice6').value;   //15
    var qty = document.getElementById('poqty6').value;  //2
    var discnt = document.getElementById('discount6').value;  //2%
    var result = document.getElementById('totalprice6'); 
    
    var cgstper = document.getElementById('cgstper6').value;
    var sgstper = document.getElementById('sgstper6').value;
    var igstper = document.getElementById('igstper6').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis6').value = z11;
 
    if(discnt!='0')
    {
      result.value = fg4; 

      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt6').value = cgstamt3;
      document.getElementById("cgstdis6").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt6').value = sgstamt3;
      document.getElementById("sgstdis6").innerHTML = sgstamt3;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt6').value = igstamt3;
      document.getElementById("igstdis6").innerHTML = igstamt3;

    }
    if(discnt=='0')
    {
        var z=qty2;
        var z1=z.toFixed(2);
        result.value = z1;

        var cgstamt=qty2*cgstper;
        var cgstamt2=cgstamt/100;
        var cgstamt3=cgstamt2.toFixed(2);
        document.getElementById('cgstamt6').value = cgstamt3;
        document.getElementById("cgstdis6").innerHTML = cgstamt3;

        var sgstamt=qty2*sgstper;
        var sgstamt2=sgstamt/100;
        var sgstamt3=sgstamt2.toFixed(2);
        document.getElementById('sgstamt6').value = sgstamt3;
        document.getElementById("sgstdis6").innerHTML = sgstamt3;

        var igstamt=qty2*igstper;
        var igstamt2=igstamt/100;
        var igstamt3=igstamt2.toFixed(2);
        document.getElementById('igstamt6').value = igstamt3;
        document.getElementById("igstdis6").innerHTML = igstamt3;
    } 
    var cess_cgstper = document.getElementById('cess_cgstper6').value;
    var cess_sgstper = document.getElementById('cess_sgstper6').value;
    var cess_igstper = document.getElementById('cess_igstper6').value;
    
    var cgstamt = document.getElementById('cgstamt6').value;
    var sgstamt = document.getElementById('sgstamt6').value;
    var igstamt = document.getElementById('igstamt6').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt6').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt6').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt6').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt6').value=cgst_cessamt3;
    }
 
}
</script>

<!--onchange of tax type calculating igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
$(document).ready(function(){
$('#tax6').on('change', function(){
    var unitpr = document.getElementById('unitprice6').value;   
    var qty = document.getElementById('poqty6').value;
    var discnt = document.getElementById('discount6').value;  
    var result = document.getElementById('totalprice6').value;; 

    var cgstper = document.getElementById('cgstper6').value;
    var sgstper = document.getElementById('sgstper6').value;
    var igstper = document.getElementById('igstper6').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis6').value = z11;

    if(discnt!='0')
    {
      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt6').value = cgstamt3;
      document.getElementById("cgstdis6").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt6').value = sgstamt3;
      document.getElementById("sgstdis6").innerHTML = sgstamt3; ;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt6').value = igstamt3;
      document.getElementById("igstdis6").innerHTML = igstamt3; ;
    }
    if(discnt=='0')
    {
      var cgstamt=qty2*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt6').value = cgstamt3;
      document.getElementById("cgstdis6").innerHTML = cgstamt3;

      var sgstamt=qty2*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt6').value = sgstamt3;
      document.getElementById("sgstdis6").innerHTML = sgstamt3;

      var igstamt=qty2*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt6').value = igstamt3;
      document.getElementById("igstdis6").innerHTML = igstamt3;
    }

    var cess_cgstper = document.getElementById('cess_cgstper6').value;
    var cess_sgstper = document.getElementById('cess_sgstper6').value;
    var cess_igstper = document.getElementById('cess_igstper6').value;
    
    var cgstamt = document.getElementById('cgstamt6').value;
    var sgstamt = document.getElementById('sgstamt6').value;
    var igstamt = document.getElementById('igstamt6').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt6').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt6').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt6').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt6').value=cgst_cessamt3;
    }
   
});
});
</script>
<!--onchange of CESS type calculating CESS amount -->
<script type="text/javascript">
$(document).ready(function(){
$('#cesstype6').on('change', function(){
  
    var cess_cgstper = document.getElementById('cess_cgstper6').value;
    var cess_sgstper = document.getElementById('cess_sgstper6').value;
    var cess_igstper = document.getElementById('cess_igstper6').value;
    
    var cgstamt = document.getElementById('cgstamt6').value;
    var sgstamt = document.getElementById('sgstamt6').value;
    var igstamt = document.getElementById('igstamt6').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt6').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt6').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt6').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt6').value=cgst_cessamt3;
    }
   
});
});
</script>

<!--8th ROW CALCULATION -->
<!--calculation of total price ,igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
function eighthrow() 
{
    var unitpr = document.getElementById('unitprice7').value;   //15
    var qty = document.getElementById('poqty7').value;  //2
    var discnt = document.getElementById('discount7').value;  //2%
    var result = document.getElementById('totalprice7'); 
    
    var cgstper = document.getElementById('cgstper7').value;
    var sgstper = document.getElementById('sgstper7').value;
    var igstper = document.getElementById('igstper7').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis7').value = z11;
 
    if(discnt!='0')
    {
      result.value = fg4; 

      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt7').value = cgstamt3;
      document.getElementById("cgstdis7").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt7').value = sgstamt3;
      document.getElementById("sgstdis7").innerHTML = sgstamt3;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt7').value = igstamt3;
      document.getElementById("igstdis7").innerHTML = igstamt3;

    }
    if(discnt=='0')
    {
        var z=qty2;
        var z1=z.toFixed(2);
        result.value = z1;

        var cgstamt=qty2*cgstper;
        var cgstamt2=cgstamt/100;
        var cgstamt3=cgstamt2.toFixed(2);
        document.getElementById('cgstamt7').value = cgstamt3;
        document.getElementById("cgstdis7").innerHTML = cgstamt3;

        var sgstamt=qty2*sgstper;
        var sgstamt2=sgstamt/100;
        var sgstamt3=sgstamt2.toFixed(2);
        document.getElementById('sgstamt7').value = sgstamt3;
        document.getElementById("sgstdis7").innerHTML = sgstamt3;

        var igstamt=qty2*igstper;
        var igstamt2=igstamt/100;
        var igstamt3=igstamt2.toFixed(2);
        document.getElementById('igstamt7').value = igstamt3;
        document.getElementById("igstdis7").innerHTML = igstamt3;
    } 
    var cess_cgstper = document.getElementById('cess_cgstper7').value;
    var cess_sgstper = document.getElementById('cess_sgstper7').value;
    var cess_igstper = document.getElementById('cess_igstper7').value;
    
    var cgstamt = document.getElementById('cgstamt7').value;
    var sgstamt = document.getElementById('sgstamt7').value;
    var igstamt = document.getElementById('igstamt7').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt7').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt7').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt7').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt7').value=cgst_cessamt3;
    }
 
}
</script>

<!--onchange of tax type calculating igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
$(document).ready(function(){
$('#tax7').on('change', function(){
    var unitpr = document.getElementById('unitprice7').value;   
    var qty = document.getElementById('poqty7').value;
    var discnt = document.getElementById('discount7').value;  
    var result = document.getElementById('totalprice7').value;; 

    var cgstper = document.getElementById('cgstper7').value;
    var sgstper = document.getElementById('sgstper7').value;
    var igstper = document.getElementById('igstper7').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis7').value = z11;

    if(discnt!='0')
    {
      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt7').value = cgstamt3;
      document.getElementById("cgstdis7").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt7').value = sgstamt3;
      document.getElementById("sgstdis7").innerHTML = sgstamt3; ;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt7').value = igstamt3;
      document.getElementById("igstdis7").innerHTML = igstamt3; ;
    }
    if(discnt=='0')
    {
      var cgstamt=qty2*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt7').value = cgstamt3;
      document.getElementById("cgstdis7").innerHTML = cgstamt3;

      var sgstamt=qty2*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt7').value = sgstamt3;
      document.getElementById("sgstdis7").innerHTML = sgstamt3;

      var igstamt=qty2*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt7').value = igstamt3;
      document.getElementById("igstdis7").innerHTML = igstamt3;
    }

    var cess_cgstper = document.getElementById('cess_cgstper7').value;
    var cess_sgstper = document.getElementById('cess_sgstper7').value;
    var cess_igstper = document.getElementById('cess_igstper7').value;
    
    var cgstamt = document.getElementById('cgstamt7').value;
    var sgstamt = document.getElementById('sgstamt7').value;
    var igstamt = document.getElementById('igstamt7').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt7').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt7').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt7').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt7').value=cgst_cessamt3;
    }
   
});
});
</script>
<!--onchange of CESS type calculating CESS amount -->
<script type="text/javascript">
$(document).ready(function(){
$('#cesstype7').on('change', function(){
  
    var cess_cgstper = document.getElementById('cess_cgstper7').value;
    var cess_sgstper = document.getElementById('cess_sgstper7').value;
    var cess_igstper = document.getElementById('cess_igstper7').value;
    
    var cgstamt = document.getElementById('cgstamt7').value;
    var sgstamt = document.getElementById('sgstamt7').value;
    var igstamt = document.getElementById('igstamt7').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt7').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt7').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt7').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt7').value=cgst_cessamt3;
    }
   
});
});
</script>

<!--9TH ROW CALCULATION -->
<!--calculation of total price ,igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
function ninthrow() 
{
    var unitpr = document.getElementById('unitprice8').value;   //15
    var qty = document.getElementById('poqty8').value;  //2
    var discnt = document.getElementById('discount8').value;  //2%
    var result = document.getElementById('totalprice8'); 
    
    var cgstper = document.getElementById('cgstper8').value;
    var sgstper = document.getElementById('sgstper8').value;
    var igstper = document.getElementById('igstper8').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis8').value = z11;
 
    if(discnt!='0')
    {
      result.value = fg4; 

      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt8').value = cgstamt3;
      document.getElementById("cgstdis8").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt8').value = sgstamt3;
      document.getElementById("sgstdis8").innerHTML = sgstamt3;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt8').value = igstamt3;
      document.getElementById("igstdis8").innerHTML = igstamt3;

    }
    if(discnt=='0')
    {
        var z=qty2;
        var z1=z.toFixed(2);
        result.value = z1;

        var cgstamt=qty2*cgstper;
        var cgstamt2=cgstamt/100;
        var cgstamt3=cgstamt2.toFixed(2);
        document.getElementById('cgstamt8').value = cgstamt3;
        document.getElementById("cgstdis8").innerHTML = cgstamt3;

        var sgstamt=qty2*sgstper;
        var sgstamt2=sgstamt/100;
        var sgstamt3=sgstamt2.toFixed(2);
        document.getElementById('sgstamt8').value = sgstamt3;
        document.getElementById("sgstdis8").innerHTML = sgstamt3;

        var igstamt=qty2*igstper;
        var igstamt2=igstamt/100;
        var igstamt3=igstamt2.toFixed(2);
        document.getElementById('igstamt8').value = igstamt3;
        document.getElementById("igstdis8").innerHTML = igstamt3;
    } 
    var cess_cgstper = document.getElementById('cess_cgstper8').value;
    var cess_sgstper = document.getElementById('cess_sgstper8').value;
    var cess_igstper = document.getElementById('cess_igstper8').value;
    
    var cgstamt = document.getElementById('cgstamt8').value;
    var sgstamt = document.getElementById('sgstamt8').value;
    var igstamt = document.getElementById('igstamt8').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt8').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt8').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt8').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt8').value=cgst_cessamt3;
    }
 
}
</script>

<!--onchange of tax type calculating igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
$(document).ready(function(){
$('#tax8').on('change', function(){
    var unitpr = document.getElementById('unitprice8').value;   
    var qty = document.getElementById('poqty8').value;
    var discnt = document.getElementById('discount8').value;  
    var result = document.getElementById('totalprice8').value;; 

    var cgstper = document.getElementById('cgstper8').value;
    var sgstper = document.getElementById('sgstper8').value;
    var igstper = document.getElementById('igstper8').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis8').value = z11;

    if(discnt!='0')
    {
      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt8').value = cgstamt3;
      document.getElementById("cgstdis8").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt8').value = sgstamt3;
      document.getElementById("sgstdis8").innerHTML = sgstamt3; ;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt8').value = igstamt3;
      document.getElementById("igstdis8").innerHTML = igstamt3; ;
    }
    if(discnt=='0')
    {
      var cgstamt=qty2*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt8').value = cgstamt3;
      document.getElementById("cgstdis8").innerHTML = cgstamt3;

      var sgstamt=qty2*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt8').value = sgstamt3;
      document.getElementById("sgstdis8").innerHTML = sgstamt3;

      var igstamt=qty2*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt8').value = igstamt3;
      document.getElementById("igstdis8").innerHTML = igstamt3;
    }

    var cess_cgstper = document.getElementById('cess_cgstper8').value;
    var cess_sgstper = document.getElementById('cess_sgstper8').value;
    var cess_igstper = document.getElementById('cess_igstper8').value;
    
    var cgstamt = document.getElementById('cgstamt8').value;
    var sgstamt = document.getElementById('sgstamt8').value;
    var igstamt = document.getElementById('igstamt8').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt8').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt8').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt8').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt8').value=cgst_cessamt3;
    }
   
});
});
</script>
<!--onchange of CESS type calculating CESS amount -->
<script type="text/javascript">
$(document).ready(function(){
$('#cesstype8').on('change', function(){
  
    var cess_cgstper = document.getElementById('cess_cgstper8').value;
    var cess_sgstper = document.getElementById('cess_sgstper8').value;
    var cess_igstper = document.getElementById('cess_igstper8').value;
    
    var cgstamt = document.getElementById('cgstamt8').value;
    var sgstamt = document.getElementById('sgstamt8').value;
    var igstamt = document.getElementById('igstamt8').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt8').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt8').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt8').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt8').value=cgst_cessamt3;
    }
   
});
});
</script>

<!--10 th ROW CALCULATION -->
<!--calculation of total price ,igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
function tenthrow() 
{
    var unitpr = document.getElementById('unitprice9').value;   //15
    var qty = document.getElementById('poqty9').value;  //2
    var discnt = document.getElementById('discount9').value;  //2%
    var result = document.getElementById('totalprice9'); 
    
    var cgstper = document.getElementById('cgstper9').value;
    var sgstper = document.getElementById('sgstper9').value;
    var igstper = document.getElementById('igstper9').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis9').value = z11;
 
    if(discnt!='0')
    {
      result.value = fg4; 

      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt9').value = cgstamt3;
      document.getElementById("cgstdis9").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt9').value = sgstamt3;
      document.getElementById("sgstdis9").innerHTML = sgstamt3;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt9').value = igstamt3;
      document.getElementById("igstdis9").innerHTML = igstamt3;

    }
    if(discnt=='0')
    {
        var z=qty2;
        var z1=z.toFixed(2);
        result.value = z1;

        var cgstamt=qty2*cgstper;
        var cgstamt2=cgstamt/100;
        var cgstamt3=cgstamt2.toFixed(2);
        document.getElementById('cgstamt9').value = cgstamt3;
        document.getElementById("cgstdis9").innerHTML = cgstamt3;

        var sgstamt=qty2*sgstper;
        var sgstamt2=sgstamt/100;
        var sgstamt3=sgstamt2.toFixed(2);
        document.getElementById('sgstamt9').value = sgstamt3;
        document.getElementById("sgstdis9").innerHTML = sgstamt3;

        var igstamt=qty2*igstper;
        var igstamt2=igstamt/100;
        var igstamt3=igstamt2.toFixed(2);
        document.getElementById('igstamt9').value = igstamt3;
        document.getElementById("igstdis9").innerHTML = igstamt3;
    } 
    var cess_cgstper = document.getElementById('cess_cgstper9').value;
    var cess_sgstper = document.getElementById('cess_sgstper9').value;
    var cess_igstper = document.getElementById('cess_igstper9').value;
    
    var cgstamt = document.getElementById('cgstamt9').value;
    var sgstamt = document.getElementById('sgstamt9').value;
    var igstamt = document.getElementById('igstamt9').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt9').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt9').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt9').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt9').value=cgst_cessamt3;
    }
 
}
</script>

<!--onchange of tax type calculating igst amt,cgst amt,sgst amt while adding parts -->
<script type="text/javascript">
$(document).ready(function(){
$('#tax9').on('change', function(){
    var unitpr = document.getElementById('unitprice9').value;   
    var qty = document.getElementById('poqty9').value;
    var discnt = document.getElementById('discount9').value;  
    var result = document.getElementById('totalprice9').value;; 

    var cgstper = document.getElementById('cgstper9').value;
    var sgstper = document.getElementById('sgstper9').value;
    var igstper = document.getElementById('igstper9').value;

//total price with discount
    var qty2=unitpr*qty; //30
    var dis=discnt/100;  //0.02
    var fg2=qty2*dis;//30*0.02= 0.6
    var fg3=qty2-fg2; //30-0.6=29.4
    var fg4=fg3.toFixed(2);

//total price without discount
    var totalpr_wo_dis=qty2;
    var z11=totalpr_wo_dis.toFixed(2);
    document.getElementById('totalpr_wo_dis9').value = z11;

    if(discnt!='0')
    {
      var cgstamt=fg3*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt9').value = cgstamt3;
      document.getElementById("cgstdis9").innerHTML = cgstamt3;

      var sgstamt=fg3*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt9').value = sgstamt3;
      document.getElementById("sgstdis9").innerHTML = sgstamt3; ;

      var igstamt=fg3*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt9').value = igstamt3;
      document.getElementById("igstdis9").innerHTML = igstamt3; ;
    }
    if(discnt=='0')
    {
      var cgstamt=qty2*cgstper;
      var cgstamt2=cgstamt/100;
      var cgstamt3=cgstamt2.toFixed(2);
      document.getElementById('cgstamt9').value = cgstamt3;
      document.getElementById("cgstdis9").innerHTML = cgstamt3;

      var sgstamt=qty2*sgstper;
      var sgstamt2=sgstamt/100;
      var sgstamt3=sgstamt2.toFixed(2);
      document.getElementById('sgstamt9').value = sgstamt3;
      document.getElementById("sgstdis9").innerHTML = sgstamt3;

      var igstamt=qty2*igstper;
      var igstamt2=igstamt/100;
      var igstamt3=igstamt2.toFixed(2);
      document.getElementById('igstamt9').value = igstamt3;
      document.getElementById("igstdis9").innerHTML = igstamt3;
    }

    var cess_cgstper = document.getElementById('cess_cgstper9').value;
    var cess_sgstper = document.getElementById('cess_sgstper9').value;
    var cess_igstper = document.getElementById('cess_igstper9').value;
    
    var cgstamt = document.getElementById('cgstamt9').value;
    var sgstamt = document.getElementById('sgstamt9').value;
    var igstamt = document.getElementById('igstamt9').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt9').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt9').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt9').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt9').value=cgst_cessamt3;
    }
   
});
});
</script>
<!--onchange of CESS type calculating CESS amount -->
<script type="text/javascript">
$(document).ready(function(){
$('#cesstype9').on('change', function(){
  
    var cess_cgstper = document.getElementById('cess_cgstper9').value;
    var cess_sgstper = document.getElementById('cess_sgstper9').value;
    var cess_igstper = document.getElementById('cess_igstper9').value;
    
    var cgstamt = document.getElementById('cgstamt9').value;
    var sgstamt = document.getElementById('sgstamt9').value;
    var igstamt = document.getElementById('igstamt9').value;
    
    var sumamt=+cgstamt+ +sgstamt+ +igstamt;
    var sumamt1=sumamt*cess_sgstper;
    var sumamt2=sumamt1/100;
    var sumamt3=sumamt2.toFixed(2);

    var cgst_cessamt1=cgstamt*cess_cgstper;
    var cgst_cessamt2=cgst_cessamt1/100;
    var cgst_cessamt3=cgst_cessamt2.toFixed(2);

    var sgst_cessamt1=sgstamt*cess_sgstper;
    var sgst_cessamt2=sgst_cessamt1/100;
    var sgst_cessamt3=sgst_cessamt2.toFixed(2);

    var igst_cessamt1=igstamt*cess_igstper;
    var igst_cessamt2=igst_cessamt1/100;
    var igst_cessamt3=igst_cessamt2.toFixed(2);

    if(((cess_cgstper>'0')&&(cess_sgstper>'0'))&& ((cess_igstper=='0') || (cess_igstper=="")))
    { 
      document.getElementById('cessamt9').value=sumamt3;
    }
    else if((cess_igstper>'0') && (((cess_cgstper=='0') || (cess_cgstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt9').value=igst_cessamt3;
    }
    else if((cess_sgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_cgstper=='0') || (cess_cgstper==""))))
    {
     document.getElementById('cessamt9').value=sgst_cessamt3;
    } 
    else if((cess_cgstper>'0') && (((cess_igstper=='0') || (cess_igstper=="")) && ((cess_sgstper=='0') || (cess_sgstper==""))))
    {
     document.getElementById('cessamt9').value=cgst_cessamt3;
    }
   
});
});
</script>

<!-- <script type="text/javascript">
// $(document).on("change", ".qty1", function() {
//     var sum = 0;
//     $(".tp1").each(function(){
//         sum += +$(this).val();
//     });
//     $('#subtotal').val(sum);
// });

$(document).ready(function(){           
    $('input.qty1').keyup(function(){   
        calculateTotal(this);
    });
});

function calculateTotal( src ) {
    var sum = 0,
        tbl = $(src).closest('table');
    tbl.find('input.tp').each(function( index, elem ) {
        var val = parseFloat($(elem).val());
        if( !isNaN( val ) ) {
            sum += val;
        }
    });
    tbl.find('input.total').val(sum.toFixed(2));
}
</script> -->


<!--calculations fro subtotal,total cgst,total sgst,total igst and total cess -->
<script type="text/javascript">
$(document).ready(function(){           
    $('select.qtys').change(function(){   
        calculateTotal2(this);
    });
});
$(document).ready(function(){           
    $('input.qty1').keyup(function(){   
        calculateTotal2(this);
    });
});

function calculateTotal2( src ) {
    var sum = 0,
    tbl = $(src).closest('table');

     tbl.find('input.tp').each(function( index, elem ) {
        var val = parseFloat($(elem).val());
        if( !isNaN( val ) ) {
            sum += val;
        }
         tbl.find('input.total').val(sum.toFixed(2));
    });
   

}
$(document).ready(function(){           
    $('select.qtys').change(function(){   
        calculateTotal1(this);
    });
});
$(document).ready(function(){           
    $('input.qty1').keyup(function(){   
        calculateTotal1(this);
    });
});

function calculateTotal1( src ) {
    var sum = 0,
     tbl = $(src).closest('table');
     tbl.find('input.cgstam').each(function( index, elem ) {
        var val = parseFloat($(elem).val());
        if( !isNaN( val ) ) {
            sum += val;
        }
         tbl.find('input.cgs').val(sum.toFixed(2));
    });
   

}

$(document).ready(function(){           
    $('select.qtys').change(function(){   
        calculateTotal(this);
    });
});
$(document).ready(function(){           
    $('input.qty1').keyup(function(){   
        calculateTotal(this);
    });
});

function calculateTotal( src ) {
    var sum = 0,
     tbl = $(src).closest('table');
     tbl.find('input.sgstam').each(function( index, elem ) {
        var val = parseFloat($(elem).val());
        if( !isNaN( val ) ) {
            sum += val;
        }
         tbl.find('input.sgs').val(sum.toFixed(2));
    });
   

}

$(document).ready(function(){           
    $('select.qtys').change(function(){   
        calculateTotalig(this);
    });
});
$(document).ready(function(){           
    $('input.qty1').keyup(function(){   
        calculateTotalig(this);
    });
});

function calculateTotalig( src ) {
    var sum = 0,
     tbl = $(src).closest('table');
     tbl.find('input.igstam').each(function( index, elem ) {
        var val = parseFloat($(elem).val());
        if( !isNaN( val ) ) {
            sum += val;
        }
         tbl.find('input.igs').val(sum.toFixed(2));
    });
   

}


$(document).ready(function(){           
    $('select.qtys').change(function(){   
        calculateTotalces(this);
    });
});
$(document).ready(function(){           
    $('input.qty1').keyup(function(){   
        calculateTotalces(this);
    });
});

function calculateTotalces( src ) {
    var sum = 0,
     tbl = $(src).closest('table');
     tbl.find('input.cessam').each(function( index, elem ) {
        var val = parseFloat($(elem).val());
        if( !isNaN( val ) ) {
            sum += val;
        }
         tbl.find('input.tcess').val(sum.toFixed(2));
    });
   

}



//total amount
$(document).ready(function(){           
    $('select.qtys').change(function(){   
        totalamt(this);
    });
});
$(document).ready(function(){           
    $('input.qty1').keyup(function(){   
        totalamt(this);
    });
});
$(document).ready(function(){           
    $('input.amtclass').keyup(function(){   
        totalamt(this);
    });
});

function totalamt( src ) {
    var sum = 0,
     tbl = $(src).closest('table');
     tbl.find('input.amtclass').each(function( index, elem ) {
        var val = parseFloat($(elem).val());
        if( !isNaN( val ) ) {
            sum += val;
        }
         tbl.find('input.totalamtclass').val(sum.toFixed(2));
    });
   

}

</script>


<script src="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>

<script>
$('#deliverydatepicker').bootstrapMaterialDatePicker({ format: 'DD-MM-YYYY', time: false});
$('#deliverydatepicker1').bootstrapMaterialDatePicker({ format: 'DD-MM-YYYY', time: false});
$('#deliverydatepicker2').bootstrapMaterialDatePicker({ format: 'DD-MM-YYYY', time: false});
$('#deliverydatepicker3').bootstrapMaterialDatePicker({ format: 'DD-MM-YYYY', time: false});
$('#deliverydatepicker4').bootstrapMaterialDatePicker({ format: 'DD-MM-YYYY', time: false});
$('#deliverydatepicker5').bootstrapMaterialDatePicker({ format: 'DD-MM-YYYY', time: false});
$('#deliverydatepicker6').bootstrapMaterialDatePicker({ format: 'DD-MM-YYYY', time: false});
$('#deliverydatepicker7').bootstrapMaterialDatePicker({ format: 'DD-MM-YYYY', time: false});
$('#deliverydatepicker8').bootstrapMaterialDatePicker({ format: 'DD-MM-YYYY', time: false});
$('#deliverydatepicker9').bootstrapMaterialDatePicker({ format: 'DD-MM-YYYY', time: false});
</script>
  </body>

</html>
